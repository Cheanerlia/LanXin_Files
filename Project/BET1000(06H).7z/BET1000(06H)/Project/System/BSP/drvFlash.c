#include "stm32f4xx.h"
#include "configure.h"



//int8_t  bspSave(uint32_t addr, uint8_t *buf, uint16_t len)
//{
//  uint16_t i;
//  uint32_t page;
//  if((addr < 0x08004000) && (addr > 0x08010000))
//  {
//    return -1;
//  }
//  page = addr - 0x08000000;
//  page /= 0x00004000;
//  switch(page)
//  {
//  case 0:
//    page = FLASH_Sector_0;
//    break;
//  case 1:
//    page = FLASH_Sector_1;
//    break;
//  case 2:
//    page = FLASH_Sector_2;
//    break;
//  case 3:
//    page = FLASH_Sector_3;
//    break;
//  case 4:
//    page = FLASH_Sector_4;
//    break;
//  case 5:
//    page = FLASH_Sector_5;
//    break;
//  case 6:
//    page = FLASH_Sector_6;
//    break;
//  case 7:
//    page = FLASH_Sector_7;
//    break;
//  case 8:
//    page = FLASH_Sector_8;
//    break;
//  case 9:
//    page = FLASH_Sector_9;
//    break;
//  }
//  FLASH_Unlock();
//  
//  FLASH_EraseSector(page, VoltageRange_3);
//  
//  for(i = 0; i < len; i++)
//  {
//    FLASH_ProgramByte(addr + i, *buf++);
//  }
//  
//  FLASH_Lock();
//  return 0;
//}
//int8_t  bspLoad(uint32_t addr, uint8_t *buf, uint16_t len)
//{
//  uint16_t i;  
//  uint8_t *src;
//  src = (uint8_t *)addr;
//  for(i = 0; i < len; i++)
//  {
//    *buf++ = *src++;
//  }
//  return 0;
//}







