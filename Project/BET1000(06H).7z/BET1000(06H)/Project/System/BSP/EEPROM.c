#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"
#include "sys2.h"

//��ʼ��IIC
void drvFram_Init(void)
{
		GPIO_InitTypeDef   GPIO_InitStructure;
		RCC_APB2PeriphClockCmd(	RCC_APB2Periph_GPIOB, ENABLE );	//ʹ��GPIOBʱ��
			 
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	
		//GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//�������  
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;//©����·���  
	
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOB, &GPIO_InitStructure);

		GPIO_SetBits(GPIOB, GPIO_Pin_6 | GPIO_Pin_7);//SCL��SDA������	
}


//ʾ����ʵ�⣺11��3.25US  12��3.25US  13:3.5US   14:3.75US
static void drvFramDelay3uS(void)
{
		uint32_t tim;
		/*
		for(tim = 0; tim < 80; tim++)	//1000=100K,200=400K 80=1M(850k)
		{}
		*/
	  /* 
		for(tim = 0; tim < 12; tim++) //STM32F103	
		{}
		*/
	
		for(tim = 0; tim < 24; tim++)	//GD32F103
		{}			
}



