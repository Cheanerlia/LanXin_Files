#include "stm32f4xx.h"
#include "BSP.h"
#include "configure.h"
#include "bspBIMS.h"
#include "sys.h"
#include <time.h>

#include <string.h>


#define ADJ_Save_Addr	0x0100

int32_t drvFramWrite(uint16_t FramAddr, uint8_t *buf, int32_t len);
int32_t drvFramRead(uint16_t FramAddr, uint8_t *buf, int32_t len);
unsigned short Modbus_CRC16(unsigned char *updata, unsigned short len);

uint16_t drvPWM_Value[DAC_ChannelNum];

void drvBSP_GPIO_Init(void);
void drvAI_Init(void);


void drvBSP_PWMtask(void);

void drvBSP_PWMout(uint8_t ch, uint16_t dat);



void funADC_Cal_Init(void)
{
	//bspLoad(AdjCfgAddr,(uint8_t *)&AdjData, sizeof(ADJ_STRUCT) );
	drvFramRead(0x00,(uint8_t *)&AdjData, sizeof(ADJ_STRUCT) );
	if(Modbus_CRC16( (uint8_t *)&AdjData, sizeof(ADJ_STRUCT) ) != 0x00)
	{//��ʼ��Ĭ��ֵ
		//�ٶ�1��
		drvFramRead(0x00,(uint8_t *)&AdjData, sizeof(ADJ_STRUCT) );
		if(Modbus_CRC16( (uint8_t *)&AdjData, sizeof(ADJ_STRUCT) ) != 0x00)
		{
			drvFramRead(0x00,(uint8_t *)&AdjData, sizeof(ADJ_STRUCT) );
			if(Modbus_CRC16( (uint8_t *)&AdjData, sizeof(ADJ_STRUCT) ) != 0x00)
			{
				AdjData.CALdata[0].offset = 0;
				AdjData.CALdata[0].radio = 655360;
				AdjData.CALdata[1].offset = 0;
				AdjData.CALdata[1].radio = 655360;
				AdjData.CALdata[2].offset = 0;
				AdjData.CALdata[2].radio = 655360;
				AdjData.CALdata[3].offset = 0;
				AdjData.CALdata[3].radio = 655360;
				
				AdjData.CALdata[4].offset = -1693;
				AdjData.CALdata[4].radio = 3225;
				AdjData.CALdata[5].offset = -2030;
				AdjData.CALdata[5].radio = 3500;
				AdjData.CALdata[6].offset = -909;
				AdjData.CALdata[6].radio = 872;
				
				AdjData.CALdata[7].offset = 0;
				AdjData.CALdata[7].radio = 655360;
				
				AdjData.CALdata[8].offset = -622;
				AdjData.CALdata[8].radio = 558;
				AdjData.CALdata[9].offset = -1;
				AdjData.CALdata[9].radio = -1;
				AdjData.CALdata[10].offset = -1;
				AdjData.CALdata[10].radio = -1;
				AdjData.CALdata[11].offset = -1;
				AdjData.CALdata[11].radio = -1;
				
				AdjData.CALdata[12].offset = -1;
				AdjData.CALdata[12].radio = -1;
				AdjData.CALdata[13].offset = 2851;
				AdjData.CALdata[13].radio = 247;
				AdjData.CALdata[14].offset = -1;
				AdjData.CALdata[14].radio = -1;
				AdjData.CALdata[15].offset = -1;
				AdjData.CALdata[15].radio = -1;
				//pwM
				AdjData.CALdata[16].offset = 14582;
				AdjData.CALdata[16].radio = 404;
				AdjData.CALdata[17].offset = 420;
				AdjData.CALdata[17].radio = 589;
				AdjData.CALdata[18].offset = 302;
				AdjData.CALdata[18].radio = 648;
				AdjData.CALdata[19].offset = -1;
				AdjData.CALdata[19].radio = -1;
			}
		}
		
	}
}


void funRptInit(void);
void funDataInit(void);

void funConfig_Init(void)
{
	uint8_t i;
	for(i = 0; i < 64; i++)
	{
		drvFramReadConfig(i, &SysData.ConfigData[i]);
	}
//	if(drvFramReadConfig(Cfg_SwitchType, &SysData.ConfigData[Cfg_SwitchType]) == 0)
//	{
//		SysData.ConfigData[Cfg_SwitchType] =  SwitchType_Motor;//�������ͺ�
//	}
//	
//	if(drvFramReadConfig(Cfg_SubDevNum, &SysData.ConfigData[Cfg_SubDevNum]) == 0)
//	{
//		SysData.ConfigData[Cfg_SubDevNum] =  1;	//���豸���������
//	}
//	
//	if(drvFramReadConfig(Cfg_SubVoltRatio, &SysData.ConfigData[Cfg_SubVoltRatio]) == 0)
//	{
//		SysData.ConfigData[Cfg_SubVoltRatio] = 12;	//���ѹ
//	}
//	
//	if(drvFramReadConfig(Cfg_SubAHRatio, &SysData.ConfigData[Cfg_SubAHRatio]) == 0)
//	{
//		SysData.ConfigData[Cfg_SubAHRatio] = 10;	//�����
//	}
//	
//	if(drvFramReadConfig(Cfg_Addr, &SysData.ConfigData[Cfg_Addr]) == 0)
//	{
//		SysData.ConfigData[Cfg_Addr] =  1;//����ͨ�ŵ�ַ
//	}
//	
//	if(drvFramReadConfig(Cfg_Band, &SysData.ConfigData[Cfg_Band]) == 0)
//	{
//		SysData.ConfigData[Cfg_Band] =  9600;//������
//	}
//	
//	if(drvFramReadConfig(Cfg_Par, &SysData.ConfigData[Cfg_Par]) == 0)
//	{
//		SysData.ConfigData[Cfg_Par] =  0;//У��λ
//	}
//	
//	if(drvFramReadConfig(Cfg_CellVoltTopLimit, &SysData.ConfigData[Cfg_CellVoltTopLimit]) == 0)
//	{
//		SysData.ConfigData[Cfg_CellVoltTopLimit] =  13800;//��������ѹ
//	}
//	
//	if(drvFramReadConfig(Cfg_CellVoltLowLimit, &SysData.ConfigData[Cfg_CellVoltLowLimit]) == 0)
//	{
//		SysData.ConfigData[Cfg_CellVoltLowLimit] =  10800;//�ŵ������ѹ
//	}
	
	funRptInit();
	
	//
	funDataInit();
	
}

void BSP_RTC_Init(void);
void drvFram_Init(void);

void drvBSP_Init(void)
{
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC
                         | RCC_AHB1Periph_GPIOD | RCC_AHB1Periph_GPIOE, ENABLE); 

	BSP_RTC_Init();
	drvFram_Init();
//	drvFramRead(ADJ_Save_Addr, (uint8_t *)&AdjData, sizeof(ADJ_STRUCT));
	funADC_Cal_Init();
	
  drvBSP_GPIO_Init();
	
  drvDAC_PWM_Init();		
	drvAI_Init();
	
}




void drvBSP_task(void)
{
}


void drvBSP_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;  

	
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  //GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  
  //DI
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;      //RELAY ON/OFF IN
  GPIO_Init(GPIOE, &GPIO_InitStructure);     
  
	
	
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;      //FAN_ERR
//  GPIO_Init(GPIOC, &GPIO_InitStructure);  
  
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
//  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2
//                                 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;        //ADDR0~5
//  GPIO_Init(GPIOE, &GPIO_InitStructure);     
  
  //DO
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;     //RELAY ON/OFF OUT
  GPIO_ResetBits(GPIOD, GPIO_InitStructure.GPIO_Pin);
  GPIO_Init(GPIOD, &GPIO_InitStructure);  
  
	GPIO_SetBits(GPIOE, GPIO_InitStructure.GPIO_Pin);		//H�ر�BUS��Դ���
  GPIO_Init(GPIOE, &GPIO_InitStructure);      //PE12,PE15 PWR CTRL

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 ;     //ADDR _EN/next
  GPIO_SetBits(GPIOD, GPIO_InitStructure.GPIO_Pin);
  GPIO_Init(GPIOD, &GPIO_InitStructure);
}




uint16_t PWM_Set[DAC_ChannelNum];
int16_t testdat, cha;







#define PWM_Step	50
void drvBSP_PWMtask(void)
{  
  uint16_t i;
  
  for(i = 0 ;i < DAC_ChannelNum ; i++)
  {
    if(PWM_Set[i] > drvPWM_Value[i])
    {
      if(PWM_Set[i] > (drvPWM_Value[i] + PWM_Step))
      {
        drvPWM_Value[i] += PWM_Step;
      }
      else
      {
        drvPWM_Value[i] = PWM_Set[i];
      }
      //drvBSP_PWMout(i,drvPWM_Value[i] );
    }
    else if(PWM_Set[i] < drvPWM_Value[i])
    {
      if((PWM_Set[i] + PWM_Step) < drvPWM_Value[i])
      {
        drvPWM_Value[i] -= PWM_Step;
      }
      else
      {
        drvPWM_Value[i] = PWM_Set[i];
      }      
      //drvBSP_PWMout(i,drvPWM_Value[i] );
    }
		drvBSP_PWMout(i,drvPWM_Value[i] );
  }

}
int16_t drvBSP_PWMGet(uint8_t ch)
{
  if(ch >= DAC_ChannelNum)
  {
    return 0;
  }
      
  return (int16_t)drvPWM_Value[ch];
}
void drvBSP_PWMout(uint8_t ch, uint16_t dat)
{  
  int16_t sPWMN,sPWMS;
  if((ch >= DAC_ChannelNum) && (dat > PWM_CYC))
  {
    return ;
  } 
  if(ch == PWM_OutIqB)
  {
    sPWMS = drvPWM_Value[ch];
		//sPWMS = PWM_CYC - 1 - drvPWM_Value[ch];
  }
  else
  {
    sPWMS = PWM_CYC - 1 - drvPWM_Value[ch];
  }
  if(sPWMS < 0)
  {
    sPWMS = 0;
  }else if(sPWMS >= PWM_CYC)
  {
    sPWMS = PWM_CYC - 1;
  }
  switch(ch)
  {
  case PWM_OutVC:
    sPWMN = TIM_GetCapture1(TIM1);
    if(sPWMN != sPWMS)
    {
      TIM_SetCompare1(TIM1, sPWMS);
    }
    break;
  case PWM_OutIC:
    sPWMN = TIM_GetCapture2(TIM1);
    if(sPWMN != sPWMS)
    {
      TIM_SetCompare2(TIM1, sPWMS);
    }
    break;
  case PWM_OutVL:
    sPWMN = TIM_GetCapture3(TIM1);
    if(sPWMN != sPWMS)
    {
      TIM_SetCompare3(TIM1, sPWMS);
    }
    break;
  case PWM_OutIL:
    sPWMN = TIM_GetCapture4(TIM1);
    if(sPWMN != sPWMS)
    {
      TIM_SetCompare4(TIM1, sPWMS);
    }
    break;
  case PWM_OutVB:    
    sPWMN = TIM_GetCapture1(TIM4);
    if(sPWMN != sPWMS)
    {
      TIM_SetCompare1(TIM4, sPWMS);
    }
    break;
  case PWM_OutIB: 
    sPWMN = TIM_GetCapture2(TIM4);
    if(sPWMN != sPWMS)
    {
      TIM_SetCompare2(TIM4, sPWMS);
    }
    break;    
  case PWM_OutIqL: 
    sPWMN = TIM_GetCapture3(TIM4);
    if(sPWMN != sPWMS)
    {
      TIM_SetCompare3(TIM4, sPWMS);
    }
    break;
  case PWM_OutIqB: 
    sPWMN = TIM_GetCapture4(TIM4);
    if(sPWMN != sPWMS)
    {
      TIM_SetCompare4(TIM4, sPWMS);
    }
    break;
  case PWM_FAN: 
    sPWMN = TIM_GetCapture2(TIM9);
    if(sPWMN != sPWMS)
    {
      TIM_SetCompare2(TIM9, sPWMS);
    }
    break;
  }
}


//void drvBSP_LedSeg(uint8_t dat)
//{  
//  
//  GPIO_ResetBits(GPIOD, 0xFF);
//  if(dat != 0)
//  {
//    GPIO_SetBits(GPIOD, dat);
//  }
//}
//void drvBSP_LedCom(uint8_t dat)
//{  
//  switch(dat)
//  {
//  case 0:       //�ر�����
//    GPIO_ResetBits(GPIOB, GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_8 | GPIO_Pin_9);
//    break;
//  case 1:       //COM0
//    GPIO_SetBits(GPIOB, GPIO_Pin_3);
//    break;
//  case 2:       //COM0
//    GPIO_SetBits(GPIOB, GPIO_Pin_4);
//    break;
//  case 3:       //COM0
//    GPIO_SetBits(GPIOB, GPIO_Pin_5);
//    break;
//  case 4:       //COM0
//    GPIO_SetBits(GPIOB, GPIO_Pin_8);
//    break;
//  case 5:       //COM0
//    GPIO_SetBits(GPIOB, GPIO_Pin_9);
//    break;
//  }
//}



//uint16_t drvBSP_CtrlIoSts = 0;
//uint8_t drvBSP_CtrlIO_Sts(uint8_t io)
//{
//  if((drvBSP_CtrlIoSts & io) != 0)
//  {
//    return 1;
//  }
//  return 0;
//}

//void drvBSP_CtrlIO_ON(uint8_t io)
//{
//  switch(io)
//  {
//    //�е����
//    case bspCtrlIO_RlyLin:
//      GPIO_SetBits(GPIOB,GPIO_Pin_10);
//      drvBSP_CtrlIoSts |= bspCtrlIO_RlyLin;
//      break;
//    case bspCtrlIO_PFCLin:
//      GPIO_ResetBits(GPIOB,GPIO_Pin_2);
//      drvBSP_CtrlIoSts |= bspCtrlIO_PFCLin;
//      break;
//    case bspCtrlIO_OutLin:
//      GPIO_ResetBits(GPIOE,GPIO_Pin_7);
//      drvBSP_CtrlIoSts |= bspCtrlIO_OutLin;
//      break;
//     //��ؿ���      
//    case bspCtrlIO_RlyBat:
//      GPIO_SetBits(GPIOB,GPIO_Pin_11);
//      drvBSP_CtrlIoSts |= bspCtrlIO_RlyBat;
//      break;   
//    case bspCtrlIO_CHGBat:
//      GPIO_ResetBits(GPIOE,GPIO_Pin_10);
//      drvBSP_CtrlIoSts |= bspCtrlIO_CHGBat;
//      break;   
//    case bspCtrlIO_OutBat:
//      GPIO_ResetBits(GPIOE,GPIO_Pin_8);
//      drvBSP_CtrlIoSts |= bspCtrlIO_OutBat;
//      break;
//  }
//}

//void drvBSP_CtrlIO_OFF(uint8_t io)
//{
//  switch(io)
//  {
//    case bspCtrlIO_RlyLin:
//      GPIO_ResetBits(GPIOB,GPIO_Pin_10);
//      drvBSP_CtrlIoSts &= ~bspCtrlIO_RlyLin;
//      break;
//    case bspCtrlIO_PFCLin:
//      GPIO_SetBits(GPIOB,GPIO_Pin_2);
//      drvBSP_CtrlIoSts &= ~bspCtrlIO_PFCLin;
//      break;
//    case bspCtrlIO_OutLin:
//      GPIO_SetBits(GPIOE,GPIO_Pin_7);
//      drvBSP_CtrlIoSts &= ~bspCtrlIO_OutLin;
//      break;
//     //��ؿ���      
//    case bspCtrlIO_RlyBat:
//      GPIO_ResetBits(GPIOB,GPIO_Pin_11);
//      drvBSP_CtrlIoSts &= ~bspCtrlIO_RlyBat;
//      break;   
//    case bspCtrlIO_CHGBat:
//      GPIO_SetBits(GPIOE,GPIO_Pin_10);
//      drvBSP_CtrlIoSts &= ~bspCtrlIO_CHGBat;
//      break;   
//    case bspCtrlIO_OutBat:
//      GPIO_SetBits(GPIOE,GPIO_Pin_8);
//      drvBSP_CtrlIoSts &= ~bspCtrlIO_OutBat;
//      break;
//  }
//}










//#define ADC_Cnl_VChg    0
//#define ADC_Cnl_IChg    1
//#define ADC_Cnl_VlineOut        2
//#define ADC_Cnl_IlineOut        3
//#define ADC_Cnl_VBatOut 4
//#define ADC_Cnl_IBatOut 5
//#define ADC_Cnl_VBat    6
//#define ADC_Cnl_IBat    7
//#define ADC_Cnl_Vac     8
////10,11,NONE, 9-AC_0
//#define ADC_Cnl_Tbat    12
//#define ADC_Cnl_Fan     13
//#define ADC_Cnl_T1      14
//#define ADC_Cnl_T2      15
//
//#define PWM_OutVC       0       //����ѹ����
//#define PWM_OutIC       1       //����������
//
//#define PWM_OutV2       2       //�е������ѹ����
//#define PWM_OutI2       3       //�е������������
//
//#define PWM_OutV3       4       //����
//#define PWM_OutI3       5       //����
//
//#define PWM_OutIq1      6       //�е��������
//#define PWM_OutIq2      7       //����������
//
//#define PWM_FAN         8       //����ת�ٿ���



#define RTC_Check 0x55AA5A5A


#define RTC_CheckReg 	RTC_BKP_DR0
#define RTC_SohReg		RTC_BKP_DR1
#define RTC_StartReg		RTC_BKP_DR2
#define RTC_EndReg		RTC_BKP_DR3
#define RTC_ResLastTimeH RTC_BKP_DR9
#define RTC_ResLastTimeL RTC_BKP_DR10
#define RTC_ActLastTimeH RTC_BKP_DR11
#define RTC_ActLastTimeL RTC_BKP_DR12




void BSP_RTC_Init(void)
{
  RTC_InitTypeDef  RTC_InitStructure;
  RTC_TimeTypeDef  RTC_TimeStruct;
  RTC_DateTypeDef  RTC_DateStruct;
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
  PWR_BackupAccessCmd(ENABLE);  //��������RTC BKP
  
  if(RTC_ReadBackupRegister(RTC_CheckReg) != RTC_Check)
  {  
    /* Enable the LSE OSC */
    RCC_LSEConfig(RCC_LSE_ON);

    /* Wait till LSE is ready */  
    while(RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
    {
    }

    /* Select the RTC Clock Source */
    RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
    
    /* Configure the RTC data register and RTC prescaler */
    /* ck_spre(1Hz) = RTCCLK(LSI) /(AsynchPrediv + 1)*(SynchPrediv + 1)*/
    RTC_InitStructure.RTC_AsynchPrediv = 0x7F;
    RTC_InitStructure.RTC_SynchPrediv  = 0xFF;
    RTC_InitStructure.RTC_HourFormat   = RTC_HourFormat_24;
    RTC_Init(&RTC_InitStructure);
    
    /* Set the time to 00h 00mn 00s AM */
    RTC_TimeStruct.RTC_H12     = RTC_H12_AM;
    RTC_TimeStruct.RTC_Hours   = 0;
    RTC_TimeStruct.RTC_Minutes = 0;
    RTC_TimeStruct.RTC_Seconds = 0;  
    RTC_SetTime(RTC_Format_BIN, &RTC_TimeStruct);
    
    RTC_DateStruct.RTC_WeekDay     = RTC_Weekday_Monday;
    RTC_DateStruct.RTC_Month   = 1;
    RTC_DateStruct.RTC_Date = 1;
    RTC_DateStruct.RTC_Year = 15;  
    RTC_SetDate(RTC_Format_BIN, &RTC_DateStruct);
    
    /* Enable the RTC Clock */
    RCC_RTCCLKCmd(ENABLE);

    /* Wait for RTC APB registers synchronisation */
    RTC_WaitForSynchro();

    /* Write to the first RTC Backup Data Register */
    RTC_WriteBackupRegister(RTC_CheckReg, RTC_Check);
  }
}








int8_t BSP_SOH_Read(void)
{
	uint32_t dat;
	int16_t dat16;
	dat = RTC_ReadBackupRegister(RTC_SohReg) ;
	
	dat16 = (dat >> 16) & 0xFFFF;
	
	dat16 ^= (dat & 0xFFFF);
	if(dat16 == (int16_t)0xFFFF)
	{
		dat16 = dat & 0xFFFF;
		if((dat16 > 100)
			|| (dat16 < 0))
		{
			dat16 = 100;
		}
	}
	else
	{
		dat16 = 100;
	}
	return (int8_t)dat16;
}

int8_t BSP_SOH_Write(int8_t soh)
{
	uint32_t dat;
	int16_t dat16;
	
	dat16 = soh;
	dat16 ^= 0xFFFF;
	dat = (uint32_t)dat16 << 16;
	dat |= soh;
	
	PWR_BackupAccessCmd(ENABLE);
	RTC_WriteBackupRegister(RTC_SohReg, dat);	
	return soh;
}




uint32_t bspLoadLastTime(uint8_t ch, uint32_t *dt)
{
	uint32_t dtH, dtL;
	uint16_t usH, usL;
  //*dt = RTC_ReadBackupRegister(RTC_ActLastTimeH);
	if(ch == 0)
	{
		dtH = RTC_ReadBackupRegister(RTC_ActLastTimeH);
		dtL = RTC_ReadBackupRegister(RTC_ActLastTimeL);
	}
	else
	{
		dtH = RTC_ReadBackupRegister(RTC_ResLastTimeH);
		dtL = RTC_ReadBackupRegister(RTC_ResLastTimeL);
	}
	usH = (dtH >> 16) & 0xFFFF;
	usL = (dtL >> 16) & 0xFFFF;
	
	dtH &= 0xFFFF;
	dtL &= 0xFFFF;
	
	if(((usH ^ dtH) == 0xFFFF)
		&& ((usL ^ dtL) == 0xFFFF))
	{
		*dt = (dtH << 16) | dtL;
		return 1;
	}
	*dt = 0;
  return 0;
}
//difftime

uint32_t bspSaveLastTime(uint8_t ch, uint32_t *dt)
{ 
	uint32_t dtH, dtL;
	uint16_t usH, usL; 
	
	dtH = (*dt >> 16) & 0xFFFF;
	dtL = *dt & 0xFFFF;
	
	usH = 0xFFFF - dtH;
	usL = 0xFFFF - dtL;
	
	dtH |= usH << 16;
	dtL |= usL << 16;
	if(ch == 0)
	{
		RTC_WriteBackupRegister(RTC_ActLastTimeH,dtH);
		RTC_WriteBackupRegister(RTC_ActLastTimeL,dtL);
	}
	else
	{
		RTC_WriteBackupRegister(RTC_ResLastTimeH,dtH);
		RTC_WriteBackupRegister(RTC_ResLastTimeL,dtL);
	}
//  uint32_t itemp;
//  itemp = (dt->Year << 16) | (dt->Mon << 16) | dt->Day;
//  RTC_WriteBackupRegister(ActLastTimeH,itemp);
//  
//  itemp = (dt->Hour << 16) | (dt->Min << 16) | dt->Sec;
//  RTC_WriteBackupRegister(ActLastTimeL,itemp);
  return 1;
}

uint32_t bspSetDateTime(DateTimeStruct *dt)
{
  RTC_TimeTypeDef  RTC_Time;
  RTC_DateTypeDef  RTC_Date;


  RTC_Date.RTC_Year = dt->Year;
  RTC_Date.RTC_Month = dt->Mon;
  RTC_Date.RTC_Date = dt->Day;

  RTC_Time.RTC_Hours  = dt->Hour;
  RTC_Time.RTC_Minutes = dt->Min;
  RTC_Time.RTC_Seconds = dt->Sec;

  RTC_SetTime(RTC_Format_BIN, &RTC_Time);
  RTC_SetDate(RTC_Format_BIN, &RTC_Date);
	
  return 1;
}




uint8_t BCDtoHex(uint8_t bcd)
{
	uint8_t hex;
	hex = (bcd >> 4) & 0x0F;
	hex *= 10;
	hex += bcd & 0x0F;
	return hex;
}
uint32_t bspGetDateTime(DateTimeStruct *dt)
{
	uint32_t date, time;
	uint8_t date_temp;
	
	time = RTC->TR;
	date = RTC->DR;
	if(time != RTC->TR)	//ʱ�䷢���˱仯
	{//�ٶ�һ��
		time = RTC->TR;
		date = RTC->DR;
	}	
	date_temp = (date >> 20) & 0x0F;
	date_temp *= 10;
	
  dt->Year = BCDtoHex((date >> 16) & 0xFF);
  dt->Mon = BCDtoHex((date >> 8) & 0x1F);
  dt->Day = BCDtoHex(date & 0x3F);

  dt->Hour = BCDtoHex((time >> 16) & 0x3F);
  dt->Min = BCDtoHex((time >> 8) & 0x7F);
  dt->Sec = BCDtoHex(time & 0x7F);

	if(time & 0x00400000)
	{
		dt->Hour  += 12;
	}
	

  return 1;
}



//int8_t  bspADJSave(uint8_t *buf, uint16_t len)
//{
//  uint16_t i;
//  FLASH_Unlock();
//  
//  FLASH_EraseSector(FLASH_Sector_1, VoltageRange_3);
//  
//  for(i = 0; i < len; i++)
//  {
//    FLASH_ProgramByte(AdjCfgAddr + i, *buf++);
//  }
//  
//  FLASH_Lock();
//  return 0;
//}

//
//int8_t  bspADJLoad(uint8_t *buf, uint16_t len)
//{
//  uint16_t i;  
//  uint8_t *src;
//  src = (uint8_t *)AdjCfgAddr;
//  for(i = 0; i < len; i++)
//  {
//    *buf++ = *src++;
//  }
//  return 0;
//}
//




//static inline unsigned long mymktime (
//	unsigned int year, unsigned int mon,
//	unsigned int day, unsigned int hour,
//	unsigned int min, unsigned int sec)
//{
//	if (0 >= (int) (mon -= 2)) 
//	{ /* 1..12 -> 11,12,1..10 */
//		mon += 12; /* Puts Feb last since it has leap day */
//		year -= 1;
//	}

//return (((
//(unsigned long) (year/4 - year/100 + year/400 + 367*mon/12 + day) +
//year*365 - 719499
//)*24 + hour /* now have hours */
//)*60 + min /* now have minutes */
//)*60 + sec; /* finally seconds */
//}



