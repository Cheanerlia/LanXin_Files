

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"

#include "stm32f4xx.h"
#include "uarts.h"
//#include "main.h"


static uint8_t USART1_TxBuf[USARTalldat_TxMax];
static uint8_t USART1_RxBuf[USARTalldat_RxMax];

static uint8_t USART2_TxBuf[USARTsam_TxMax];
static uint8_t USART2_RxBuf[USARTsam_RxMax];

static uint8_t USART3_TxBuf[USARTusb_TxMax];
static uint8_t USART3_RxBuf[USARTusb_RxMax];

static uint8_t USART4_TxBuf[USARTdef_TxMax];
static uint8_t USART4_RxBuf[USARTdef_RxMax];

static uint8_t USART5_TxBuf[USARTdef_TxMax];
static uint8_t USART5_RxBuf[USARTdef_RxMax];

static uint8_t USART6_TxBuf[USARTalldat_TxMax];
static uint8_t USART6_RxBuf[USARTalldat_RxMax];


USART_STRUCT USART[8];

/* ------------------------------------------------------------------
**
**USARTx
------------------------------------------------------------------*/
void USARTx_Init(uint32_t serial, uint32_t BaudRate,uint32_t Parity)//USART_Parity_No
{
  GPIO_InitTypeDef GPIO_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  USART_InitTypeDef USART_InitStructure;
  if(serial >= 7)
  {
    return;
  }
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC
                         | RCC_AHB1Periph_GPIOD | RCC_AHB1Periph_GPIOE, ENABLE);  
  
  
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  //GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  switch(serial)
  {
  case 0:    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    USART[serial].USART = USART1;
    USART[serial].Txbuf = USART1_TxBuf;
    USART[serial].Rxbuf = USART1_RxBuf;
    USART[serial].TxMax = sizeof(USART1_TxBuf);
    USART[serial].RxMax = sizeof(USART1_RxBuf);
    
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_Init(&NVIC_InitStructure);    
    
    /* Configure pins as AF pushpull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
    GPIO_Init(GPIOA, &GPIO_InitStructure);     
    
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);    
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1); 
    break;
  case 1:
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
    USART[serial].USART = USART2;
    USART[serial].Txbuf = USART2_TxBuf;
    USART[serial].Rxbuf = USART2_RxBuf;
    USART[serial].TxMax = sizeof(USART2_TxBuf);
    USART[serial].RxMax = sizeof(USART2_RxBuf);
    
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_Init(&NVIC_InitStructure);    
    
    /* Configure pins as AF pushpull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_Init(GPIOA, &GPIO_InitStructure);     
    
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);    
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2); 
    break;
  case 2:
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
    USART[serial].USART = USART3;
    USART[serial].Txbuf = USART3_TxBuf;
    USART[serial].Rxbuf = USART3_RxBuf;
    USART[serial].TxMax = sizeof(USART3_TxBuf);
    USART[serial].RxMax = sizeof(USART3_RxBuf);
    
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
    NVIC_Init(&NVIC_InitStructure);    
    
    /* Configure pins as AF pushpull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_Init(GPIOB, &GPIO_InitStructure);     
    
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3);    
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3); 
    break;
  case 3:
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
    USART[serial].USART = UART4;
    USART[serial].Txbuf = USART4_TxBuf;
    USART[serial].Rxbuf = USART4_RxBuf;
    USART[serial].TxMax = sizeof(USART4_TxBuf);
    USART[serial].RxMax = sizeof(USART4_RxBuf);
    
    NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
    NVIC_Init(&NVIC_InitStructure);    
    
    /* Configure pins as AF pushpull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_Init(GPIOC, &GPIO_InitStructure);     
    
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_UART4);    
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_UART4); 
    break;
  case 4:
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
    USART[serial].USART = UART5;
    USART[serial].Txbuf = USART5_TxBuf;
    USART[serial].Rxbuf = USART5_RxBuf;
    USART[serial].TxMax = sizeof(USART5_TxBuf);
    USART[serial].RxMax = sizeof(USART5_RxBuf);
    
    NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
    NVIC_Init(&NVIC_InitStructure);    
    
    /* Configure pins as AF pushpull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_Init(GPIOC, &GPIO_InitStructure);     
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_Init(GPIOD, &GPIO_InitStructure);     
    
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource12, GPIO_AF_UART5);    
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource2, GPIO_AF_UART5); 
    break;
  case 5:
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6, ENABLE);
    USART[serial].USART = USART6;
    USART[serial].Txbuf = USART6_TxBuf;
    USART[serial].Rxbuf = USART6_RxBuf;
    USART[serial].TxMax = sizeof(USART6_TxBuf);
    USART[serial].RxMax = sizeof(USART6_RxBuf);
    
    NVIC_InitStructure.NVIC_IRQChannel = USART6_IRQn;
    NVIC_Init(&NVIC_InitStructure);    
    
    /* Configure pins as AF pushpull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_Init(GPIOC, &GPIO_InitStructure);     
    
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource6, GPIO_AF_USART6);    
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource7, GPIO_AF_USART6); 
    break;

  }

  USART_InitStructure.USART_BaudRate = BaudRate;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = Parity;   //USART_Parity_No  
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USART[serial].USART, &USART_InitStructure);
	
  USART_ITConfig(USART[serial].USART, USART_IT_RXNE, ENABLE);
  USART_Cmd(USART[serial].USART, ENABLE);
}



uint16_t USARTx_Send(uint32_t serial,uint8_t *buf,uint16_t len)
{
  uint16_t i;
  if(USART[serial].TxFlag != 0)
  {
    return 0;
  }
  if(len > USART[serial].TxMax)
  {
    return 0;
  }
  USART[serial].TxPoint = USART[serial].Txbuf;
  for(i = 0; i < len; i++)
  {    
    *USART[serial].TxPoint++ = *buf++;
  }
  USART[serial].TxPoint = USART[serial].Txbuf;
  USART[serial].TxLen = len;
  if(USART[serial].TxLen > 0)
  {
    USART[serial].TxFlag |= 1;
    USART_ITConfig(USART[serial].USART, USART_IT_TXE, ENABLE);
  }
  return len;
}
uint16_t USARTx_Rec(uint32_t serial,uint8_t *buf,uint16_t len)
{
  uint16_t i,relen;
  if(USART[serial].RxLen == 0)
  {
    return 0;
  }
  //���ж�
  USART_ITConfig(USART[serial].USART, USART_IT_RXNE, DISABLE);
  if(USART[serial].RxLen > len)   //����ȶ�ȡ��
  {//��ȡ��������
    for(i = 0 ; i < len; i++)
    {
      buf[i] = USART[serial].Rxbuf[i];
    }
    for(i = len ; i < USART[serial].RxLen; i++)
    {
      USART[serial].Rxbuf[i - len] = USART[serial].Rxbuf[i];
    }
    relen = len;
    USART[serial].RxLen   -= len;
  }
  else
  {//��ȡȫ������
    for(i = 0; i < USART[serial].RxLen; i++)
    {
      buf[i] = USART[serial].Rxbuf[i];
    }
    relen = USART[serial].RxLen;
    USART[serial].RxLen = 0;
  }
  //���ж�
  USART_ITConfig(USART[serial].USART, USART_IT_RXNE, ENABLE);
  return relen;
}



void USARTx_IRQHandler(uint32_t serial)
{
  __IO static uint8_t rxTemp;
  if(USART_GetITStatus(USART[serial].USART, USART_IT_TXE) == SET)
  {
//    USART_ClearFlag(USART[serial].USART, USART_IT_TXE);
//    USART_ClearITPendingBit(USART[serial].USART, USART_IT_TXE);
    if(USART[serial].TxLen > 0)
    {
      USART_SendData(USART[serial].USART,*USART[serial].TxPoint++);
      USART[serial].TxLen--;
    }
    if(USART[serial].TxLen == 0)
    {
      USART[serial].TxFlag = 0;
      USART_ITConfig(USART[serial].USART, USART_IT_TXE, DISABLE);
      //USART_ClearITPendingBit(USART[serial].USART, USART_IT_TXE);
    }    
  }
  else if(USART_GetITStatus(USART[serial].USART, USART_IT_RXNE) == SET)
  {
    //USART_ClearFlag(USART[serial].USART, USART_IT_RXNE);
//    USART_ClearITPendingBit(USART[serial].USART, USART_IT_RXNE);
    if(USART[serial].RxLen < USART[serial].RxMax)
    {      
      USART[serial].RxTick = xTaskGetTickCount();
      USART[serial].Rxbuf[USART[serial].RxLen++] = USART_ReceiveData(USART[serial].USART);
    }
    else
    {
      rxTemp = USART_ReceiveData(USART[serial].USART);
    }
  }
  else
  {
    //USART_ClearFlag(USART[serial].USART, USART_IT_TXE);
    //USART_ClearITPendingBit(USART[serial].USART, USART_IT_TXE);
    //USART_ClearFlag(USART[serial].USART, USART_IT_RXNE);
    //USART_ClearITPendingBit(USART[serial].USART, USART_IT_RXNE);
    //USART_ClearFlag(USART[serial].USART, USART_IT_ORE);
    //USART_ClearITPendingBit(USART[serial].USART, USART_IT_ORE);
    rxTemp = USART_ReceiveData(USART[serial].USART);
  }
}


void USART1_IRQHandler(void)
{
  USARTx_IRQHandler(0);
}

void USART2_IRQHandler(void)
{
  USARTx_IRQHandler(1);
}

void USART3_IRQHandler(void)
{
  USARTx_IRQHandler(2);
}

void UART4_IRQHandler(void)
{
  USARTx_IRQHandler(3);
}

void UART5_IRQHandler(void)
{
  USARTx_IRQHandler(4);
}

void USART6_IRQHandler(void)
{
  USARTx_IRQHandler(5);
}

void UART7_IRQHandler(void)
{
  USARTx_IRQHandler(6);
}











