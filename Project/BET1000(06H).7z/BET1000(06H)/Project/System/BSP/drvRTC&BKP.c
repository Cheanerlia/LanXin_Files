
#include "stm32f4xx.h"

#define RTC_CheckValue	0x55AA55AA


void RTC_Confingure(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
	PWR_BackupAccessCmd(ENABLE);
	RCC_LSICmd(ENABLE);
	
	{
		RCC_LSEConfig(RCC_LSE_ON);
		/* Wait till LSE is ready */  
		while(RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
		{
		}
		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
		RCC_RTCCLKCmd(ENABLE);
		
		RTC_WaitForSynchro();
		RTC_WriteBackupRegister(RTC_BKP_DR0, RTC_CheckValue);
		
		
		  /* Set the Time */
  RTC_TimeStructure.RTC_Hours   = 0x08;
  RTC_TimeStructure.RTC_Minutes = 0x00;
  RTC_TimeStructure.RTC_Seconds = 0x00;

  /* Set the Date */
  RTC_DateStructure.RTC_Month = RTC_Month_January;
  RTC_DateStructure.RTC_Date = 0x11;  
  RTC_DateStructure.RTC_Year = 0x13; 
  RTC_DateStructure.RTC_WeekDay = RTC_Weekday_Friday; 

  /* Calendar Configuration */
  RTC_InitStructure.RTC_AsynchPrediv = uwAsynchPrediv;
  RTC_InitStructure.RTC_SynchPrediv =  uwSynchPrediv;
  RTC_InitStructure.RTC_HourFormat = RTC_HourFormat_24;
  RTC_Init(&RTC_InitStructure);
  
  /* Set Current Time and Date */
  RTC_SetTime(RTC_Format_BCD, &RTC_TimeStructure);  
  RTC_SetDate(RTC_Format_BCD, &RTC_DateStructure); 
	
	
	  /* Enable BKPRAM Clock */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_BKPSRAM, ENABLE);
	}
}
void RTC_Set(void)
{
}