#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"
#include "sys.h"
#include "configure.h"
#include "BSP.h"
#include <string.h>
#include "stmflash.h"

__IO   ADJ_STRUCT   AdjData;



uint32_t WDG_Tick, StartTick, RUN_Tick;

void drvBSP_Init(void);

TaskHandle_t ComTaskHandle;
TaskHandle_t BSPTaskHandle;

TaskHandle_t ControlTaskHandle;

void tskCom(void * argument);
void tskBSP(void const * argument);
void tskControl(void *pvParameters);

void funData(void);
void funMode(void);
extern uint8_t drvAI_Finish;
void funADC_Cal(int16_t *iValue, int32_t *iData);
void drvWDG_reload(void);
void RUN_LED(void);
void funLED(void);
void funSubInit(void);


void threadMain(void *pvParameters)
{
	  //u8  Flag1 = 0;
		
		drvBSP_Init();
		
		funConfig_Init();//����洢��������ó�ʼ��
		
		xTaskCreate(tskCom, "Task Com", 256, NULL, 2, &ComTaskHandle);
		
		xTaskCreate(tskControl, "thread Control", 256, NULL, 5, &ControlTaskHandle);
	 
		/* 
	  #if (defined BIMS)//0
		xTaskCreate(threadHMI,"Task HMI",256,NULL,3,&HMITaskHandle); 
		xTaskCreate(threadSPIF,"Task SPI FLASH",256,NULL,4,&SPIFTaskHandle); 
	  #endif	
		*/
		
		StartTick = xTaskGetTickCount();
		funSubInit();

		for(;;)
		{		
				if((xTaskGetTickCount() - WDG_Tick) >= 500)//500MS  1HZƵ��
				{
						WDG_Tick = xTaskGetTickCount();
						drvWDG_reload();//ι������
				}	
				
				if((xTaskGetTickCount() - RUN_Tick) >= 200)//200MS  ����ָʾ��200MS������˸
				{
						RUN_Tick = xTaskGetTickCount();
					  RUN_LED();
				}
				
				if(drvAI_Finish)
				{
						drvAI_Finish = 0;
						funADC_Cal(SysData.iAI_Value, drvADC_Value);//����16·AD����ֵ,������SysData.iAI_Value
						funData();                                  //�����ص�ѹ����ص������Լ�4·�¶ȡ��������ֵ
				}	
				
				if(SysData.RunSts & RunSts_Init)
				{
						if((xTaskGetTickCount() - StartTick) >= 5000)//5S,����ʱ��Ϊ5��
						{
							  SysData.RunSts &= ~RunSts_Init;
						}
				}					
				else if(SysData.RunSts & RunSts_Adj)	//У׼
				{
					
				}
				else	//����ģʽ
				{
					  funMode();
				}				
				
				vTaskDelay(5/portTICK_RATE_MS);//5MS
		}
}



int64_t ADC_CAL_Ltemp;
void funADC_Cal(int16_t *iValue, int32_t *iData)//AD��������У׼
{
		int8_t i;
	
		for(i = 0; i < ADC_ChannelNum; i++)//16
		{
				ADC_CAL_Ltemp = drvADC_Value[i] + AdjData.CALdata[i].offset;
				ADC_CAL_Ltemp *= ADC_RADIO;//256
				ADC_CAL_Ltemp /= AdjData.CALdata[i].radio;//655360
			
				if(ADC_CAL_Ltemp > 32767)      {ADC_CAL_Ltemp =  32767;}//0x7FFFFFFF
				else if(ADC_CAL_Ltemp < -32767){ADC_CAL_Ltemp = -32767;}//0x80000000

				iValue[i] = ADC_CAL_Ltemp;
		}
}


int32_t drvFramWrite(uint16_t FramAddr, uint8_t *buf, int32_t len);
unsigned short Modbus_Send(unsigned char *updata, unsigned short len);

////static   ADJ_STRUCT  ADC_SaveTemp;
   ADJ_STRUCT  ADC_SaveTemp;
static   uint32_t    ADJ_Time;
////static   uint8_t     ADJ_SaveFlag;
   uint8_t     ADJ_SaveFlag;
float  AdjValue[ADC_ChannelNum + DAC_ChannelNum][4];
int32_t  iADJ_Def;
#define  ADJ_Sec   600000//600S  10MIN

uint16_t data11, data22, data33;
uint16_t no_no;

void funADC_Adj(uint16_t no,uint16_t data)//reg - 9000
{
		int32_t ch,point;
		float ftemp;
	
	  no_no = no;

		if(no == 0)//start ADJ  ����У׼ģʽ
		{
				SysData.RunSts |= RunSts_Adj;
				
				ADJ_Time = xTaskGetTickCount();
		}
		else if(no == 1)//End ADJ  �˳�У׼ģʽ
		{			
				SysData.RunSts &= ~RunSts_Adj;   //У׼ģʽ����
				SysData.RunSts &= ~RunSts_AdjRdy;//У׼׼��ģʽ����
			
				drvDAC_Out(1, 0);
				drvDAC_Out(2, 0);
				drvPWM_RES(0);
		}
		else if(((xTaskGetTickCount() - ADJ_Time) < ADJ_Sec) && ((SysData.RunSts & RunSts_Adj) != 0))//У׼ʱ�䲻�ó���10����
		{
				if(no == 2)//Read Para   ��ԭ������  У׼���ݳ�ʼ��
				{
						SysData.RunSts |= RunSts_AdjRdy;//��λУ׼׼��ģʽ
						memcpy(&ADC_SaveTemp, (uint8_t *)&AdjData, sizeof(ADJ_STRUCT));//AdjData������ADC_SaveTemp
				}
				else if((no == 3) && ((SysData.RunSts & RunSts_AdjRdy) != 0))//У׼׼��ģʽ  Save ADJ  ����У׼����
				{
						if(ADJ_SaveFlag != 0)
						{
								ADC_SaveTemp.Flag = 0xAA55;
								Modbus_Send((uint8_t *)&ADC_SaveTemp, sizeof(ADJ_STRUCT) - 2);							
								
                STMFLASH_Write(FLASH_SAVE_ADDR1, (u16 *)&ADC_SaveTemp, (sizeof(ADJ_STRUCT) / 2));//ADC_SaveTemp���ݱ������ڲ�Flash							
								
								funADC_Cal_Init();//У׼���ݿ�����AdjData��У��
							  
								ADJ_SaveFlag = 0;
						}
				}		
				else if((no >= 11) &&  (no < 100) )//9011-9100 У׼��2��
				{
					  //ȷ��ͬһͨ��������,ÿ��������noΪͬһͨ����������
						ch = no - 11;
						point = ch % 2;
						ch /= 2;
					
						if(ch < ADC_ChannelNum)//<16   У׼AD����
						{			
								if(ch == ADC_ChnlSub_VRES)//13   9037��9038
								{
										AdjValue[ch][point] = data;//�������ʵ��ֵ
									  //                                                 ����100��,��ת��Ϊ��ŷ���� 
										//AdjValue[ch][point + 2] = (drvADC_Value[ADC_ChnlSub_VRES] * 100000) / SysData.iAI_Value[ADC_ChnlSub_Volt2];//�õ���ѹ��
									  //                                                  ʵ��ֵ,��ת��Ϊ��ŷ����
                    AdjValue[ch][point + 2] = ((float)drvADC_Value[ADC_ChnlSub_VRES] * 1000) / SysData.iAI_Value[ADC_ChnlSub_Volt2];//�õ���ѹ��									
								}		
								else		
								{
										AdjValue[ch][point] = data;
										AdjValue[ch][point + 2] = drvADC_Value[ch];//�ɼ�ֵ,������16��
								}
								if(point == 1)//ÿ������,�ĸ�����У׼һ��
								{
										//����
										ftemp = AdjValue[ch][3] - AdjValue[ch][2];
										iADJ_Def = AdjValue[ch][1] - AdjValue[ch][0];//��λ�����������ֵ֮��
										ftemp *= ADC_RADIO;//256
										ADC_SaveTemp.CALdata[ch].radio = ftemp / iADJ_Def;
										
										//ƫ�Ƽ���
										ftemp = AdjValue[ch][1] *ADC_SaveTemp.CALdata[ch].radio;
										ftemp /= ADC_RADIO; 
										ADC_SaveTemp.CALdata[ch].offset  = ftemp - AdjValue[ch][3];
										ADJ_SaveFlag = 1;
								}
						}
						else if(ch < (ADC_ChannelNum + DAC_ChannelNum))//[16, 20)  У׼PWM����  ch==16,�����ѹ����У׼
						{
								AdjValue[ch][point] = data;
								AdjValue[ch][point + 2] = drvDAC_Value[ch - ADC_ChannelNum];//�ɼ�ֵ
							
								if(point == 1)
								{
										//����
										ftemp = AdjValue[ch][3] - AdjValue[ch][2];//ʵ��PWMֵ֮�� 0 - 10000
										ftemp *= ADC_RADIO; 
									
										iADJ_Def = AdjValue[ch][1] - AdjValue[ch][0];
										ADC_SaveTemp.CALdata[ch].radio = ftemp / iADJ_Def;
										
										//ƫ�Ƽ���
										ftemp = AdjValue[ch][1] * ADC_SaveTemp.CALdata[ch].radio;
										ftemp /= ADC_RADIO; 
										ADC_SaveTemp.CALdata[ch].offset  = ftemp - AdjValue[ch][3];//�������PWMֵ - ʵ��PWMֵ = PWMƫ��ֵ
										
										ADJ_SaveFlag = 1;
								}
						}
				}
				else if(no >= 101)//PWM�������
				{
						no -= 101;
						switch(no)
						{
								case 1://9102  �������ܿ���PWM
									drvDAC_Out(no, data * 10);//TIM4_CH3	 R33  25
                  data11 = 	data;							
								break;
									
								case 2://9103  ���弤�����PWM
									drvDAC_Out(no, data * 10);//TIM4_CH4  R31  50
								  data22 = 	data;
								break;
								
								case 3://9104  ����ŵ����PWM						
								  drvPWM_RES(data);         //TIM4_CH2	R32  80
                  data33 = 	data; 								
								break;
						}
				}
		}
		else
		{
			  SysData.RunSts &= ~RunSts_Adj;//����У׼
			
				drvDAC_Out(1, 0);
				drvDAC_Out(2, 0);
				drvPWM_RES(0);		
		}
}
//============================================================================================================================
// No more.
//============================================================================================================================
