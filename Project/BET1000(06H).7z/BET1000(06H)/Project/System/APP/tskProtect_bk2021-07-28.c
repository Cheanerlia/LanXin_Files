/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include "sys.h"
#include "configure.h"
#include "bspBIMS.h"
#include "protect.h"


#define Cfg_EnvOTAlarm	48	//��������
#define Cfg_EnvUTAlarm	49	//����Ƿ��

#define Cfg_ChgOCAlarm	50	//������
#define Cfg_DsgOCAlarm	51	//�ŵ����
#define Cfg_PortOTAlarm	55	//���߶��ӹ��¸澯


void AlarmAdd(uint8_t AlarmType, uint8_t cell, int16_t reaValue);
void AlarmDel(uint8_t AlarmType, uint8_t cell, int16_t reaValue);


//ACT_RPT_STRUCT ActRptList[ActRptMax]	__attribute__ ((aligned (4)));
//ACT_RPT_STRUCT ActRptList[ActRptMax]	__attribute__ ((aligned (4)));
/*********************************************************
����:0�澯�ޱ仯�� 1���¸澯�� -1���澯�ָ�
*********************************************************/
int8_t funAlarm(int in_t, int ret_t,	//������������������
							int16_t *AlarmVaue, int16_t AlarmType,
							uint32_t *InTick, uint32_t InTime, uint32_t ReTime)
{
	int16_t AlarmBit;
	if(AlarmType > 0)
	{
		AlarmBit = 1 << (AlarmType - 1);
	}
	else 
	{
		return 0;
	}
	if((*AlarmVaue & AlarmBit)	== 0)	//�޸澯
	{
		if(in_t > 0)	//�ﵽ��ֵ
		{
			if((xTaskGetTickCount() - *InTick) > InTime)	//ʱ�䵽
			{
				*InTick = xTaskGetTickCount();
				*AlarmVaue |= AlarmBit;
				return 1;	//�����澯
			}
		}
		else
		{
			*InTick = xTaskGetTickCount();
		}
	}
	else	//�и澯
	{
		if(ret_t > 0)	//�ﵽ��ֵ
		{
			if((xTaskGetTickCount() - *InTick) > ReTime)	//ʱ�䵽
			{
				*InTick = xTaskGetTickCount();
				*AlarmVaue &= ~AlarmBit;
				return -1;	//ȡ���澯
			}
		}
		else
		{
			*InTick = xTaskGetTickCount();
		}
	}
	return 0;
}

extern uint8_t ComFlag[DevSubMax];
uint8_t ComErrTimes[DevSubMax];
uint32_t ComErrTick[DevSubMax];
void funAlarmCom(void)
{
	uint8_t i, num;
	num = DevSubMax < SysData.ConfigData[Cfg_SubDevNum]? 
				DevSubMax : SysData.ConfigData[Cfg_SubDevNum];
	for(i = 0; i < num; i++)
	{
		if((ComFlag[i] & 0x0B) == 0X0B)
		{	//ͨ������
			ComErrTick[i] = xTaskGetTickCount();
			ComFlag[i] = 0;
			ComErrTimes[i] = 0;
			SysData.Sub[i].Alarm &= ~0x80;
		}
		else if((xTaskGetTickCount() - ComErrTick[i]) >= 5000)
		{	//�쳣1��
			ComErrTimes[i] ++;
			if(ComErrTimes[i] >= 5)
			{//���쳣
				SysData.Sub[i].Alarm |= 0x80;
			}
			ComErrTick[i] = xTaskGetTickCount();
			ComFlag[i] = 0;
		}
	}
	//�������
	for(i = num; i < DevSubMax; i++)
	{
		SysData.Sub[i].Alarm &= ~0x80;
	}
	//���Ӳɼ�ģ��ͨ�ű���Ӱ���ܱ���
	num = 0;
	for(i = 0; i < DevSubMax; i++)
	{
		if(SysData.Sub[i].Alarm & 0x80)
		{
			num = 1;
		}
	}	
	if(SysData.Alarm & AlarmDevErr)	//�и澯
	{
		if(num == 0)
		{
			AlarmDel(AlarmDevErr , 0, 0);
		}
	}
	else	//�޸澯
	{
		if(num != 0)
		{
			AlarmAdd(AlarmDevErr , 0, 0);
		}
	}
	//
}














//��ѹ��ѹ��Ƿѹ
uint32_t BatAlarmUVTick, BatAlarmOVTick;
void funAlarmBatVolt(void)
{
	//Ƿѹ
	switch (funAlarm((SysData.sBatVolt < SysData.ConfigData[Cfg_BatUVAlarm]),						//����������
									((SysData.sBatVolt - 200) > SysData.ConfigData[Cfg_BatUVAlarm]),	//��������
									&SysData.Alarm, AlarmBatUV,		//�澯ֵ��λ
									&BatAlarmUVTick,5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmBatUV , 0, SysData.sBatVolt);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmBatUV , 0, SysData.sBatVolt);
			break;
		}	
	//��ѹ
	switch (funAlarm((SysData.sBatVolt > SysData.ConfigData[Cfg_BatOVAlarm]),						//����������
									((SysData.sBatVolt + 200) < SysData.ConfigData[Cfg_BatOVAlarm]),	//��������
									&SysData.Alarm, AlarmBatOV,		//�澯ֵ��λ
									&BatAlarmOVTick,5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmBatOV , 0, SysData.sBatVolt);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmBatOV , 0, SysData.sBatVolt);
			break;
		}	

}

//����ع�ѹ��Ƿѹ
uint32_t CellAlarmUVTick[DevSubMax];	//, CellProtectUVTick[DevSubMax];
uint32_t CellAlarmOVTick[DevSubMax];	//, CellProtectOVTick[DevSubMax];
void funAlarmCellVolt(int16_t cell)
{
	//Ƿѹ
	switch (funAlarm((SysData.Sub[cell].sVoltmV < SysData.ConfigData[Cfg_CellUVAlarm]),						//����������
									((SysData.Sub[cell].sVoltmV - 500) > SysData.ConfigData[Cfg_CellUVAlarm]),	//��������
									&SysData.CellAlarm[cell] , AlarmCellUV,		//�澯ֵ��λ
									&CellAlarmUVTick[cell],5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmCellUV , cell + 1, SysData.Sub[cell].sVoltmV);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmCellUV , cell + 1, SysData.Sub[cell].sVoltmV);
			break;
		}	

	
	//��ѹ
	switch (funAlarm((SysData.Sub[cell].sVoltmV > SysData.ConfigData[Cfg_CellOVAlarm]),						//����������
									((SysData.Sub[cell].sVoltmV + 500) < SysData.ConfigData[Cfg_CellOVAlarm]),	//��������
									&SysData.CellAlarm[cell] , AlarmCellOV,		//�澯ֵ��λ
									&CellAlarmOVTick[cell],5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmCellOV , cell + 1, SysData.Sub[cell].sVoltmV);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmCellOV , cell + 1, SysData.Sub[cell].sVoltmV);
			break;
		}	

}


//����ع��¡�Ƿ��
uint32_t CellAlarmUTTick[DevSubMax];	//, CellProtectUTTick[DevSubMax];
uint32_t CellAlarmOTTick[DevSubMax];	//, CellProtectOTTick[DevSubMax];
void funAlarmCellTemp(int16_t cell)
{
	int16_t tTemp;
	//����
	tTemp = SysData.Sub[cell].sTemp[0] < SysData.Sub[cell].sTemp[1] ?
					SysData.Sub[cell].sTemp[0] : SysData.Sub[cell].sTemp[1];
	switch (funAlarm((tTemp < SysData.ConfigData[Cfg_CellUTAlarm]),						//����������
									((tTemp- 50) > SysData.ConfigData[Cfg_CellUTAlarm]),	//��������
									&SysData.CellAlarm[cell] , AlarmCellUT,		//�澯ֵ��λ
									&CellAlarmUTTick[cell],5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmCellUT , cell + 1, tTemp);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmCellUT , cell + 1, tTemp);
			break;
		}	

	//����
	tTemp = SysData.Sub[cell].sTemp[0] > SysData.Sub[cell].sTemp[1] ?
					SysData.Sub[cell].sTemp[0] : SysData.Sub[cell].sTemp[1];
	switch (funAlarm((tTemp > SysData.ConfigData[Cfg_CellOTAlarm]),						//����������
									((tTemp + 50) < SysData.ConfigData[Cfg_CellOTAlarm]),	//��������
									&SysData.CellAlarm[cell] , AlarmCellOT,		//�澯ֵ��λ
									&CellAlarmOTTick[cell],5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmCellOT , cell + 1, tTemp);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmCellOT , cell + 1, tTemp);
			break;
		}		
}


void funAlarmCellRes(int16_t cell)
{
	//����
	if((SysData.CellAlarm[cell] & AlarmRes) == 0)
	{
		if(SysData.sLastResValue[cell] > SysData.ConfigData[Cfg_ResOVAlarm])
		{
			SysData.CellAlarm[cell] |= AlarmRes;
			AlarmAdd(AlarmRes , cell + 1, SysData.sLastResValue[cell]);
		}
	}
	else
	{
		if(SysData.sLastResValue[cell] < SysData.ConfigData[Cfg_ResOVAlarm])
		{
			SysData.CellAlarm[cell] &= AlarmRes;
			AlarmDel(AlarmRes , cell + 1, SysData.sLastResValue[cell]);
		}
	}
}

void funAlarmCellSoh(int16_t cell)
{//���޲������ã�����û�д˱���
	if((SysData.CellAlarm[cell] & AlarmSoh) == 0)
	{
		if(SysData.sLastActValue[cell] > SysData.ConfigData[Cfg_SohOVAlarm])	//SOH ����
		{
			SysData.CellAlarm[cell] |= AlarmSoh;
			AlarmAdd(AlarmSoh , cell + 1, SysData.sLastResValue[cell]);
		}
	}
	else
	{
		if(SysData.sLastActValue[cell] < SysData.ConfigData[Cfg_SohOVAlarm])	//SOH
		{
			SysData.CellAlarm[cell] &= AlarmSoh;
			AlarmDel(AlarmSoh , cell + 1, SysData.sLastResValue[cell]);
		}
	}
}

uint32_t AlarmACUVTick, AlarmACOVTick;
void funAlarmAC(void)
{
	//Ƿѹ����ѹ
	switch (funAlarm((SysData.sLineVolt < SysData.ConfigData[Cfg_LineUVAlarm]) || (SysData.sLineVolt > SysData.ConfigData[Cfg_LineOVAlarm]) ,						//����������
									((SysData.sLineVolt - 500) > SysData.ConfigData[Cfg_LineUVAlarm]) && ((SysData.sLineVolt + 500) < SysData.ConfigData[Cfg_LineOVAlarm]),	//��������
									&SysData.Alarm , AlarmLineErr,		//�澯ֵ��λ
									&AlarmACUVTick,5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmLineErr, 0, SysData.sLineVolt);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmLineErr, 0, SysData.sLineVolt);
			break;
		}	
	
//	//��ѹ
//	switch (funAlarm((SysData.LineVolt < SysData.ConfigData[Cfg_LineUVAlarm]) ,						//����������
//									((SysData.LineVolt - 500) > SysData.ConfigData[Cfg_LineUVAlarm]) ,	//��������
//									&SysData.Alarm , AlarmLineErr,		//�澯ֵ��λ
//									&AlarmACUVTick,5000, 20000))
//		{
//		case 1:	//�澯
//			break;
//		case -1:	//�澯�ָ�
//			break;
//		}	
//	//��ѹ
//	switch (funAlarm((SysData.LineVolt < SysData.ConfigData[Cfg_LineUVAlarm]) || (SysData.LineVolt > SysData.ConfigData[Cfg_LineOVAlarm]) ,						//����������
//									((SysData.LineVolt - 500) > SysData.ConfigData[Cfg_LineUVAlarm]) && ((SysData.LineVolt + 500) < SysData.ConfigData[Cfg_LineOVAlarm]),	//��������
//									&SysData.Alarm , AlarmLineErr,		//�澯ֵ��λ
//									&AlarmACUVTick,5000, 20000))
//		{
//		case 1:	//�澯
//			break;
//		case -1:	//�澯�ָ�
//			break;
//		}	

}



//��ֹ�ѹ
uint32_t AlarmDefTick;
void funAlarmDefVolt(void)
{
	switch (funAlarm((SysData.sDefVoltmV > SysData.ConfigData[Cfg_DefOVAlarm]),						//����������
									((SysData.sDefVoltmV + 500) < SysData.ConfigData[Cfg_DefOVAlarm]),	//��������
									&SysData.Alarm , AlarmCellDef,		//�澯ֵ��λ
									&AlarmDefTick,5000, 20000))
		{
		case 1:	//�澯
			break;
		case -1:	//�澯�ָ�
			break;
		}	
}








