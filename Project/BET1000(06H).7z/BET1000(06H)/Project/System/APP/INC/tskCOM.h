#ifndef __TSK_COM_H__
#define __TSK_COM_H__
#include "stm32f10x.h"



int8_t funCanSend04(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat1,uint16_t dat2, uint16_t dat3);
int8_t funCanSend05(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat1,uint16_t dat2, uint16_t dat3);
int8_t funCanSend06(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat1,uint16_t dat2, uint16_t dat3);
int8_t funCanSend10(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat);


#endif
