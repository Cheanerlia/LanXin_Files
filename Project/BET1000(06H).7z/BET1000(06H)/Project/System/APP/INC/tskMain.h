#ifndef __TSK_MAIN_H__
#define __TSK_MAIN_H__

#include "stm32f10x.h"


#define ActionStartAuto 1
#define ActionStartRemo 2
#define ActionStartHand 3



#define ActionEndAuto 1
#define ActionEndRemo 2
#define ActionEndHand 3
#define ActionEndErr  4




#define STS_ERR 0x01
#define STS_ok  0x02




//int8_t ActiveIn(void);
int8_t ActiveStart(uint8_t mode);
int8_t ActiveEnd(uint8_t mode);


void SocParaInit(void);
void UserConfigInit(void);
#endif

