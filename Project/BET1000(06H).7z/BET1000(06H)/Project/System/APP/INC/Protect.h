#ifndef _PROTECT_H_
#define _PROTECT_H_

#include "stm32f10x.h"
#include "sys.h"

#define AlarmACOVTemp       0x01
#define AlarmACUVTemp       0x02

#define AlarmDevErr				0x01
#define AlarmLineErr       0x02

#define AlarmBatUV       0x03
#define AlarmBatOV       0x04
#define AlarmCellUV       0x05
#define AlarmCellOV       0x06
#define AlarmCellUT       0x07
#define AlarmCellOT       0x08
#define AlarmEnvUT       0x09
#define AlarmEnvOT       0x0A
#define AlarmChgOC       0x0B
#define AlarmDsgOC       0x0C
#define AlarmRes       	0x0D
#define AlarmSoh       	0x0E
#define AlarmCellDef       0x0F
#define AlarmPortOT       0x10

//��Բɼ���
#define AlarmSubUV       0x01	//���Ƿѹ
#define AlarmSubOV       0x02	//��ع�ѹ
#define AlarmSubUT       0x03	//��ص���
#define AlarmSubOT       0x04	//��ظ���
#define AlarmSubOR       0x05	//����Խ��
#define AlarmSubOH       0x06	//����Խ��
#define AlarmSubAP       0x07	//���߶��ӹ��ȹ���
#define AlarmSubCOM       0x08	//ͨ�Ÿ澯


#define AlarmSubUVBit (1 << (AlarmSubUV - 1))
#define AlarmSubOVBit (1 << (AlarmSubOV - 1))
#define AlarmSubUTBit (1 << (AlarmSubUT - 1))
#define AlarmSubOTBit (1 << (AlarmSubOT - 1))
#define AlarmSubORBit (1 << (AlarmSubOR - 1))
#define AlarmSubOHBit (1 << (AlarmSubOH - 1))
#define AlarmSubAPBit (1 << (AlarmSubAP - 1))
#define AlarmSubCOMBit (1 << (AlarmSubCOM - 1))

//#define TypeAlarm	0x40


#define AlarnList_Valid 0xAA55

//typedef struct
//{
//  uint16_t Valid;       //��Ч��  
//  DateTimeStruct AlarmTime;
//  
//  uint8_t AlarmType;
//  uint8_t Level;  
//  uint8_t Res[4];
//  
//  uint16_t CheckSum;
//}AlarmRecordStruct;


void funAlarmCellVolt(int16_t cell);
void funAlarmCellTemp(int16_t cell);
void funAlarmCellPortOT(int16_t cell);
void funAlarmCellRes(int16_t cell);
void funAlarmCellSoh(int16_t cell);
void funAlarmSubTotleAll(int16_t AlarmSubAll)	;

void funAlarmAC(void);
void funAlarmDefVolt(void);





#endif

