#ifndef _CONFIGURE_H_
#define _CONFIGURE_H_

#define DEBUG

#define SubCellVoltMin	9000
#define AdjCfgAddr      0x0000		//256
//#define ManuCfgAddr   0x0180		//128
#define UserCfgAddr     0x0100		//256

//#define AdjCfgAddr      0x08004000
//#define ManuCfgAddr     0x08008000
//#define UserCfgAddr     0x0800C000
//#define UserDatAddr     0x08010000

#endif
