/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include "sys.h"
#include "configure.h"
#include "bspBIMS.h"
#include "BSP.h"
#include "tskmain.h"
#include "tskCOM.h"
#include "protect.h"
#include <string.h>
#include <stdlib.h>


#define MAX(a, b)		(a > b ? a : b)


void funSubInit(void);
void funSubStdby(void);
void funSubRes(void);
void funSubAct(void);

int16_t funBIMStoAct(int8_t code);
int16_t funBIMSoutAct(int8_t code);
int16_t funBIMStoRes(int8_t code);
int16_t funBIMSoutRes(int8_t code);
int16_t funBIMStoAddr(int8_t code);
int16_t funBIMStoAlChg(int8_t cell);
int16_t funBIMSoutAlChg(int8_t code);



int8_t funCanSend05(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat1,uint16_t dat2, uint16_t dat3);
void funADC_Adj(uint16_t no,uint16_t data);


BIMSSysDef_STRUCT SysData;
//BIMSConfig_STRUCT Config;

void ResAdd(uint8_t cell, int16_t reaValue);
void ActRptAddStart(uint8_t cell, int8_t ActType);
void ActRptAddStop(uint8_t cell, int8_t stop, int16_t Value, uint16_t time);


void funFDataAddStart(uint8_t Cell, uint8_t step);
void funFDataAddStop(uint8_t Cell, uint8_t step, int8_t stopcode);
void funFDataAddData(uint8_t Cell, uint8_t step, int16_t volt, int16_t Curr,	int16_t AH);

int16_t const ConfigDef[][3] =
{
	//MIN, MAX, DEF
	{0,0,0},
	{0,1,0},//1�������ͺ�
	{1,2,1},//2�������
	{12,12,12},//3���ѹ
	{5,300,25},//4�����
	{1,40,1},//5���豸���������
	{0,0,0},
	{1,254,1},//7����ͨ�ŵ�ַ
	{1200,19200,9600},	//8	//������
	{0,2,0},	//9	//У��λ
	{0,0,0},	//10	//Э��
	{10,254,192},	//11	//IP1
	{0,254,168},	//12	//
	{0,254,0},	//13	//
	{0,254,1},	//14	//
	{1,		1080,	30000},	//15	//PORT
	{10,	254,	192},	//16	//
	{0,		254,	168},	//17	//
	{0,		254,	0	},	//18	//
	{0,		254,	1	},	//19	//
	{0,		0,		0},	//
	{0,		0,		0},	//21	//��������
	{0,		0,		0},	//22	//����洢ʱ����<��Ч>
	{0,		0,		0},	//23	//ά���洢ʱ����<��Ч>
	{0,		0,		0},	//
	{0,		1800,		0},	//25	//�����
	{0,		1800,		0},	//26	//��������
	{0,		12,		0},	//27	//����ʱ��
	{0,		1,		0},	//28	//����ʹ��
	{0,		1,		0},	//29	//����ʹ��
	{0,		0,		0},	//
	{10000,14500,	13800},	//31	//��������ѹ
	{10000,14500, 10800},	//32	//�ŵ������ѹ
	{0,		100,	10},	//33	//������
	{0,		1000,	10},	//34	//�ŵ����
	{0,		1080,	0},	//35	//��ֹʱ��(��)
	{10	,2000,1000},	//36	//��������ѹ��
	{10	,2000,500},	//37	//����ֹͣѹ��
	{0,		0,		0},	//38
	{0,		0,		0},	//39
	{15000,	30000,26400},	//40	//������ѹ�澯
	{15000,	30000,19800},	//41	//����Ƿѹ�澯
	{100,		30000,		26400},	//42	//��ѹ��ѹ�澯
	{100,		30000,		19800},	//43	//��ѹǷѹ�澯
	{10000,		15000,		15000},	//44	//�����ѹ
	{9000,		15000,		10000},	//45	//����Ƿѹ
	{-400,		1500,		600},	//46	//������¶�
	{-400,		1500,		-100},	//47	//������¶�
	{-400,		1500,		600},	//48	//��������
	{-400,		1500,		-100},	//49	//����Ƿ��
	{0,		5000,		1000},	//50	//������
	{0,		5000,		1000},	//51	//�ŵ����
	{0,		10000,		2000},	//52	//���賬��
	{0,		1000,		750},	//53	//SOH���޸澯
	{0,		10000,		2000},	//54	//������ѹ��޸澯
	{-400,		1500,		600},	//55	//���߶��ӹ��¸澯
	{0,		0,		0},	//56
	{0,		0,		0},	//57
	{0,		0,		0},	//58
	{0,		0,		0},	//59
	{0,		0,		0},	//60
	{0,		0,		0},	//61
	{0,		0,		0},	//62
	{0,		0,		0},	//63
	{0,		0,		0},	//64
	{0,		0,		0},	//
};//



#define DAC_ChgVolt	0
#define DAC_ChgCurr	1
#define DAC_DsgCurr	2
extern void funDAC_OUT(int8_t ch, int32_t dat);

uint32_t GetLocalTime(DateTimeStruct *dt) ;

void vApplicationTickHook( void )
{
}

void funConfigCheck(uint8_t sn)
{

		if((SysData.ConfigData[sn] < ConfigDef[sn][0]) 
			|| (SysData.ConfigData[sn] > ConfigDef[sn][1]) )
		{
			SysData.ConfigData[sn] = ConfigDef[sn][2];
		}

}

int16_t funGetFloatVolt(int16_t volt, int16_t temp)
{
	int16_t diftemp;
	
	diftemp = temp - 250;
	if(diftemp > (TempDiffMax * 10))
	{
		diftemp = TempDiffMax * 10;
	}
	else if(diftemp < (-TempDiffMax * 10))
	{
		diftemp = -TempDiffMax * 10;
	}
	diftemp *= TempCompVolt;
	diftemp /= 10;
	
	return volt + diftemp;
}

void funDataInit(void)
{
	if(bspLoadLastTime(0, &SysData.ActLastTime) != 1)
	{
		SysData.ActLastTime = GetLocalTime(&Now);	//��ǰ
	}
	if(bspLoadLastTime(1, &SysData.ResLastTime) != 1)
	{
		SysData.ResLastTime = GetLocalTime(&Now);	//��ǰ
	}
}

/********************************************************************************************************************
**��������Ҫ����
**
**
**
**
********************************************************************************************************************/
int32_t funDiffDateTime(DateTimeStruct *d1, DateTimeStruct *d2)	;

int8_t funBusSwitchRead(void);
int8_t funBusSwitchOn(void);
int8_t funBusSwitchOff(void);
void funFanCtrl(void);
void funAddr(void);
void funAct(void);
void funAlChg(void);
void funNormal(void);
void funSubRes(void);
void funMode(void)
{
	uint32_t NowTime;
	if(SysData.RunSts & RunSts_Addr)	//��ַ
	{
		funAddr();
	}	
	else if(SysData.RunSts & RunSts_Act)	//�
	{
		funAct();
	}
	else if(SysData.RunSts & RunSts_AlChg)	//����
	{
		funAlChg();
	}
	else if(SysData.RunSts & RunSts_Res)	//����
	{
		funSubRes();
	}
	else
	{
		funNormal();
		
		NowTime = GetLocalTime(&Now);
		
		//�Ƿ���Ҫ������
		if(((NowTime - SysData.ResLastTime) >= (SysData.ConfigData[Cfg_ResTestCys] * 86400))	//ʱ�䵽
			&& (SysData.ConfigData[Cfg_ResTestCys] != 0))
		{
			funBIMStoRes(ActMode_Auto);
		}
		else if((SysData.sBatVolt > BatVoltFull)	//�Ƿ��س���
			&& (SysData.sBatCurr < SysData.ConfigData[Cfg_SubAHRatio]) 
			&& ((SysData.Alarm & ~( (1 << (AlarmRes - 1) )
													| (1 << (AlarmSoh - 1 ))
													| (1 << (AlarmCellDef - 1 )))	  ) == 0))
		{
			//�Ƿ�����
			if(SysData.RunSts & RunSts_ActPause)
			{
				funBIMStoAct(ActMode_Auto);
			}
			else
			{
			//�ж�ʱ��
				if(((NowTime - SysData.ActLastTime) >= (SysData.ConfigData[Cfg_ActionCyc] * 86400))	//ʱ�䵽
					&& (SysData.ConfigData[Cfg_ActionCyc] != 0))
				{
					funBIMStoAct(ActMode_Auto);
				}
			}
		}
		
	}
	
	if((SysData.RunSts & RunSts_Act ) == 0)	//�ǻ״̬
	{
		funBusSwitchOn();		
	}	
	if((SysData.RunSts & (RunSts_Act | RunSts_AlChg)) == 0)	//�ǻ״̬
	{
		//�رո��ɼ�ģ��̵���
		
	}
}

//#define Cfg_ActionCyc				25	//�����
//#define Cfg_ResTestCys			26	//��������

uint32_t GetLocalTime(DateTimeStruct *dt) 
{
	uint32_t date, time;
		//������
	date = dt->Year * 365;
	date ++;	//2000��������
	date += dt->Year / 4;	//������
	if((( dt->Year % 4 )== 0) && (dt->Mon <= 2))	//����ǰ2����
	{
		date--;
	}
	switch(dt->Mon )
	{
		case 12:	//12��
			date += 30;	//11�� 30��
		case 11:	//
			date += 31;	//10�� 31��
		case 10:	//
			date += 30;	//9�� 30��
		case 9:	//
			date += 31;	//8�� 31��
		case 8:	//
			date += 31;	//7�� 31��
		case 7:	//
			date += 30;	//6�� 30��
		case 6:	//
			date += 31;	//5�� 31��
		case 5:	//
			date += 30;	//4�� 30��
		case 4:	//
			date += 31;	//3�� 31��
		case 3:	//
			date += 28;	//2�� 28
		case 2:	//
			date += 31;	//1�� 31��
			break;
	}
	date += dt->Day - 1;	
	
	time = date * 86400;
	time += (uint32_t)dt->Hour * 3600;
	time += (uint32_t)dt->Min * 60;
	time += dt->Sec ;
	
	return time;
}

uint32_t GetSubDataTick;
void funModeCtrl(void)
{
	int16_t i;
	int16_t num, max, min;
	int32_t cellsum;
	static uint8_t CellSerial = 0;
	num = SysData.ConfigData[Cfg_SubDevNum] < DevSubMax ? SysData.ConfigData[Cfg_SubDevNum] : DevSubMax;
	//ѭ����ȡ����
	if((xTaskGetTickCount() - GetSubDataTick) >= 30)
	{
		GetSubDataTick = xTaskGetTickCount();
		
		if(CellSerial < num)
		{
			funCanSend04(CellSerial + 1, 0, 0x10, 0, 0, 0);
		}
		else
		{
			CellSerial = 0;
		}
		CellSerial ++;
		if(CellSerial >= num)
		{
			CellSerial = 0;
		}
	}
	
	cellsum = 0;
	max = 0;
	min = 0;
	if(num > 0)
	{
		for( i = 0; i < num; i++)
		{
			cellsum += SysData.Sub[i].sVoltmV;
			if(SysData.Sub[min].sVoltmV > SysData.Sub[i].sVoltmV)
			{
				min = i;
			}
			if(SysData.Sub[max].sVoltmV < SysData.Sub[i].sVoltmV)
			{
				max = i;
			}
		}
		SysData.bCellMin = min + 1;
		SysData.bCellMax = max + 1;
		SysData.sAveVoltmV = cellsum / num;
		SysData.sDefVoltmV = SysData.Sub[max].sVoltmV - SysData.Sub[min].sVoltmV;
	}
	else	//num = 0
	{
		SysData.bCellMin = -1;
		SysData.bCellMax = -1;
		SysData.sAveVoltmV = 0;
		SysData.sDefVoltmV = 0;
	}
	
	funFanCtrl();		//���ȿ���
	//�̵������
	SysData.RunSts &= 0x0FFF;
	SysData.RunSts |= funBusSwitchRead() << 12;
	
}
	
//���ȿ���
void drvFAN_Out(uint8_t pt);

int16_t  testCurr;

uint32_t FanTick, FanDelay;
uint8_t FanCtrl = 0;
void funFanCtrl(void)
{
	static uint8_t NowFan;
	uint32_t temp;
	
//	SysData.sBusCurrcA = testCurr;
	
	if(abs(SysData.sBusCurrcA) < 750)
	{
		temp = 0;
	}
	else
	{
		temp = abs(SysData.sBusCurrcA) - 750;
		temp *= 100 - 55;
		temp /= 2500 - 750;
		temp += 55;

		if(temp > 100)
		{
			temp = 100;
		}
	}
	
	if(temp >= FanCtrl)
	{
		FanCtrl = temp;
		FanDelay = xTaskGetTickCount();
	}
	else if((xTaskGetTickCount() - FanDelay) > 30000)
	{
		FanCtrl = temp;
		FanDelay = xTaskGetTickCount();
	}
	
	
//	if((xTaskGetTickCount() - FanDelay) < 30000)
//	{
//		drvFAN_Out(FanCtrl);
//	}
//	else
//	{
//		FanCtrl = temp;
//		FanDelay = xTaskGetTickCount();
//		drvFAN_Out(FanCtrl);
//	}
	
	if((xTaskGetTickCount() - FanTick) >= 1000)
	{
		FanTick = xTaskGetTickCount();
		drvFAN_Out(FanCtrl);
		//drvFAN_Out(50);
	}
}


/******************************************************************************
������Կ���
*******************************************************************************/
uint8_t ResSubDev;
uint32_t ResDevFlag;
uint32_t Res_CAN_TICK, ResDelayTick;
int16_t funBIMStoRes(int8_t code)
{
//	if((SysData.RunSts & RunSts_Act) == 0)
//	{
//		SysData.Act_Step = 0;
//		ActSubDev = 0;
//		SysData.RunSts |= RunSts_Act;
//	}
	uint8_t i;
	ResDevFlag = 0;
	for(i = 0; (i < SysData.ConfigData[Cfg_SubDevNum]) && (i < 32); i++)
	{
		ResDevFlag |= 1 << i;
	}
	
	ResSubDev = 0;
	SysData.Res_Step = 1;
	SysData.RunSts |=  RunSts_Res;
	return 0;
}

int16_t funBIMSoutRes(int8_t code)
{
	SysData.Res_Step = 0;
	SysData.RunSts &=  ~RunSts_Res;

	return 0;
}

void funSubRes(void)
{	
	switch(SysData.Res_Step)
	{
		case 0:
			SysData.Res_Step++;
			break;
		case 1:	//������Ҫ���������ģ��
			if(ResSubDev < SysData.ConfigData[Cfg_SubDevNum])
			{
				//�����У�
				if(SysData.Sub[ResSubDev].RunSts & RunSts_Act)	//���
				{
					ResSubDev++;
				}
				else if(ResDevFlag & (1 << ResSubDev))	//δ������
				{
					SysData.Res_Step++;
				}
				else
				{
					ResSubDev++;
				}
			}
			else if(ResDevFlag == 0)	//�������
			{
				funBIMSoutRes(ActMode_Auto);
			}
			else	//���¿�ʼ
			{
				ResSubDev = 0;
			}
			break;
		case 2:	//�ж��Ƿ��ѿ�ʼ������
			if((xTaskGetTickCount() - Res_CAN_TICK) >= 100)	//���ͻ��ʼ
			{
				Res_CAN_TICK = xTaskGetTickCount();
				funCanSend05(ResSubDev + 1, 0, 0x11, 0xFF55, 0, 0);
				funCanSend04(ResSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
			}
			
			if((SysData.Sub[ResSubDev].RunSts & RunSts_Res) != 0)	//�ѿ�ʼ������
			{
				SysData.Res_Step = 3;
			}

			break;
		case 3:	//�ȴ��������
			if(ResSubDev < SysData.ConfigData[Cfg_SubDevNum])
			{
				if((xTaskGetTickCount() - Res_CAN_TICK) >= 100)	//���Ͳ�ѯ
				{
					Res_CAN_TICK = xTaskGetTickCount();
				}
				if((SysData.Sub[ResSubDev].RunSts & RunSts_Res) == 0)		//�����
				{
					ResDevFlag &= ~(1 << ResSubDev);
//					ResSubDev++;
					SysData.Res_Step ++;
					ResDelayTick = xTaskGetTickCount();
				}
			}
	
			break;
		case 4:	//��ʱ2S���ȴ����ݸ���
			if(ResSubDev < SysData.ConfigData[Cfg_SubDevNum])
			{
				if((xTaskGetTickCount() - Res_CAN_TICK) >= 100)	//���Ͳ�ѯ
				{
					Res_CAN_TICK = xTaskGetTickCount();
					funCanSend04(ResSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
				}
				if((xTaskGetTickCount() - ResDelayTick) >= 3000)	
				{
					ResAdd(ResSubDev + 1, SysData.Sub[ResSubDev].sCellRes);
					funAlarmCellRes(ResSubDev);
					SysData.Res_Step = 1;
					ResSubDev++;
				}
			}
			break;
		case 5:	//����
			
			SysData.RunSts &= ~RunSts_Act;
			break;
	}
}
/******************************************************************************
�����
*******************************************************************************/
/****************************************************************************************************
�����
****************************************************************************************************/
uint32_t ActTick;	//���ʱ��
uint16_t ActSubDev;
int16_t funBIMStoAct(int8_t code)
{
	uint32_t LastTime;
	if(((SysData.RunSts & RunSts_Act) == 0)	//δ�
		&& ((SysData.RunSts & RunSts_AlChg) == 0)	//�����
		&& ((SysData.Alarm & ~( (1 << (AlarmRes - 1) )
													| (1 << (AlarmSoh - 1 ))
													| (1 << (AlarmCellDef - 1 )))	  ) == 0))
	{
		SysData.Act_Step = 0;
		if((SysData.RunSts & RunSts_ActPause) == 0)
		{
			ActSubDev = 0;
		}
		SysData.RunSts |= RunSts_Act;
		ActTick = xTaskGetTickCount();
		funFDataAddStart(SysData.ConfigData[Cfg_SubDevNum], 0);
		
		LastTime = GetLocalTime(&Now);
		bspSaveLastTime(0, &LastTime);
	}
	return 0;
}
int16_t funBIMSoutAct(int8_t code)
{
	uint32_t LastTime;
	if(SysData.RunSts & RunSts_Act)
	{
		if((code == ActMode_Auto)
			|| (code == ActMode_Hand)
			|| (code == ActMode_Remo)
			|| (code == ActMode_HMI))
		{//�Զ����ֶ�ֹͣ- ���쳣ֹͣ
			SysData.RunSts &= ~RunSts_ActPause;
			ActSubDev = 0;
		}
		else	//�쳣ֹͣ
		{
			SysData.RunSts |= RunSts_ActPause;
		}
		SysData.Act_Step = 0;
		SysData.RunSts &= ~RunSts_Act;
		funFDataAddStop(0, 0, code);
		
		LastTime = GetLocalTime(&Now);
		bspSaveLastTime(0, &LastTime);
	}
	return 0;
}

uint32_t BIMS_CAN_TICK;	//������CANָ��TICK
uint32_t BIMS_CTRL_TICK;
uint32_t BIMS_ACT_Delay;

int8_t funSubChg(uint8_t SubNo, int16_t volt, int16_t Curr);
int8_t funSubDsg(uint8_t SubNo, int16_t volt, int16_t Curr);


uint32_t FdataTick;
uint32_t PwrTick;
void funAct(void)
{
	uint8_t i, Ready;
	if(SysData.Alarm & AlarmLineErr)	//��������
	{
		if((SysData.Act_Step >= 7) && (SysData.Act_Step <= 11))	//�ŵ�δ����
		{
			funBIMStoAlChg(ActSubDev);	//Ӧ�����ģʽ
		}
		funBIMSoutAct(ActMode_Err);		
	}
	else if(SysData.Alarm & ~((1 << (AlarmRes  - 1))
													| (1 << (AlarmSoh - 1) )
													| (1 << (AlarmCellDef - 1) )))	
	{
		funBIMSoutAct(ActMode_Err);		
	}
	switch(SysData.Act_Step)
	{
		case 0:
			SysData.Act_Step++;
			ActTick = xTaskGetTickCount();
			BIMS_ACT_Delay = xTaskGetTickCount();
			BIMS_CTRL_TICK = xTaskGetTickCount();
			break;
		case 1:
			ActSubDev = 0;
			//�Ͽ��Ӵ���
			BUS_CHG_OFF;
			BUS_DSG_OFF;
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)	//��ʱ
			{
				BIMS_CAN_TICK = xTaskGetTickCount();
					//�㲥���׼��
				funCanSend05(0xFF, 0, 0x10, 0xFF00, 0, 0);	//�رղɼ���̵���
			}
			if(funBusSwitchOff() == 1)
			{
				SysData.Act_Step++;
			}
			if((xTaskGetTickCount() - ActTick) >= 30000)	//��ʱ
			{	//ʧ��
				funBIMSoutAct(ActMode_Err);
			}
			break;
		case 2:
			//�ж����вɼ�������׼��
			Ready = 0;			
			BUS_CHG_OFF;
			BUS_DSG_OFF;
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
			{
				BIMS_CAN_TICK = xTaskGetTickCount();
				funCanSend05(0xFF, 0, 0x10, 0xFF00, 0, 0);	//�رղɼ���̵���
			}
			
			for(i = 0; i < SysData.ConfigData[Cfg_SubDevNum]; i++)
			{
				if(SysData.Sub[i].RunSts & SubRunSts_BusON)	//�ж����вɼ����Ƿ�׼����-δ��բ
				{
					Ready = 1;
				}
			}
			if(Ready == 0)
			{
				//ActSubDev = 0;
				SysData.Act_Step++;
			}
			break;
		case 3:
			if(ActSubDev < SysData.ConfigData[Cfg_SubDevNum])			//��ʼѭ���
			{
				if((SysData.Sub[ActSubDev].RunSts & SubRunSts_BusON) == 0)  //��Ӧ��ģ��δ��բ
				{
					//��ʱ���ͻ��ʼָ��
					if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 200)
					{
						BIMS_CAN_TICK = xTaskGetTickCount();
						//
						BUS_CHG_ON;
						BUS_DSG_OFF;
						
						SysData.sSetChgVoltmV = SysData.Sub[ActSubDev].sVoltmV;
						SysData.sSetChgCurrcA = SysData.ConfigData[Cfg_SubAHRatio] * SysData.ConfigData[Cfg_CellChgCurr];
						funDAC_OUT(DAC_ChgVolt, SysData.sSetChgVoltmV );
						funDAC_OUT(DAC_ChgCurr, SysData.sSetChgCurrcA );	//����Ĭ��������� 0.1C
						
						funCanSend05(ActSubDev + 1, 0, 0x10, 0xFF55, 0, 0);	//��բ
						funCanSend04(ActSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
					}
				}
				else	//�ѿ�ʼ�
				{
					SysData.Act_Step++;
				}
			}
			else	//����ģ������
			{
				SysData.Act_Step = ActStepEnd;
			}
			break;
		case 4:	//�ȴ��ɼ����բ�̵���
			BUS_CHG_OFF;
			BUS_DSG_OFF;
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 200)
			{
				BIMS_CAN_TICK = xTaskGetTickCount();
				//
				funCanSend06(ActSubDev + 1, 0, 0x10, 0xFF55, 0, 0);	//������
				funCanSend04(ActSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
			}
			if(ActSubDev < SysData.ConfigData[Cfg_SubDevNum])
			{
				if((SysData.Sub[ActSubDev].RunSts & SubRunSts_BusCK) != 0)  //��Ӧ��ģ����ȷ�Ϻ�բ
				{
					SysData.Act_Step++;
					SysData.sSetChgCurrcA  = SysData.ConfigData[Cfg_SubAHRatio] * 10;
					funDAC_OUT(DAC_ChgCurr, SysData.sSetChgCurrcA );
					
					SysData.sSetChgVoltmV  = SysData.Sub[ActSubDev].sVoltmV ;	//��������ѹ��ʼ��
					funDAC_OUT(DAC_ChgVolt, SysData.sSetChgVoltmV );
					
					ActRptAddStart(ActSubDev + 1, ActType_PreChg);	//��¼��翪ʼ
					
					funFDataAddStart(ActSubDev + 1, ActType_PreChg);			//���ݼ�¼��ʼ			
					funFDataAddData(ActSubDev + 1, ActType_PreChg, SysData.Sub[ActSubDev].sVoltmV , 0,	0);
					FdataTick = xTaskGetTickCount();
					ActTick = xTaskGetTickCount();	//�-Ԥ���ʱ��ʼ
					
					PwrTick = xTaskGetTickCount();
				}
			}
			break;
		case 5:	//���-Ԥ��
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
			{
				BIMS_CAN_TICK = xTaskGetTickCount();
				funCanSend04(ActSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
				funCanSend04(ActSubDev + 1, 0, 0x20, 0, 0, 0);	//��ȡ�ŵ�����
			}
			if(ActSubDev < SysData.ConfigData[Cfg_SubDevNum])
			{
				BUS_CHG_ON;
				BUS_DSG_OFF;
				if((SysData.Sub[ActSubDev].RunSts & SubRunSts_BusCK) != 0)  //��Ӧ��ģ����ȷ�Ϻ�բ
				{
					funSubChg(ActSubDev,
										funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1])), 
										SysData.ConfigData[Cfg_SubAHRatio] * SysData.ConfigData[Cfg_CellChgCurr]);
					
					if((xTaskGetTickCount() - FdataTick) >= 60000)	//��ʱ������
					{
						FdataTick = xTaskGetTickCount();
						funFDataAddData( ActSubDev + 1, ActType_PreChg, SysData.Sub[ActSubDev].sVoltmV , SysData.Sub[ActSubDev].sCurrcA,	SysData.Sub[ActSubDev].iCelldAH);
					}
					//�жϳ�����
					if((SysData.Sub[ActSubDev].sVoltmV >= funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1]))) 
						&& (SysData.Sub[ActSubDev].sCurrcA <= SubCellCurrMastoSub) )	//�����
					{
						if((xTaskGetTickCount() - BIMS_ACT_Delay) >= 30000)
						{
							SysData.Act_Step++;

							SysData.sSetChgVoltmV = SubCellVoltMin;				
							funDAC_OUT(DAC_ChgVolt, SysData.sSetChgVoltmV);	//���������ѹ
							
							SysData.sSetDsgCurrcA = SysData.ConfigData[Cfg_SubAHRatio] * 10;
							funDAC_OUT(DAC_DsgCurr, SysData.sSetDsgCurrcA );
							
							ActRptAddStop(ActSubDev + 1, ActMode_Auto, SysData.Sub[ActSubDev].iCelldAH,  (xTaskGetTickCount() - ActTick) / 1000); 	//��¼Ԥ�����
							funFDataAddStop(ActSubDev + 1, ActType_PreChg, ActMode_Auto);
							
							BIMS_ACT_Delay = xTaskGetTickCount();
							ActTick = xTaskGetTickCount();	
						}
					}
					else
					{
						BIMS_ACT_Delay = xTaskGetTickCount();
					}
				}
				if((xTaskGetTickCount() - ActTick) > 64800000)	//��ʱ  18h * 3600S * 1000mS
				{//��ʱ
					SysData.Act_Step = 15;	
					ActRptAddStop(ActSubDev + 1, ActMode_Err, SysData.Sub[ActSubDev].iCelldAH,  (xTaskGetTickCount() - ActTick) / 1000); 	//��¼Ԥ�����
					funFDataAddStop(ActSubDev + 1, ActType_PreChg, ActMode_Auto);
				}	

				//�жϳ���Ƿ�ɹ�
				if((xTaskGetTickCount() - PwrTick) >= 180000)//��ʱ���޳��
				{
						SysData.Act_Step = 15;	
						ActRptAddStop(ActSubDev + 1, ActMode_Auto, SysData.Sub[ActSubDev].iCelldAH,  (xTaskGetTickCount() - ActTick) / 1000); 	//��¼Ԥ�����
						funFDataAddStop(ActSubDev + 1, ActType_PreChg, ActMode_Auto);
				}
				else if((SysData.Sub[ActSubDev].sVoltmV >= funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1]))) //����ѹ�㹻
							|| (SysData.Sub[ActSubDev].sCurrcA >= SubCellCurrMastoSub) )	//�ɳ�����			
				{
					PwrTick = xTaskGetTickCount();
				}
			
			}
			else	//��س�����Χ--��Ӧ�ó������
			{
			}
			
			break;
		case 6:	//Ԥ����ɣ��ŵ�׼��
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
			{
				BIMS_CAN_TICK = xTaskGetTickCount();
				funCanSend04(ActSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��	
				funCanSend04(ActSubDev + 1, 0, 0x20, 0, 0, 0);	//��ȡ�ŵ�����	
				funCanSend06(ActSubDev + 1, 0, 0x10, 0xFF55, 0, 0);	//������	
			}
			if(SysData.Sub[ActSubDev].iCelldAH == 0)
			{
				if((xTaskGetTickCount() - BIMS_ACT_Delay) >= 3000)
				{
					SysData.Act_Step++;
					ActRptAddStart(ActSubDev + 1, ActType_DisChg);	//��¼�ŵ翪ʼ
					funFDataAddStart(ActSubDev + 1, ActType_DisChg);			//���ݼ�¼��ʼ	
					funFDataAddData(ActSubDev + 1, ActType_DisChg, SysData.Sub[ActSubDev].sVoltmV , 0,	0);
					FdataTick = xTaskGetTickCount();
					ActTick = xTaskGetTickCount();	//�-�ŵ��ʱ��ʼ
					
					PwrTick = xTaskGetTickCount();
				}
			}
			else
			{
				BIMS_ACT_Delay = xTaskGetTickCount();
			}
			if((xTaskGetTickCount() - ActTick) > 30000)	//��ʱ  
			{//��ʱ
			}
			break;
		case 7:	//�ŵ�
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
			{
				BIMS_CAN_TICK = xTaskGetTickCount();
				funCanSend04(ActSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
				funCanSend04(ActSubDev + 1, 0, 0x20, 0, 0, 0);	//��ȡ�����
			}
			
			if(ActSubDev < SysData.ConfigData[Cfg_SubDevNum])
			{
				if((SysData.Sub[ActSubDev].RunSts & SubRunSts_BusCK) != 0)  //��Ӧ��ģ����ȷ�Ϻ�բ
				{
					BUS_CHG_OFF;
					BUS_DSG_ON;
					funSubDsg(ActSubDev, SysData.ConfigData[Cfg_CellVoltLowLimit], SysData.ConfigData[Cfg_SubAHRatio] * SysData.ConfigData[Cfg_CellDsgCurr]);

					if((xTaskGetTickCount() - FdataTick) >= 60000)	//��ʱ������
					{
						FdataTick = xTaskGetTickCount();
						funFDataAddData( ActSubDev + 1, ActType_DisChg, SysData.Sub[ActSubDev].sVoltmV , -SysData.Sub[ActSubDev].sCurrcA,	-SysData.Sub[ActSubDev].iCelldAH);
					}					
					
					if(SysData.Sub[ActSubDev].sVoltmV <= SysData.ConfigData[Cfg_CellVoltLowLimit]) 
					{
						if((xTaskGetTickCount() - BIMS_ACT_Delay) >= 30000)	//�ŵ���ɣ�
						{
							//��¼��ʱ������Ϊ��������
							SysData.Act_Step++;
							ActTick = xTaskGetTickCount();	
							
							SysData.sSetChgVoltmV = SysData.Sub[ActSubDev].sVoltmV ;	
							funDAC_OUT(DAC_ChgVolt, SysData.sSetChgVoltmV);	//���������ѹ
							
							SysData.sSetDsgCurrcA = SysData.ConfigData[Cfg_SubAHRatio] * 10;
							funDAC_OUT(DAC_ChgCurr, SysData.sSetDsgCurrcA );
							
							ActRptAddStop(ActSubDev + 1, ActMode_Auto, -SysData.Sub[ActSubDev].iCelldAH, (xTaskGetTickCount() - ActTick) / 1000); 	//��¼����
							funAlarmCellSoh(ActSubDev);
							
							
							funFDataAddStop(ActSubDev + 1, ActType_DisChg, ActMode_Auto);
						}
					}
					else
					{
						BIMS_ACT_Delay = xTaskGetTickCount();
					}
				}
				if((xTaskGetTickCount() - ActTick) > 64800000)	//��ʱ  18h * 3600S * 1000mS
				{//��ʱ
						SysData.Act_Step ++;	
						ActRptAddStop(ActSubDev + 1, ActMode_Err, -SysData.Sub[ActSubDev].iCelldAH,  (xTaskGetTickCount() - ActTick) / 1000); 	//��¼Ԥ�����
						funFDataAddStop(ActSubDev + 1, ActType_PreChg, ActMode_Err);
				}
				
				//�жϷŵ��Ƿ�ɹ�
				if((xTaskGetTickCount() - PwrTick) >= 180000)//��ʱ���޷ŵ�
				{
						SysData.Act_Step = 15;	
						ActRptAddStop(ActSubDev + 1, ActMode_Err, -SysData.Sub[ActSubDev].iCelldAH,  (xTaskGetTickCount() - ActTick) / 1000); 	//��¼Ԥ�����
						funFDataAddStop(ActSubDev + 1, ActType_PreChg, ActMode_Err);
				}
				else if (SysData.Sub[ActSubDev].sCurrcA <= -SubCellCurrMastoSub )	//	
				{
					PwrTick = xTaskGetTickCount();
				}
			}
			else	//��س�����Χ
			{
			}
			break;
		case 8:	//�ŵ���ɣ���ֹ�ȴ�
			//SysData.Act_Step++;  SysData.ConfigData[Cfg_StandbyTime]
			if(SysData.ConfigData[Cfg_StandbyTime] <= 1080)	//18h
			{
				if((xTaskGetTickCount() - ActTick) > (SysData.ConfigData[Cfg_StandbyTime] * 60000))
				{
					SysData.Act_Step++;
				}
			}
			else
			{
				SysData.Act_Step++;
			}
			break;
		case 9:	//�ŵ���ɣ�����׼��
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
			{
				BIMS_CAN_TICK = xTaskGetTickCount();
				funCanSend04(ActSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��	
				funCanSend04(ActSubDev + 1, 0, 0x20, 0, 0, 0);	//��ȡ�ŵ�����	
				funCanSend06(ActSubDev + 1, 0, 0x10, 0xFF55, 0, 0);	//������	
			}
			if(SysData.Sub[ActSubDev].iCelldAH == 0)
			{
				if((xTaskGetTickCount() - BIMS_ACT_Delay) >= 3000)
				{
					SysData.Act_Step++;
					ActRptAddStart(ActSubDev + 1, ActType_EndChg);	//��¼�س俪ʼ
					ActTick = xTaskGetTickCount();	//�-�����ʱ��ʼ
					
					
					funFDataAddStart(ActSubDev + 1, ActType_EndChg);			//���ݼ�¼��ʼ			
					funFDataAddData(ActSubDev + 1, ActType_EndChg, SysData.Sub[ActSubDev].sVoltmV , 0,	0);
					FdataTick = xTaskGetTickCount();
					PwrTick = xTaskGetTickCount();
				}
			}
			else
			{
				BIMS_ACT_Delay = xTaskGetTickCount();
			}

			break;
		case 10:	//�س��	
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
			{
				BIMS_CAN_TICK = xTaskGetTickCount();
				funCanSend04(ActSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��	
				funCanSend04(ActSubDev + 1, 0, 0x20, 0, 0, 0);	//��ȡ�ŵ�����	
			}
			if(ActSubDev < SysData.ConfigData[Cfg_SubDevNum])
			{
				BUS_CHG_ON;
				BUS_DSG_OFF;	
				if((SysData.Sub[ActSubDev].RunSts & SubRunSts_BusCK) != 0)  //��Ӧ��ģ����ȷ�Ϻ�բ
				{
					funSubChg(ActSubDev, funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1])), 
										SysData.ConfigData[Cfg_SubAHRatio] * SysData.ConfigData[Cfg_CellChgCurr]);
				}
				
				if((xTaskGetTickCount() - FdataTick) >= 60000)	//��ʱ������
				{
					FdataTick = xTaskGetTickCount();
					funFDataAddData( ActSubDev + 1, ActType_EndChg, SysData.Sub[ActSubDev].sVoltmV , -SysData.Sub[ActSubDev].sCurrcA,	-SysData.Sub[ActSubDev].iCelldAH);
				}
					
				if((SysData.Sub[ActSubDev].sVoltmV >= funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1]))) 
					&& (SysData.Sub[ActSubDev].sCurrcA <= SubCellCurrMastoSub) )	//�����
				{
					if((xTaskGetTickCount() - BIMS_ACT_Delay) >= 10000)
					{
						SysData.Act_Step++;		
						SysData.sSetChgVoltmV  = SubCellVoltMin;
						funDAC_OUT(DAC_ChgVolt, SysData.sSetChgVoltmV );	//���������ѹ
						
						SysData.sSetChgCurrcA  = SysData.ConfigData[Cfg_SubAHRatio] * 10;
						funDAC_OUT(DAC_ChgCurr, SysData.sSetChgCurrcA );	//����Ĭ��������� 0.1C
						
						ActRptAddStop(ActSubDev + 1, ActMode_Auto, SysData.Sub[ActSubDev].iCelldAH,  (xTaskGetTickCount() - ActTick) / 1000); 	//�س��¼����	
						
						funFDataAddStop(ActSubDev + 1, ActType_EndChg, ActMode_Auto);
					}
				}
				else
				{
					BIMS_ACT_Delay = xTaskGetTickCount();
				}
							
				if((xTaskGetTickCount() - ActTick) > 64800000)	//��糬 18h
				{//��ʱ
						SysData.Act_Step = 15;	
						ActRptAddStop(ActSubDev + 1, ActMode_Err, -SysData.Sub[ActSubDev].iCelldAH,  (xTaskGetTickCount() - ActTick) / 1000); 	//��¼Ԥ�����
						funFDataAddStop(ActSubDev + 1, ActType_PreChg, ActMode_Err);
				}
				//�жϳ���Ƿ�ɹ�
				if((xTaskGetTickCount() - PwrTick) >= 180000)//��ʱ���޳��
				{
						SysData.Act_Step = 15;	
						ActRptAddStop(ActSubDev + 1, ActMode_Err, -SysData.Sub[ActSubDev].iCelldAH,  (xTaskGetTickCount() - ActTick) / 1000); 	//��¼Ԥ�����
						funFDataAddStop(ActSubDev + 1, ActType_PreChg, ActMode_Err);
				}
				else if((SysData.Sub[ActSubDev].sVoltmV >= funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1]))) //����ѹ�㹻
							|| (SysData.Sub[ActSubDev].sCurrcA >= SubCellCurrMastoSub) )	//�ɳ�����	
				{
					PwrTick = xTaskGetTickCount();
				}
			}
			break;
		case 11:	//�����ɣ���������
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
			{
				BIMS_CAN_TICK = xTaskGetTickCount();
				funCanSend04(ActSubDev + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��	
				funCanSend05(ActSubDev + 1, 0, 0x10, 0xFF00, 0, 0);	//��բ-�رռ̵���
				funCanSend04(ActSubDev + 1, 0, 0x20, 0, 0, 0);	//��ȡ�ŵ�����	
				funCanSend06(ActSubDev + 1, 0, 0x10, 0xFF55, 0, 0);	//������	
			}
			if((SysData.Sub[ActSubDev].iCelldAH == 0)
				&& ((SysData.Sub[ActSubDev].RunSts & SubRunSts_BusON) == 0))
			{
				if((xTaskGetTickCount() - BIMS_ACT_Delay) >= 3000)
				{
					SysData.Act_Step++;
					ActTick = xTaskGetTickCount();	//�-�����ʱ��ʼ
				}
			}
			else
			{
				BIMS_ACT_Delay = xTaskGetTickCount();
			}
			
			if((xTaskGetTickCount() - ActTick) > 30000)	//��ʱ  
			{//��ʱ
			}
			break;
		case 12:	//�ж��Ƿ���Ҫ����
			BUS_CHG_OFF;
			BUS_DSG_OFF;			
			if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 500)	//���ͷ�բ
			{
				BIMS_CAN_TICK = xTaskGetTickCount();				
				funCanSend05(ActSubDev + 1, 0, 0x10, 0xFF00, 0, 0);	//��բ
			}
			if(ActSubDev < SysData.ConfigData[Cfg_SubDevNum])
			{
				if((SysData.Sub[ActSubDev].RunSts & SubRunSts_BusON) == 0)  //��Ӧ��ģ����ȷ�Ϸ�բ
				{
					//SysData.Act_Step++;
					funDAC_OUT(DAC_ChgVolt, SubCellVoltRatio);	//���������ѹ
					SysData.sSetChgCurrcA  = SysData.ConfigData[Cfg_SubAHRatio] * 10;
					funDAC_OUT(DAC_ChgCurr, SysData.sSetChgCurrcA );
					
					BIMS_ACT_Delay = xTaskGetTickCount();
					
					if(SysData.ConfigData[Cfg_PlusEn] != 0)	//��Ҫ����
					{
						SysData.Act_Step ++;
					}
					else
					{
						ActSubDev++;
						SysData.Act_Step = 2;	//���¿�ʼ��һ��
					}	
				}
			}
			break;
		case 13:	//����ȥ��
			BUS_CHG_OFF;
			BUS_DSG_OFF;	
			if(SysData.ConfigData[Cfg_PlusEn] != 0)
			{
				SysData.Act_Step++;
				ActRptAddStart(ActSubDev + 1, ActType_PlusChg);	//��¼��ʼ
				
				funCanSend06(ActSubDev + 1, 0, 0x10, 0xFF55, 0, 0);	//������			
				funCanSend06(ActSubDev + 1, 0, 0x10, 0xFF55, 0, 0);	//������			
				funCanSend06(ActSubDev + 1, 0, 0x10, 0xFF55, 0, 0);	//������	
			}
			else
			{
				ActSubDev++;
			}
			break;
		case 14:	//����ȥ��
			if(SysData.ConfigData[Cfg_PlusEn] != 0)
			{
				if((xTaskGetTickCount() - BIMS_ACT_Delay) >= (SysData.ConfigData[Cfg_PlusTimeMin] * 60))
				{
					funCanSend05(0xFF, 0, 0x13, 0xFF00, 0, 0);
					if((SysData.Sub[ActSubDev].RunSts & RunSts_Plus) == 0)  //��Ӧ��ģ���ѹر�����
					{
						SysData.Act_Step++;							
						ActRptAddStop(ActSubDev + 1, ActMode_Auto, SysData.Sub[ActSubDev].iCelldAH,  (xTaskGetTickCount() - ActTick) / 1000); 	//��¼����
					}
				}
				else
				{
					funCanSend05(ActSubDev + 1, 0, 0x13, 0xFF55, funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1])), 0);
				}
			}
			else
			{
				SysData.Act_Step++;
			}
			break;			
		case 15:	//���ڻ����
			ActSubDev++;
			SysData.Act_Step = 2;	//���¿�ʼ��һ��
			break;
		case 20:	//�����			
			if(funBusSwitchOn() == 1)
			{
				SysData.Act_Step++;
			}
			if((xTaskGetTickCount() - ActTick) >= 30000)	//��ʱ
			{	//ʧ��
				funBIMSoutAct(ActMode_Err);
				SysData.Act_Step = 25;
			}
			//SysData.RunSts &= ~RunSts_Act;
			break;
		case 21:	
			funBIMSoutAct(ActMode_Auto);
			break;
	}
}

/*******************************************************************

********************************************************************/
uint32_t AlChgTick, AlChgTimeOut;
int16_t funBIMStoAlChg(int8_t cell)
{
//	if(((SysData.RunSts & RunSts_Act) == 0)	//δ�
//		&& ((SysData.RunSts & RunSts_AlChg) == 0))	//�����
	{
		SysData.RunSts |= RunSts_AlChg;
		SysData.AlChg_Step = 1;
		SysData.AlChg_Cell = cell;
		AlChgTick = xTaskGetTickCount();
		AlChgTimeOut = xTaskGetTickCount();
	}
	return 0;
}

int16_t funBIMSoutAlChg(int8_t code)
{
	if((SysData.RunSts & RunSts_AlChg) != 0)	//�����
	{
		SysData.RunSts &= ~RunSts_AlChg;
		SysData.AlChg_Step = 0;
		AlChgTick = xTaskGetTickCount();
	}
	return 0;
}
void funAlChg(void)
{
	int8_t i;
	if(SysData.RunSts & RunSts_AlChg)	//Ӧ��
	{
		switch(SysData.AlChg_Step)
		{
			case 1:	//START			
				BUS_CHG_OFF;
				BUS_DSG_OFF;	
				if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
				{
					BIMS_CAN_TICK = xTaskGetTickCount();
					funCanSend05(0xFF, 0, 0x10, 0xFF00, 0, 0);	//�رղɼ���̵���
					funCanSend04(SysData.AlChg_Cell + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
				}
				
				for(i = 0; i < SysData.ConfigData[Cfg_SubDevNum]; i++)
				{
					if(SysData.Sub[i].RunSts & SubRunSts_BusON)	//�ж����вɼ����Ƿ�׼����-δ��բ
					{
						AlChgTick = xTaskGetTickCount();
					}
				}
				if((xTaskGetTickCount() - AlChgTick) >= 3000)
				{
					SysData.AlChg_Step++;
					AlChgTick = xTaskGetTickCount();
				}
				break;
			case 2:	//��բ		
				if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
				{
					BIMS_CAN_TICK = xTaskGetTickCount();
					
					BUS_CHG_ON;
					BUS_DSG_OFF;
					
					SysData.sSetChgVoltmV = SysData.Sub[SysData.AlChg_Cell].sVoltmV;
					SysData.sSetChgCurrcA = SysData.ConfigData[Cfg_SubAHRatio] * SysData.ConfigData[Cfg_CellChgCurr];
					funDAC_OUT(DAC_ChgVolt, SysData.sSetChgVoltmV );
					funDAC_OUT(DAC_ChgCurr, SysData.sSetChgCurrcA );	//����Ĭ��������� 0.1C
					
					funCanSend05(SysData.AlChg_Cell + 1, 0, 0x10, 0xFF55, 0, 0);	//�ɼ���̵���
					funCanSend04(SysData.AlChg_Cell + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
				}
				if((SysData.Sub[SysData.AlChg_Cell].RunSts & SubRunSts_BusCK) != 0)  //��Ӧ��ģ����ȷ�Ϻ�բ
				{
					if((xTaskGetTickCount() - AlChgTick) >= 3000)
					{
						SysData.AlChg_Step++;
						AlChgTick = xTaskGetTickCount();
					}
				}
				else
				{
					AlChgTick = xTaskGetTickCount();
				}
				break;
			case 3:	//�����
				BUS_CHG_ON;
				BUS_DSG_OFF;
				if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
				{
					BIMS_CAN_TICK = xTaskGetTickCount();
					funCanSend04(SysData.AlChg_Cell + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
				}
				if((SysData.Sub[SysData.AlChg_Cell].RunSts & SubRunSts_BusCK) != 0)  //��Ӧ��ģ����ȷ�Ϻ�բ
				{
					funSubChg(SysData.AlChg_Cell, SysData.sAveVoltmV < funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1])) ?
										SysData.sAveVoltmV : funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1])), 
					SysData.ConfigData[Cfg_SubAHRatio] * SysData.ConfigData[Cfg_CellChgCurr]);
					
					if((SysData.Sub[SysData.AlChg_Cell].sVoltmV >= SysData.sAveVoltmV < funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1])) ?
						SysData.sAveVoltmV : funGetFloatVolt(SysData.ConfigData[Cfg_CellVoltTopLimit],  MAX(SysData.Sub[ActSubDev].sTemp[0], SysData.Sub[ActSubDev].sTemp[1]))) 
						&& (SysData.Sub[SysData.AlChg_Cell].sCurrcA <= SubCellCurrMastoSub) )	//�����
					{
						if((xTaskGetTickCount() - AlChgTick) >= 30000)
						{
							SysData.AlChg_Step++;
						}
					}
					else
					{
						AlChgTick = xTaskGetTickCount();
					}
				}
				else
				{
					
				}
				break;
			case 4:	//������
				if((xTaskGetTickCount() - BIMS_CAN_TICK) >= 100)
				{
					BIMS_CAN_TICK = xTaskGetTickCount();
					funCanSend05(0xFF, 0, 0x10, 0xFF00, 0, 0);	//�ɼ���̵���
					funCanSend04(SysData.AlChg_Cell + 1, 0, 0x10, 0, 0, 0);	//���ӵ�ǰģ�����ݻ�ȡƵ��
				}
				if((SysData.Sub[SysData.AlChg_Cell].RunSts & SubRunSts_BusON) == 0)  //��Ӧ��ģ����ȷ�Ϸ�բ
				{
					if((xTaskGetTickCount() - AlChgTick) >= 3000)
					{
						funBIMSoutAlChg(0);
					}
				}
				else
				{
					AlChgTick = xTaskGetTickCount();
				}				
				break;
			default:	//���
				funBIMSoutAlChg(0);
				break;
		}
	}
}
/*******************************************************************

********************************************************************/
int32_t BusSwitchOnTick, BusSwitchOffTick;
//bit0:   ��1
//bit1:   ��2
//bit2:   ��1
//bit3:   ��2
int8_t funBusSwitchRead(void)
{	
	int8_t ret = 0;
	if(SysData.ConfigData[Cfg_SwitchType] == SwitchType_Relay)	//�̵���
	{
		if(RelayP1_Read == Bit_SET)	//��բ״̬
		{
			ret &= ~0x01;
			ret |= 0x04;
		}
		else
		{
			ret &= ~0x04;
			ret |= 0x01;
		}
		
		if(RelayP2_Read == Bit_SET)	//��բ״̬
		{
			ret &= ~0x02;
			ret |= 0x08;
		}
		else
		{
			ret &= ~0x08;
			ret |= 0x02;
		}
	}
	else if(SysData.ConfigData[Cfg_SwitchType] == SwitchType_Motor)	//���
	{
		if(RelayP1_Read == Bit_SET)	//��բ״̬
		{
			ret |= 0x04;
		}
		else
		{
			ret &= ~0x04;
		}
		if(RelayP2_Read == Bit_SET)	//��բ״̬
		{
			ret |= 0x08;
		}
		else
		{
			ret &= ~0x08;
		}		
		
		if(RelayN1_Read == Bit_SET)	//��բ״̬
		{
			ret |= 0x01;
		}
		else
		{
			ret &= ~0x01;
		}
		
		if(RelayN2_Read == Bit_SET)	//��բ״̬
		{
			ret |= 0x02;
		}
		else
		{
			ret &= ~0x02;
		}
	}	
	return ret;
}			
int8_t funBusSwitchOff(void)
{
	int8_t ret = 0;
	if(SysData.ConfigData[Cfg_SwitchType] == SwitchType_Relay)	//�̵���
	{
		if(SysData.ConfigData[Cfg_GroupNum] == 2)	//2��
		{
			RelayP1_ON;
			RelayN1_OFF;
			RelayP2_ON;
			RelayN2_OFF;
			
			if((RelayP1_Read == Bit_SET)	//�̵����Ѷ���
				&& (RelayP2_Read == Bit_SET)	)
			{
				if((xTaskGetTickCount() - BusSwitchOffTick) >= 3000)//��ʱ
				{
					ret = 1;
				}
			}
			else	//�̵���δ����
			{
				BusSwitchOffTick = xTaskGetTickCount();
			}
		}
		else
		{
			RelayP1_ON;
			RelayN1_OFF;
			if(RelayP1_Read == Bit_SET)	//�̵����Ѷ���
			{
				if((xTaskGetTickCount() - BusSwitchOffTick) >= 3000)//��ʱ
				{
					ret = 1;
				}
			}
			else	//�̵���δ����
			{
				BusSwitchOffTick = xTaskGetTickCount();
			}
		}
	}
	else if(SysData.ConfigData[Cfg_SwitchType] == SwitchType_Motor)	//���
	{
		if(SysData.ConfigData[Cfg_GroupNum] == 2)
		{
			RelayP1_OFF;	//�رպ�բ����
			RelayP2_OFF;	//�رպ�բ����
			//1#
			if(RelayN1_Read == Bit_SET)	//��բ״̬
			{
				RelayN1_OFF;	//�رշ�բ����
				if((xTaskGetTickCount() - BusSwitchOffTick) >= 3000)//��ʱ
				{
					ret = 1;
				}					
			}
			else
			{
				RelayN1_ON;	//��բ����
				BusSwitchOffTick = xTaskGetTickCount();
			}
			//2#
			if(RelayN2_Read == Bit_SET)	//��բ״̬
			{
				RelayN2_OFF;	//�رշ�բ����
				if((xTaskGetTickCount() - BusSwitchOffTick) >= 3000)//��ʱ
				{
					ret = 1;
				}					
			}
			else
			{
				RelayN2_ON;	//��բ����
				BusSwitchOffTick = xTaskGetTickCount();
			}
		}
		else
		{
			RelayP1_OFF;	//�رպ�բ����
			if(RelayN1_Read == Bit_SET)	//��բ״̬
			{
				RelayN1_OFF;	//�رշ�բ����
				if((xTaskGetTickCount() - BusSwitchOffTick) >= 3000)//��ʱ
				{
					ret = 1;
				}					
			}
			else
			{
				RelayN1_ON;	//��բ����
				BusSwitchOffTick = xTaskGetTickCount();
			}
		}
	}		
	return ret;
}

int8_t funBusSwitchOn(void)
{	
	int8_t ret = 0;
	if(SysData.ConfigData[Cfg_SwitchType] == SwitchType_Relay)	//�̵���
	{
		if(SysData.ConfigData[Cfg_GroupNum] == 2)
		{
			RelayP1_OFF;
			RelayN1_OFF;
			RelayP2_OFF;
			RelayN2_OFF;
			if((RelayP1_Read == Bit_RESET)	//�̵����Ѷ���
				&& (RelayP2_Read == Bit_RESET)	)
			{
				if((xTaskGetTickCount() - BusSwitchOnTick) >= 3000)//��ʱ
				{
					ret = 1;
				}
			}
			else	//�̵���δ����
			{
				BusSwitchOnTick = xTaskGetTickCount();
			}
			
		}
		else
		{
			RelayP1_OFF;
			RelayN1_OFF;
			if(RelayP1_Read == Bit_RESET)	//�̵����Ѷ���
			{
				if((xTaskGetTickCount() - BusSwitchOnTick) >= 3000)//��ʱ
				{
					ret = 1;
				}
			}
			else	//�̵���δ����
			{
				BusSwitchOnTick = xTaskGetTickCount();
			}
		}
	}
	else if(SysData.ConfigData[Cfg_SwitchType] == SwitchType_Motor)	//���
	{
		if(SysData.ConfigData[Cfg_GroupNum] == 2)
		{
			RelayN1_OFF;	//�رշ�բ����
			RelayN2_OFF;	//�رշ�բ����					
			//1#
			if(RelayP1_Read == Bit_SET)	//��բ״̬
			{
				RelayP1_OFF;	//�رպ�բ����
				if((xTaskGetTickCount() - BusSwitchOnTick) >= 3000)//��ʱ
				{
					ret = 1;
				}					
			}
			else
			{
				RelayP1_ON;	//��բ����
				BusSwitchOnTick = xTaskGetTickCount();
			}
			//2#
			if(RelayP2_Read == Bit_SET)	//��բ״̬
			{
				RelayP2_OFF;	//�رպ�բ����
				if((xTaskGetTickCount() - BusSwitchOnTick) >= 3000)//��ʱ
				{
					ret = 1;
				}					
			}
			else
			{
				RelayP2_ON;	//��բ����
				BusSwitchOnTick = xTaskGetTickCount();
			}
		}
		else
		{
			RelayN1_OFF;	//�رշ�բ����
			if(RelayP1_Read == Bit_SET)	//��բ״̬
			{
				RelayP1_OFF;	//�رպ�բ����
				if((xTaskGetTickCount() - BusSwitchOnTick) >= 3000)//��ʱ
				{
					ret = 1;
				}					
			}
			else
			{
				RelayP1_ON;	//��բ����
				BusSwitchOnTick = xTaskGetTickCount();
			}
		}
	}	
	return ret;
}			

/*******************************************************************
�����Ƽ��ŵ����
********************************************************************/
int8_t funSubChg(uint8_t SubNo, int16_t volt, int16_t Curr)
{
	if(SubNo < SysData.ConfigData[Cfg_SubDevNum])	//���������Ч���
	{
		BUS_CHG_ON;	//�����
		BUS_DSG_OFF;	//�طŵ�
		if((SysData.Sub[SubNo].RunSts & SubRunSts_BusCK) != 0)  //��Ӧ��ģ����ȷ�Ϻ�բ
		{
			if((xTaskGetTickCount() - BIMS_CTRL_TICK) >= 1000)	//���ڳ���ѹ������
			{
				BIMS_CTRL_TICK = xTaskGetTickCount();
				
				if(((SysData.sBusVoltmV + 200) <  SysData.sSetChgVoltmV)	//��ѹ�������
					&& ((SysData.iAI_Value[ADC_Chnl_IC] + 100) <  SysData.sSetChgCurrcA))	//�����������
				{//��״��Ϊ�쳣״̬
					//���豸����
					return -1;
				}
				else if((SysData.sBusVoltmV + 200) <  SysData.sSetChgVoltmV)	//��ѹʵ�����������С��˵������
				{		
					if(SysData.Sub[SubNo].sVoltmV >= (volt + 50))	//��ѹ����
					{//���͵���
						SysData.sSetChgCurrcA -= 20;
					}
					if((SysData.Sub[SubNo].sVoltmV <= volt) 	//δ�����
						&& (SysData.Sub[SubNo].sCurrcA < Curr))
					{
						if(SysData.Sub[SubNo].sCurrcA < (Curr * 0.95))
						{
							SysData.sSetChgCurrcA += 10;
						}
						else
						{
							SysData.sSetChgCurrcA ++;
						}
					}//����Ѿ�����磬�򲻹�
					else if(SysData.Sub[SubNo].sCurrcA > Curr )	//��������
					{
						if(SysData.Sub[SubNo].sCurrcA > (Curr * 1.05))
						{
							SysData.sSetChgCurrcA -= SysData.Sub[SubNo].sCurrcA - Curr ;
							SysData.sSetChgCurrcA -= 10;
						}
						else
						{
							SysData.sSetChgCurrcA --;
						}
					}
				}
				else if((SysData.iAI_Value[ADC_Chnl_IC] + 50) <  SysData.sSetChgCurrcA)	//����ʵ�����������С����ѹ����
				{
					if(SysData.Sub[SubNo].sVoltmV <= volt) 
					{
						SysData.sSetChgVoltmV += 10;
					}
					else if(SysData.Sub[SubNo].sVoltmV >= (volt + 50))	//��ѹ����
					{
						SysData.sSetChgVoltmV -= 10;
					}
				}
				else	//��������
				{
					if(SysData.Sub[SubNo].sVoltmV >= (volt + 50))	//��ѹ����
					{//���͵���
						SysData.sSetChgCurrcA -= 20;
					}
					else if(SysData.Sub[SubNo].sCurrcA > Curr )	//��������
					{
						if(SysData.Sub[SubNo].sCurrcA > (Curr * 1.05))
						{
							SysData.sSetChgCurrcA -= SysData.Sub[SubNo].sCurrcA - Curr ;
							SysData.sSetChgCurrcA -= 10;
						}
						else
						{
							SysData.sSetChgCurrcA --;
						}
					}
					else if((SysData.Sub[SubNo].sVoltmV <= volt) 	//δ�����
						&& (SysData.Sub[SubNo].sCurrcA < Curr))
					{
						if(SysData.Sub[SubNo].sCurrcA < (Curr * 0.95))
						{
							SysData.sSetChgCurrcA += 10;
						}
						else
						{
							SysData.sSetChgCurrcA ++;
						}
					}
				}
				//
				if(SysData.sSetChgVoltmV  < 0)
				{
					SysData.sSetChgVoltmV = 0;
				}
				if(SysData.sSetChgVoltmV  > (volt + 1000))
				{
					SysData.sSetChgVoltmV  = volt + 1000;	//������������ѹ
				}
				if(SysData.sSetChgCurrcA < 0)
				{	SysData.sSetChgCurrcA = 0;}
					funDAC_OUT(DAC_ChgVolt, SysData.sSetChgVoltmV );
				funDAC_OUT(DAC_ChgCurr, SysData.sSetChgCurrcA );	//����Ĭ��������� 0.1C
			}
		}
	}
	return 0;
}


int8_t funSubDsg(uint8_t SubNo, int16_t volt, int16_t Curr)
{
	if(SubNo < SysData.ConfigData[Cfg_SubDevNum])	//���������Ч���
	{
		BUS_CHG_OFF;	//�س��
		BUS_DSG_ON;	//���ŵ�
		if((SysData.Sub[SubNo].RunSts & SubRunSts_BusCK) != 0)  //��Ӧ��ģ����ȷ�Ϻ�բ
		{
			if((xTaskGetTickCount() - BIMS_CTRL_TICK) >= 1000)	//���ڳ���ѹ������
			{
				BIMS_CTRL_TICK = xTaskGetTickCount();
				
				if((SysData.iAI_Value[ADC_Chnl_ID] + 100) <  SysData.sSetDsgCurrcA)	//����ʵ�����������С
				{//�����Ǹ��ز���
					//�˴�������Ҫ���Ӹ���
				}
				else
				{	//��������
					if((-SysData.Sub[ActSubDev].sCurrcA) > Curr )	//
					{
						if((-SysData.Sub[ActSubDev].sCurrcA) > (Curr * 1.05))	//
						{
							SysData.sSetDsgCurrcA -= (-SysData.Sub[ActSubDev].sCurrcA) - (Curr);
							SysData.sSetDsgCurrcA  -= 10;
						}
						else
						{
							SysData.sSetDsgCurrcA  --;
						}
					}
					else if((-SysData.Sub[ActSubDev].sCurrcA) < Curr )	//
					{
						if((-SysData.Sub[ActSubDev].sCurrcA) < (Curr * 0.95))	//
						{
							SysData.sSetDsgCurrcA  += 10;
						}
						else
						{
							SysData.sSetDsgCurrcA  ++;
						}
					}
				}

				if(SysData.sSetDsgCurrcA < 0)
				{	SysData.sSetDsgCurrcA = 0;}
				funDAC_OUT(DAC_DsgCurr, SysData.sSetDsgCurrcA );	//����Ĭ��������� 0.1C
			}
		}
	}
	return 0;
}


/********************************************************************************************************************
��ַģʽ
********************************************************************************************************************/
uint32_t AddrTick;
uint8_t LastAddr;
int16_t funBIMStoAddr(int8_t code)
{
	if((SysData.RunSts & (RunSts_Act | RunSts_Res | RunSts_Addr)) == 0)
	{
		LastAddr = 0;
		SysData.Addr_Step = 1;
		AddrTick = xTaskGetTickCount();
		SysData.RunSts |= RunSts_Addr;
	}
	return 0;
}
int16_t funBIMSOutAddr(int8_t code)
{
	NEXT_OFF;
	if((SysData.RunSts & RunSts_Addr) != 0)
	{
		SysData.Addr_Step = 0;
		SysData.RunSts &= ~RunSts_Addr;
	}
	return 0;
}


void funAddr(void)
{
	if((SysData.RunSts & RunSts_Addr) != 0)
	{
		switch(SysData.Addr_Step)
		{
			case 1:	//DO = 0
				NEXT_ON;
				break;
			case 2:
				NEXT_OFF;
				break;
		}
		if((xTaskGetTickCount() - AddrTick) > 120000)
		{//
			if(LastAddr < SysData.ConfigData[Cfg_SubDevNum])
			{
				funBIMSOutAddr(ActMode_Err);
			}
		}
		else if((xTaskGetTickCount() - AddrTick) > 6000)
		{//
			if(SysData.Addr_Step <= 1)
			{
				funBIMSOutAddr(ActMode_Err);
			}
		}
	}
}

void funAddrCan(uint8_t addr)
{
	LastAddr = addr;
	if(addr >= 1)
	{
		if(SysData.Addr_Step == 1)
		{
			SysData.Addr_Step = 2;
		}
		if(addr >= SysData.ConfigData[Cfg_SubDevNum])
		{
			funBIMSOutAddr(ActMode_Auto);
		}
	}
}


uint32_t NorCanTick, BanlenceTick;
void funBIMS_NoBal(void);
void funNormal(void)
{
	BUS_CHG_ON;
	BUS_DSG_OFF;		
	funDAC_OUT(DAC_ChgVolt, SubCellVoltRatio);	//���������ѹ
	SysData.sSetChgCurrcA  = SysData.ConfigData[Cfg_SubAHRatio] * 10;
	funDAC_OUT(DAC_ChgCurr, SysData.sSetChgCurrcA );
	
	if((xTaskGetTickCount() - NorCanTick) > 500)
	{
		NorCanTick = xTaskGetTickCount();
		funCanSend05(0xFF, 0, 0x10, 0xFF00, 0, 0);	//�㲥��բ
		
		if(SysData.ConfigData[Cfg_NoBal] != 0)	//��������
		{
			if((SysData.RunSts & RunSts_NoBal) != 0)	//����ģʽ
			{
				funBIMS_NoBal();
			}
			else
			{
				funCanSend05(0xFF, 0, 0x12, 0xFF00, 0, 0);	//�㲥����
				if(SysData.sDefVoltmV >= SysData.ConfigData[Cfg_NoBalStartVolt])
				{
					if((xTaskGetTickCount() - BanlenceTick) >= 5000)
					{
						BanlenceTick = xTaskGetTickCount();
						SysData.RunSts |= RunSts_NoBal;
					}
				}
				else
				{
					BanlenceTick = xTaskGetTickCount();
				}
			}
		}
		else
		{
			funCanSend05(0xFF, 0, 0x12, 0xFF00, 0, 0);	//�㲥����
		}
	}
	
}

void funBIMS_NoBal(void)
{
	int16_t i;
	int16_t num, defVolt;
	
	num = SysData.ConfigData[Cfg_SubDevNum] < DevSubMax ? SysData.ConfigData[Cfg_SubDevNum] : DevSubMax;
	
	for(i = 0; i < num; i++)
	{
		defVolt = SysData.Sub[i].sVoltmV - SysData.sAveVoltmV;
		if(defVolt > 0)
		{
			if(defVolt >= SysData.ConfigData[Cfg_NoBalStopVolt])
			{
				funCanSend05(i + 1, 0, 0x12, 0xFF55, (uint16_t )-5, 0);	
			}
		}
		else if(defVolt < 0)
		{
			if(defVolt <= -SysData.ConfigData[Cfg_NoBalStopVolt])
			{
				funCanSend05(i + 1, 0, 0x12, 0xFF55,SubCellVoltEqual, 0);	
			}
		}
		else
		{
			//BanlenceTick = xTaskGetTickCount();
		}
	}

	if(SysData.sDefVoltmV < SysData.ConfigData[Cfg_NoBalStopVolt])
	{
		if((xTaskGetTickCount() - BanlenceTick) >= 5000)
		{
			BanlenceTick = xTaskGetTickCount();
			SysData.RunSts &= ~RunSts_NoBal;
		}
	}
	else
	{
		BanlenceTick = xTaskGetTickCount();
	}
}


//		SysData.bCellMin = -1;
//		SysData.bCellMax = -1;
//		SysData.sAveVoltmV = 0;
//		SysData.sDefVoltmV = 0;
/********************************************************************************************************************
������ͨ��
********************************************************************************************************************/
//			40001	0	����		
//40002	1	���Ӵ������Ʒ�ʽ		
//40003	2	�������	S16	
//40004	3	��ض��ѹ	S16	
//40005	4	��ض����	S16	
//40006	5	�������	S16	
//40007	6			
//40008	7	ͨ�ŵ�ַ<���̨ͨ��>		
//40009	8	������		
//40010	9	У��λ		
//40011	10	����Э��<Э�����>		
//40012	11	����IP1		
//40013	12	����IP2		
//40014	13	����IP3		
//40015	14	����IP4		
//40016	15	�˿�		
//40017	16	Զ�̷�����IP1		
//40018	17	Զ�̷�����IP2		
//40019	18	Զ�̷�����IP3		
//40020	19	Զ�̷�����IP4		
//40021	20			
//40022	21	��������		
//40023	22	����洢ʱ����	S16	
//40024	23	ά���洢ʱ����	S16	
//40025	24			
//40026	25	�Զ������	S16	
//40027	26	�Զ���������	S16	
//40028	27	����ʱ��	S16	
//40029	28	����ʹ��		
//40030	29	����ʹ��		
//				
//40032	31	����ֹ��ѹ	S16	
//40033	32	�ŵ��ֹ��ѹ	S16	
//40034	33	������	S16	
//40035	34	�ŵ����	S16	
//40036	35	��ֹʱ��	S16	
//40037	36	��������ѹ��	S16	
//40038	37	����ֹͣѹ��	S16	
//				
//40041	40	������ѹ�澯	S16	
//40042	41	����Ƿѹ�澯	S16	
//40043	42	��ѹ��ѹ�澯	S16	
//40044	43	��ѹǷѹ�澯	S16	
//40045	44	�����ѹ�澯	S16	
//40046	45	����Ƿѹ�澯	S16	
//40047	46	������¸澯	S16	
//40048	47	����Ƿ�¸澯	S16	
//40049	48	��������	S16	
//40050	49	����Ƿ��	S16	
//40051	50	������	S16	
//40052	51	�ŵ����	S16	
//40053	52	���賬�޸澯	S16	
//40054	53	SOH���޸澯	S16	
//40055	54	������ѹ��޸澯	S16	
//40056	55	���߶��ӹ��¸澯	S16	
extern ResRecordStruct ResRpt[ResRptMax] ;
extern ActRecordStruct ActRpt[ActRptMax] ;

extern AlarmRecordStruct AlarmRpt[AlarmRptMax] ;
extern AlarmRecordStruct ProtectRpt[ProtectRptMax] ;
extern AlarmRecordStruct AlarmList[AlarmListMax] ;
extern DataHeadStruct DataFramHead[3];
extern DataStruct DataFramDat[3][DataFramLen];	//��ȡ�����ݻ���   
extern int16_t DataReadPara[3][3];
extern DataInfoStruct DataInfo[];
uint8_t ComSrc;

void funFdataReadSet(uint8_t src, uint8_t dat_name, int16_t dat);		


const int16_t *Modbus04Table[] = {
	&SysData.RunSts,	//0	״̬	16Bit	RO	
	&SysData.Alarm,//1	�澯	16Bit	RO	
	&SysData.Protect,//2	����״̬<��Ч>	16Bit	RO	
	&SysData.sLineVolt,//3	������ѹ	S16	RO	0.01V
	&SysData.sBatVolt,//4	������ѹ	S16	RO	0.01V
	&SysData.sBatCurr,//5	��������	S16	RO	0.01A
	&SysData.sTemp[0],//6	�¶�1�����¶�	S16	RO	0.1��
	&SysData.sTemp[1],//7	�¶�2�����¶�	S16	RO	0.1��
	&SysData.ConfigData[Cfg_SubDevNum],					//8	�������	S16	RO	
	&SysData.sDefVoltmV,//9	���ѹ��	S16	RO	0.001V
	NULL,//10	��ߵ�ѹ	S16	RO	
	NULL,//11	��͵�ѹ	S16	RO	
	&SysData.bCellMax,//12	��ߵ�ѹ���	S16	RO
	&SysData.bCellMin,//13	��͵�ѹ���	S16	RO	
	&SysData.RunSts,
	&SysData.RunSts,
	NULL,
};


int16_t funSubModbusRx03_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat)
{
	int16_t i;
	int16_t len = 0;
	uint16_t dataddr;
	if((reg < 10000) && ( num <= 127))
	{
		redat[len++] = addr;
		redat[len++] = 0x03;
		redat[len++] = num * 2;
		for(i = 0; i < num; i++)
		{
			dataddr = reg + i;
			if((dataddr) < 64)	//��������
			{
				redat[len++] = SysData.ConfigData[dataddr] >> 8;
				redat[len++] = SysData.ConfigData[dataddr] & 0xFF;	

//				if(Modbus03Table[dataddr] != 0)
//				{
//					redat[len++] = *Modbus03Table[dataddr] >> 8;
//					redat[len++] = *Modbus03Table[dataddr] & 0xFF;	
//				}
//				else
//				{
//					redat[len++] = 0;
//					redat[len++] = 0;	
//				}
			}
			else if(dataddr == 100)	//��������ݼ�¼���	
			{
					redat[len++] = DataReadPara[ComSrc][0] >> 8;
					redat[len++] = DataReadPara[ComSrc][0] & 0xFF;	
			}
			else if(dataddr == 101)	//��������ݼ�¼���	
			{
					redat[len++] = DataReadPara[ComSrc][1] >> 8;
					redat[len++] = DataReadPara[ComSrc][1] & 0xFF;	
			}
			else if(dataddr == 102)	//��������ݼ�¼���	
			{
					redat[len++] = DataReadPara[ComSrc][2] >> 8;
					redat[len++] = DataReadPara[ComSrc][2] & 0xFF;	
			}
			else
			{
					redat[len++] = 0;
					redat[len++] = 0;	
			}
		}		
	}
	return len;
}

extern FDataInfo_STRUCT FDataReadHead;



int16_t funSubModbusRx04_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat)
{
	int16_t dat, i; ;
	int16_t len = 0;
	uint16_t dataddr;
	uint16_t usTemp;
	if((reg < 10000) && ( num <= 127))
	{
		redat[len++] = addr;
		redat[len++] = 0x04;
		redat[len++] = num * 2;
		for(i = 0; i < num; i++)
		{
			dataddr = reg + i;
			if((dataddr) < 14)	//��������
			{
				switch(dataddr)
				{
					case 10://10	��ߵ�ѹ
						if(SysData.bCellMax > 0)
						{
							dat = SysData.Sub[SysData.bCellMax - 1].sVoltmV;
						}
						else
						{
							dat = 0;
						}
						break;
					case 11://11	��͵�ѹ
						if(SysData.bCellMin > 0)
						{
							dat = SysData.Sub[SysData.bCellMin - 1].sVoltmV;
						}
						else
						{
							dat = 0;
						}
						break;
					default:
						dat = *Modbus04Table[dataddr];
						break;
				}
				redat[len++] = dat >> 8;
				redat[len++] = dat & 0xFF;	
			}
			else if((dataddr) < 40)	//����ݼ���Чֵ
			{
				switch(dataddr)
				{
					case 14:	//���ڻ�ĵ�ر��
						if(((SysData.RunSts & RunSts_Act) != 0)
							&& (SysData.Act_Step >= 3))
						{
							dat = ActSubDev + 1;
						}
						else
						{
							dat = 0;
						}
						break;
					case 15:	//�״̬
						if(((SysData.RunSts & RunSts_Act) != 0)
							&& (SysData.Act_Step >= 5))
						{
							if(SysData.Act_Step < 7)	//5~6Ԥ��
							{
								dat = 1;
							}
							else if(SysData.Act_Step < 10)	//7~9	�ŵ�
							{
								dat = 2;
							}
							else if(SysData.Act_Step < 13)	//10~12	�����
							{
								dat = 3;
							}
							else if(SysData.Act_Step <= 15)	//13~15����
							{
								dat = 4;
							}
						}
						else
						{
							dat = 0;
						}
						//dat = SysData.Act_Step;
						break;
					case 16:
						dat = SysData.Sub[ActSubDev].sVoltmV;
						break;
					case 17:
						dat = SysData.Sub[ActSubDev].sCurrcA;
						break;
					case 18:
						dat = SysData.Sub[ActSubDev].iCelldAH;	//��ǰ��������
						break;
					case 19:
						dat = (xTaskGetTickCount() - ActTick) / 1000;	//��ǰ����ʱ��
						break;
					default:
						dat = 0;
						break;
				}
				redat[len++] = dat >> 8;
				redat[len++] = dat & 0xFF;	
			}
			else if((dataddr) < 360)	//���ڵ������
			{
				dataddr -= 40;				
				switch(dataddr % 8)
				{
					case 0:	//״̬
						dat = SysData.Sub[dataddr / 8].RunSts & 0xFF;
						dat |= (SysData.Sub[dataddr / 8].Alarm & 0xFF) << 8;
						break;
					case 1:	//��ѹ
						dat = SysData.Sub[dataddr / 8].sVoltmV;
						break;
					case 2:	//����
						dat = SysData.Sub[dataddr / 8].sCurrcA;	
						break;
					case 3:	//SOH
						//dat = SysData.Sub[dataddr / 8].soh;
						dat = SysData.sLastActValue[dataddr / 8];
						break;
					case 4:	//����
						dat = SysData.sLastResValue[dataddr / 8];
						break;
					case 5:	//�����¶�
						dat = SysData.Sub[dataddr / 8].sTemp[0];
						break;
					case 6:	//�����¶�
						dat = SysData.Sub[dataddr / 8].sTemp[1];
						break;
					case 7:
						dat = 0;
						break;
				}
				redat[len++] = dat >> 8;
				redat[len++] = dat & 0xFF;	
			}
			else if((dataddr) < 400)	//��Ч����
			{
				redat[len++] = 0;
				redat[len++] = 0;	
			}			
			else if((dataddr) == 400)	//ʵʱ�澯��¼����(���15)
			{
				redat[len++] = SysData.AlarmListNum >> 8;
				redat[len++] = SysData.AlarmListNum & 0xFF;	
			}
			else if((dataddr) <= 475)	//15��
			{
				dataddr -= 401;
				
				switch(dataddr % 5)
				{
					case 0://1#�澯��¼-��/��						
						redat[len++] = AlarmList[(dataddr / 5)].Time.Year;
						redat[len++] = AlarmList[(dataddr / 5)].Time.Mon;
						break;
					case 1://��/ʱ
						redat[len++] = AlarmList[(dataddr / 5)].Time.Day;
						redat[len++] = AlarmList[(dataddr / 5)].Time.Hour;
						break;
					case 2://��/��
						redat[len++] = AlarmList[(dataddr / 5)].Time.Min;
						redat[len++] = AlarmList[(dataddr / 5)].Time.Sec;
						break;
					case 3://�澯���ͼ���ر��
						redat[len++] = AlarmList[(dataddr / 5)].CellNumber;
						redat[len++] = AlarmList[(dataddr / 5)].Alarm;
						break;
					case 4://�澯ֵ
						redat[len++] = AlarmList[(dataddr / 5)].Value >> 8;
						redat[len++] = AlarmList[(dataddr / 5)].Value & 0xFF;
						break;
				}
			}
			else if((dataddr) < 1000)	//��Ч����
			{
				redat[len++] = 0;
				redat[len++] = 0;	
			}
			else if((dataddr) == 1000)	//
			{
				redat[len++] = SysData.AlarmRptNum >> 8;
				redat[len++] = SysData.AlarmRptNum & 0xFF;	
			}
			else if((dataddr) <= 1400)	//
			{
				dataddr -= 1001;
				usTemp = SysData.AlarmRptLast + 80;
				usTemp -= dataddr / 5;
				usTemp %= 80;
				switch(dataddr % 5)
				{
					case 0://1#�澯��¼-��/��						
						redat[len++] = AlarmRpt[usTemp].Time.Year;
						redat[len++] = AlarmRpt[usTemp].Time.Mon;
						break;
					case 1://��/ʱ
						redat[len++] = AlarmRpt[usTemp].Time.Day;
						redat[len++] = AlarmRpt[usTemp].Time.Hour;
						break;
					case 2://��/��
						redat[len++] = AlarmRpt[usTemp].Time.Min;
						redat[len++] = AlarmRpt[usTemp].Time.Sec;
						break;
					case 3://�澯���ͼ���ر��
						redat[len++] = AlarmRpt[usTemp].CellNumber;
						redat[len++] = AlarmRpt[usTemp].Alarm;
						break;
					case 4://�澯ֵ
						redat[len++] = AlarmRpt[usTemp].Value >> 8;
						redat[len++] = AlarmRpt[usTemp].Value & 0xFF;
						break;
				}
			}
			else if((dataddr) < 2000)	//��Ч����
			{
				redat[len++] = 0;
				redat[len++] = 0;	
			}
			else if((dataddr) == 2000)	//
			{
				redat[len++] = SysData.sResRptNum >> 8;
				redat[len++] = SysData.sResRptNum & 0xFF;	
			}
			else if((dataddr) <= 2320)	//
			{
				dataddr -= 2001;
				usTemp = SysData.sResRptLast + 64;
				usTemp -= dataddr / 5;
				usTemp %= 64;
				switch(dataddr % 5)
				{
					case 0://1#��¼-��/��						
						redat[len++] = ResRpt[usTemp].Time.Year;
						redat[len++] = ResRpt[usTemp].Time.Mon;
						break;
					case 1://��/ʱ
						redat[len++] = ResRpt[usTemp].Time.Day;
						redat[len++] = ResRpt[usTemp].Time.Hour;
						break;
					case 2://��/��
						redat[len++] = ResRpt[usTemp].Time.Min;
						redat[len++] = ResRpt[usTemp].Time.Sec;
						break;
					case 3://��ر��
						redat[len++] = 0;
						redat[len++] = ResRpt[usTemp].CellNumber;
						break;
					case 4://�澯ֵ
						redat[len++] = ResRpt[usTemp].Value >> 8;
						redat[len++] = ResRpt[usTemp].Value & 0xFF;
						break;
				}
			}
			else if((dataddr) < 3000)	//��Ч����
			{
				redat[len++] = 0;
				redat[len++] = 0;	
			}
			else if((dataddr) == 3000)	//
			{
				redat[len++] = SysData.ActionListNum >> 8;
				redat[len++] = SysData.ActionListNum & 0xFF;	
			}
			else if((dataddr) <= 4700)	//
			{
				dataddr -= 3001;
				usTemp = SysData.ActionListLast + 170;
				usTemp -= dataddr / 10;
				usTemp %= 170;
				switch(dataddr % 10)
				{
					case 0://1#��ʼ-��/��						
						redat[len++] = ActRpt[usTemp].Start.Year;
						redat[len++] = ActRpt[usTemp].Start.Mon;
						break;
					case 1://��/ʱ
						redat[len++] = ActRpt[usTemp].Start.Day;
						redat[len++] = ActRpt[usTemp].Start.Hour;
						break;
					case 2://��/��
						redat[len++] = ActRpt[usTemp].Start.Min;
						redat[len++] = ActRpt[usTemp].Start.Sec;
						break;
					case 3://��ر��
						redat[len++] = ActRpt[usTemp].CellNumber;
						redat[len++] = ActRpt[usTemp].ActType;
						break;
					case 4://ֹͣԭ��/���������Ƿ���Ч(��Էŵ�׶�)
						redat[len++] = 0;
						redat[len++] = ActRpt[usTemp].StopValive;
						break;
					case 5://ֹͣ-��/��						
						redat[len++] = ActRpt[usTemp].Stop.Year;
						redat[len++] = ActRpt[usTemp].Stop.Mon;
						break;
					case 6://��/ʱ
						redat[len++] = ActRpt[usTemp].Stop.Day;
						redat[len++] = ActRpt[usTemp].Stop.Hour;
						break;
					case 7://��/��
						redat[len++] = ActRpt[usTemp].Stop.Min;
						redat[len++] = ActRpt[usTemp].Stop.Sec;
						break;
					case 8://�ʱ��(���18Сʱ)
						redat[len++] = ActRpt[usTemp].ActTime >> 8;
						redat[len++] = ActRpt[usTemp].ActTime & 0xFF;
						break;
					case 9://����(���)
						redat[len++] = ActRpt[usTemp].Value >> 8;
						redat[len++] = ActRpt[usTemp].Value & 0xFF;
						break;
				}
			}		
			else if((dataddr) < 5000)	//��Ч����
			{
				redat[len++] = 0;
				redat[len++] = 0;	
			}	
			else if((dataddr) == 5000)	//���¼����
			{
				redat[len++] = 0;
				redat[len++] = SysData.FDataValiveNum ;	
			}				
			else if((dataddr) <= 5160)	//�����-ͷ
			{
				dataddr -= 5001;
				switch(dataddr % 20)
				{
					case 0:	//5001	
						if((dataddr / 20) < SysData.FDataValiveNum)
						{
							redat[len++] = 0xFF;
							redat[len++] = 0x55;
						}
						else
						{
							redat[len++] = 0x00;
							redat[len++] = 0x00;
						}
						break;
					case 1:	//5002	��¼��ˮ��H
						redat[len++] = (DataInfo[(dataddr / 20 + 1)].SerialNum >> 24) & 0xFF;
						redat[len++] = (DataInfo[(dataddr / 20 + 1)].SerialNum >> 16) & 0xFF;
						break;
					case 2:	//5003	��¼��ˮ��L
						redat[len++] = (DataInfo[(dataddr / 20 + 1)].SerialNum >> 8) & 0xFF;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].SerialNum & 0xFF;
						break;	
					case 3:	//5004	����//����
						redat[len++] = 0;
						redat[len++] = 0;
						break;
					case 4:	//5005	ֹͣԭ��
						redat[len++] = 0;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StopType;
						break;
					case 5:	//5006	��ʼ-��/��
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StartTime.Year;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StartTime.Mon;
						break;
					case 6:	//5007	��/ʱ
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StartTime.Day;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StartTime.Hour;
						break;
					case 7:	//5008	��/��
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StartTime.Min;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StartTime.Sec;
						break;
					case 8:	//5009	����-��/��
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StopTime.Year;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StopTime.Mon;
						break;
					case 9:	//5010	��/ʱ
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StopTime.Day;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StopTime.Hour;
						break;
					case 10:	//5011	��/��
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StopTime.Min;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].StopTime.Sec;
						break;
					case 11:	//5012	���������
						redat[len++] = 0;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].CellNum;
						break;
					case 12:	//5013	��������
						redat[len++] = 0;
						redat[len++] = DataInfo[(dataddr / 20 + 1)].CellActNum;
						break;
					default:
						redat[len++] = 0;
						redat[len++] = 0;
						break;	
				}
			}	//ComSrc
			else if((dataddr) == 6000)	
			{
				if(DataFramHead[ComSrc].SerialNumber != 0)
				{
					redat[len++] = 0xFF;
					redat[len++] = 0x55;
				}
				else
				{
					redat[len++] = 0x00;
					redat[len++] = 0x00;
				}
			}
			else if((dataddr) <= 6020)	
			{
				extern DataStruct DataFramDat[3][DataFramLen];	//��ȡ�����ݻ���   
				switch(dataddr)
				{
					case 6001:
						redat[len++] = (DataFramHead[ComSrc].SerialNumber >> 24) & 0xFF;
						redat[len++] = (DataFramHead[ComSrc].SerialNumber >> 16) & 0xFF;
						break;
					case 6002:
						redat[len++] = (DataFramHead[ComSrc].SerialNumber >> 8) & 0xFF;
						redat[len++] = DataFramHead[ComSrc].SerialNumber & 0xFF;
						break;
					case 6003:	//��ر��
						redat[len++] = 0;
						redat[len++] = DataFramHead[ComSrc].Cell;
						break;
					case 6004:	//��ػ�׶�
						redat[len++] = 0;
						redat[len++] = DataFramHead[ComSrc].Type;
						break;
					case 6005:	//��ػ����
						redat[len++] = 0;
						redat[len++] = DataFramHead[ComSrc].TypeNum;
						break;
					case 6007:	//��ʼ-��/��
						redat[len++] = DataFramHead[ComSrc].StartTime.Year;
						redat[len++] = DataFramHead[ComSrc].StartTime.Mon;
						break;
					case 6008:	//��/ʱ
						redat[len++] = DataFramHead[ComSrc].StartTime.Day;
						redat[len++] = DataFramHead[ComSrc].StartTime.Hour;
						break;
					case 6009:	//��/��
						redat[len++] = DataFramHead[ComSrc].StartTime.Min;
						redat[len++] = DataFramHead[ComSrc].StartTime.Sec;
						break;
					case 6010:	//����-��/��
						redat[len++] = DataFramHead[ComSrc].StopTime.Year;
						redat[len++] = DataFramHead[ComSrc].StopTime.Mon;
						break;
					case 6011:	//��/ʱ
						redat[len++] = DataFramHead[ComSrc].StopTime.Day;
						redat[len++] = DataFramHead[ComSrc].StopTime.Hour;
						break;
					case 6012:	//��/��
						redat[len++] = DataFramHead[ComSrc].StopTime.Min;
						redat[len++] = DataFramHead[ComSrc].StopTime.Sec;
						break;
					case 6013:	//ֹͣԭ��
						redat[len++] = 0;
						redat[len++] = DataFramHead[ComSrc].StopType;
						break;
					case 6014:	//��/ʱ
						redat[len++] = DataFramHead[ComSrc].AH >> 8;
						redat[len++] = DataFramHead[ComSrc].AH;
						break;
					case 6015:	//
						redat[len++] = DataFramHead[ComSrc].DataNum >> 8;
						redat[len++] = DataFramHead[ComSrc].DataNum;
						break;
					default:
						redat[len++] = 0;
						redat[len++] = 0;
						break;
				}
			}
			else if((dataddr) <= 13220)	//�����-����			1200*6 + 6020
			{
				dataddr -= 6021;
				usTemp = dataddr / 6;
				switch(dataddr % 6)
				{
					case 0:	//
						redat[len++] = DataFramDat[ComSrc][usTemp].Time.Year;
						redat[len++] = DataFramDat[ComSrc][usTemp].Time.Mon;
						break;
					case 1:	//
						redat[len++] = DataFramDat[ComSrc][usTemp].Time.Day;
						redat[len++] = DataFramDat[ComSrc][usTemp].Time.Hour;
						break;
					case 2:	//
						redat[len++] = DataFramDat[ComSrc][usTemp].Time.Min;
						redat[len++] = DataFramDat[ComSrc][usTemp].Time.Sec;
						break;

					case 3:	//��ѹ
						redat[len++] = DataFramDat[ComSrc][usTemp].Data.Volt >> 8;
						redat[len++] = DataFramDat[ComSrc][usTemp].Data.Volt & 0xFF;
						break;
					case 4:	//����
						redat[len++] = DataFramDat[ComSrc][usTemp].Data.Curr >> 8;
						redat[len++] = DataFramDat[ComSrc][usTemp].Data.Curr & 0xFF;
						break;
					case 5:	//����
						redat[len++] = DataFramDat[ComSrc][usTemp].Data.AH >> 8;
						redat[len++] = DataFramDat[ComSrc][usTemp].Data.AH & 0xFF;
						break;
				}
			}	
			else
			{
				redat[len++] = 0;
				redat[len++] = 0;	
			}
		}		
	}
	return len;
}

void funFDataClr(void);
void funClrRecord(void);
DateTimeStruct SetDT_temp;

void funFDataReadData(int16_t s);

int16_t funSubModbusRx06_CallBack(uint8_t addr, uint16_t reg, uint16_t dat, uint8_t *redat)
{	
	int16_t len = 0;
	len = 0;
	redat[len++] = addr;
	if(reg < 64)//����
	{
		drvFramWriteConfig(reg, (int16_t *)&dat);	
		//drvFramReadConfig(reg, &);
		SysData.ConfigData[reg] = dat;
		
		//��Ҫ������֤
			redat[len++] = 0x06;
			redat[len++] = reg >> 8;
			redat[len++] = reg & 0xFF;
			redat[len++] = dat >> 8;
			redat[len++] = dat & 0xFF;
	}
	else if(reg == 100)	//��������ݼ�¼���
	{
		//funFDataReadData(dat);
		funFdataReadSet(ComSrc, 0, dat);	
	}	
	else if(reg == 101)	//��������ݼ�¼���
	{
		funFdataReadSet(ComSrc, 1, dat);	
	}	
	else if(reg == 102)	//��������ݼ�¼���
	{
		funFdataReadSet(ComSrc, 2, dat);	
	}
	else if(reg < 110)	//��Ч
	{
	}
	else if(reg <= 115)	//ʱ��
	{
			
		memcpy(&SetDT_temp, &Now, sizeof(DateTimeStruct));

			switch(reg)
			{
				case 110:
					SetDT_temp.Year = dat;
					break;
				case 111:
					SetDT_temp.Mon = dat;
					break;
				case 112:
					SetDT_temp.Day = dat;
					break;
				case 113:
					SetDT_temp.Hour = dat;
					break;
				case 114:
					SetDT_temp.Min = dat;
					break;
				case 115:
					SetDT_temp.Sec = dat;
					break;
			}
		bspSetDateTime(&SetDT_temp);
	}
	else if(reg < 1000)	//��Ч
	{
	}
	else if(reg == 1000)	//�
  {
		if(dat == 0xFF55)
		{
//			#define ActMode_Auto	0x01
//#define ActMode_Hand	0x02
//#define ActMode_Remo	0x03
//#define ActMode_HMI		0x04
			funBIMStoAct(ActMode_Remo);
			redat[len++] = 0x06;
			redat[len++] = reg >> 8;
			redat[len++] = reg & 0xFF;
			redat[len++] = dat >> 8;
			redat[len++] = dat & 0xFF;
		}
		else if(dat == 0xFF00)
		{
			funBIMSoutAct(ActMode_Remo);
			redat[len++] = 0x06;
			redat[len++] = reg >> 8;
			redat[len++] = reg & 0xFF;
			redat[len++] = dat >> 8;
			redat[len++] = dat & 0xFF;
		}
		else
		{
			redat[len++] = 0x86;
			redat[len++] = 1;
		}
	}	
	else if(reg == 1001)	//����
	{		
		if(dat == 0xFF55)
		{
			funBIMStoRes(ActMode_HMI);
			redat[len++] = 0x06;
			redat[len++] = reg >> 8;
			redat[len++] = reg & 0xFF;
			redat[len++] = dat >> 8;
			redat[len++] = dat & 0xFF;
		}
		else if(dat == 0xFF00)
		{
			funBIMSoutRes(ActMode_HMI);
			redat[len++] = 0x06;
			redat[len++] = reg >> 8;
			redat[len++] = reg & 0xFF;
			redat[len++] = dat >> 8;
			redat[len++] = dat & 0xFF;
		}
	}
	else if(reg == 1010)	//��ַ����
	{
		if(dat == 0xFF55)
		{
			funBIMStoAddr(ActMode_HMI);
		}
	}
	else if((reg >= 9000) && (reg <= 9200))
  {
    funADC_Adj(reg - 9000, dat);
    redat[len++] = 0x06;
    redat[len++] = reg >> 8;
    redat[len++] = reg & 0xFF;
    redat[len++] = dat >> 8;
    redat[len++] = dat & 0xFF;
  }
	else if(reg == 10000)	//�������
	{
		if(dat == 0xFF55)
		{
			funFDataClr();
			funClrRecord();
		}
	}
  else
  {
    redat[len++] = 0x86;
    redat[len++] = 02;
  }	
	return len;	
}


int16_t funSubModbusRx10_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *dat, uint8_t *redat)
{
	uint8_t i;
	int16_t dat16, len;
	len = 0;
	redat[len++] = addr;
	if((reg + num) <= 64)
	{
		for(i = 0; i < num; i++)
		{
			dat16 = (dat[2 * i] << 8) | dat[(2 * i) + 1];
			drvFramWriteConfig(reg + i, (int16_t *)&dat16);	
			SysData.ConfigData[reg + i] = dat16;
		}
	}
	else if((reg >= 100) && ((reg + num) <= 103))
	{
		//funFdataReadSet(ComSrc, 0, dat);
		for(i = 0; i < num; i++)
		{
			dat16 = (dat[2 * i] << 8) | dat[(2 * i) + 1];
			funFdataReadSet(ComSrc, reg + i - 100, dat16);
		}
	}
	else if((reg >= 110) && ((reg + num) < 116))	//ʱ��
	{				
		memcpy(&SetDT_temp, &Now, sizeof(DateTimeStruct));
		for(i = 0; i < num; i++)
		{
			
			switch(reg)
			{
				case 110:
					SetDT_temp.Year = dat16;
					break;
				case 111:
					SetDT_temp.Mon = dat16;
					break;
				case 112:
					SetDT_temp.Day = dat16;
					break;
				case 113:
					SetDT_temp.Hour = dat16;
					break;
				case 114:
					SetDT_temp.Min = dat16;
					break;
				case 115:
					SetDT_temp.Sec = dat16;
					break;
			}
		}
		bspGetDateTime(&SetDT_temp);
		//bspGetDateTime(&Now);
	}
	redat[len++] = 0x10;
	redat[len++] = reg >> 8;
	redat[len++] = reg & 0xFF;
	redat[len++] = num >> 8;
	redat[len++] = num & 0xFF;
	
	return len;
}

uint8_t ComFlag[DevSubMax];
void funCanPrase04(uint8_t src, uint8_t cnt, uint8_t cmd , int16_t *dat)
{
	if((src <= 0) || (src > DevSubMax))
	{
		return;
	}
	switch(cmd)
	{
		case 0x10:	//��ͨ����
			SysData.Sub[src - 1].RunSts = dat[0];
			SysData.Sub[src - 1].SubAlarm = dat[1];	
			SysData.Sub[src - 1].sVoltmV = dat[2] > CellVoltDead ? dat[2] : 0;

			ComFlag[src - 1] |= 0x01;
			break;
		case 0x11:	//
			SysData.Sub[src - 1].sVoltmV = dat[0] > CellVoltDead ? dat[0] : 0;
			SysData.Sub[src - 1].sCurrcA = dat[1];
			//SysData.Sub[src - 1].sCurrcA = dat[1] > CellCurrDead ? dat[1] : 0;
			SysData.Sub[src - 1].sCellRes = dat[2];
			ComFlag[src - 1] |= 0x02;
			break;
		case 0x12:	//
//			SysData.Sub[src - 1].sCellcAH = dat[0];
//			SysData.Sub[src - 1].sCellSoh = dat[1];
			SysData.Sub[src - 1].sTemp[0] = dat[0];
			SysData.Sub[src - 1].sTemp[1] = dat[1];
			SysData.Sub[src - 1].sTemp[2] = (int8_t)(dat[2] >> 8) * 10;
			SysData.Sub[src - 1].sTemp[3] = (int8_t)(dat[2] & 0xFF) * 10;
			ComFlag[src - 1] |= 0x04;
			break;
		case 0x13:	//
			ComFlag[src - 1] |= 0x08;
			break;
		case 0x20:	//���������
//			SysData.Sub[src - 1].Act_Step = dat[0] & 0xFF;
			SysData.Sub[src - 1].Res_Step = dat[0] ;//>> 8;
//			SysData.Sub[src - 1].SubReq = dat[1];
			break;
		case 0x21:	//���������
			SysData.Sub[src - 1].iCelldAH = dat[0];	//��ǰ(�ŵ���)����
//			SysData.Sub[src - 1].sCellSoh = dat[1];
//			SysData.Sub[src - 1].sCellRes = dat[2];
			break;
		case 0xC0:	//���ַ			
			if(SysData.RunSts & RunSts_Addr)	//��ַģʽ
			{
				funAddrCan(dat[0] & 0xFF);		
			}
			break;
	}
}




void funCanPrase05(uint8_t src, uint8_t cnt, uint8_t cmd , int16_t *dat)
{
	switch(cmd)
	{
		case 0:	//�
			
			break;
		case 1:	//����
			break;
	}
}

void funCanPrase(uint8_t src, uint8_t cnt, uint8_t *pData)
{
	int16_t dat[3];
	dat[0] = (pData[2] << 8) | pData[3];
	dat[1] = (pData[4] << 8) | pData[5];
	dat[2] = (pData[6] << 8) | pData[7];
	switch(pData[0])
	{
		case 0x04:	//��ѯ
			funCanPrase04(src, cnt, pData[1], dat);
			break;
		case 0x05:	//����
			funCanPrase05(src, cnt, pData[1], dat);
			break;
		case 0x10:	//����
			break;
	}
}


void funData(void)
{
	SysData.sBusVoltmV = SysData.iAI_Value[ADC_Chnl_VBUS] ;
	SysData.sBusCurrcA = SysData.iAI_Value[ADC_Chnl_IC] > SysData.iAI_Value[ADC_Chnl_ID] ? \
										SysData.iAI_Value[ADC_Chnl_IC] : (-SysData.iAI_Value[ADC_Chnl_ID]) ;

	SysData.sBatVolt = SysData.iAI_Value[ADC_Chnl_VBAT] > BatVoltDead ? SysData.iAI_Value[ADC_Chnl_VBAT] : 0;
	SysData.sBatCurr = abs(SysData.iAI_Value[ADC_Chnl_CT]) > BatCurrDead ? SysData.iAI_Value[ADC_Chnl_CT] : 0;
	SysData.sLineVolt = SysData.iAI_Value[ADC_Chnl_LINE] > LineVoltDead ? SysData.iAI_Value[ADC_Chnl_LINE] : 0;
	
	
	SysData.sTemp[0] = drvTempCal(drvADC_Value[ADC_Chnl_T1], drvADC_Value[ADC_Chnl_TREF]);
	SysData.sTemp[1] = drvTempCal(drvADC_Value[ADC_Chnl_T2], drvADC_Value[ADC_Chnl_TREF]);
//	SysData.sTemp[0] = SysData.iAI_Value[ADC_Chnl_T1];
//	SysData.sTemp[1] = SysData.iAI_Value[ADC_Chnl_T2];
//	SysData.sVoltmV = SysData.sAI_Value[0];
}

/******************************************************************************************************

*******************************************************************************************************/
void funAlarmCom(void);
uint32_t uiAlarmTick;
void funAlarmBatVolt(void);
void funCheck(void)
{
	uint8_t i;
	uint16_t subAlarm;
	if((xTaskGetTickCount() - uiAlarmTick) >= 500)
	{
		uiAlarmTick = xTaskGetTickCount();
		
		subAlarm = 0;
		for(i = 0; i < SysData.ConfigData[Cfg_SubDevNum]; i++)
		{
			funAlarmCellVolt(i);
			funAlarmCellTemp(i);
			funAlarmCellPortOT(i);
			
			subAlarm |= SysData.Sub[i].Alarm;
//			if(SysData.Sub[i].SubAlarm & Alarm_SubComErr)
//			{
//				subAlarm |= AlarmSubCOMBit;
//			}
			//
		}
		funAlarmSubTotleAll(subAlarm)	;


		funAlarmAC();
		funAlarmBatVolt();
		funAlarmDefVolt();
	}
	
	funAlarmCom();
}


//#define AlarmSubUVBit (1 << (AlarmSubUV - 1))
//#define AlarmSubOVBit (1 << (AlarmSubOV - 1))
//#define AlarmSubUTBit (1 << (AlarmSubUT - 1))
//#define AlarmSubOTBit (1 << (AlarmSubOT - 1))
//#define AlarmSubORBit (1 << (AlarmSubOR - 1))
//#define AlarmSubOHBit (1 << (AlarmSubOH - 1))
//#define AlarmSubAPBit (1 << (AlarmSubAP - 1))
//#define AlarmSubCOMBit (1 << (AlarmSubCOM - 1))




