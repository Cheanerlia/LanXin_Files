/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include "sys.h"
#include "configure.h"
#include "BSP.h"
#include "tskmain.h"
#include "tskCOM.h"
#include <string.h>
#include <stdlib.h>
#include "stmflash.h"


uint8_t ComSrc;
uint8_t Res_En;
uint32_t CanTimeOutTick;

uint32_t CanResTimeOutTick, CanPlusTimeOutTick;

unsigned short Modbus_CRC16(unsigned char *updata, unsigned short len);
unsigned short Modbus_Send(unsigned char *updata, unsigned short len);

void funADC_Adj(uint16_t no,uint16_t data);
SUBSysDef_STRUCT SysData;
/********************************************************************************************************************
**��������Ҫ����
**
**
**
**
********************************************************************************************************************/
void funSubRes(void);
void funSubToRes(uint8_t mode);
void funSubPlus(void);
void funSubEffective(void);
void funSubOutPlus(void);
void funSubAct(void);

#define   WorkCommand_Res          0x01
#define   WorkCommand_Effective    0x02

#define   ComErr_04      0x01
#define   ComErr_Relay   0x10
#define   ComErr_Res     0x20
#define   ComErr_Banl    0x40
#define   ComErr_Plus    0x80

uint8_t AlarmFlag;

ConfigureStruct    ConfigData;//�û�������������

void funMode(void)
{
	  //���弤��
		if(SysData.RunSts &  RunSts_Plus)
		{
			  funSubPlus();
		}    		
		
		//�������
		if(SysData.RunSts & RunSts_Res)	
		{
			  funSubRes();
		}
		
		//��Ч�Բ���
		if(SysData.RunSts & RunSts_Effective)	  
		{
			  funSubEffective();
		}		
		
		//�����
		if(SysData.RunSts & RunSts_Act)	  
		{
			  funSubAct();
		}			
}

/*
int32_t iCellcAmS;
int32_t iCellAHcnt = 0;
void vApplicationTickHook( void )//ȷ��1MSִ��һ��  ������ֵ  40A 10H  80%
{
		iCellcAmS += SysData.sCurrcA;
		iCellAHcnt++;
		if(iCellAHcnt >= 1000)
		{
				if(abs(SysData.iCellcAS) <= 0x46000000)//1174405120
				{
						SysData.iCellcAS += iCellcAmS / iCellAHcnt;
						iCellcAmS %= iCellAHcnt;
				}
				iCellAHcnt = 0;
		}
}
*/
/******************************************************************************
��ʼ��
*******************************************************************************/
void funSubInit(void)//0
{
		drvPWM_RES(0);//0
	  drvPWM_PLUS(0);
		drvPWM_Eff2(0);	 

	  SysData.RunSts |= RunSts_Init;
}

/******************************************************************************
�������
*******************************************************************************/
uint32_t Plus_Tick;
void funSubToPlus(void)
{
	  if((SysData.Fault == 0)
    &&((SysData.RunSts & RunSts_Act) == 0)       			
		&&((SysData.RunSts & RunSts_Res) == 0)
		&&((SysData.RunSts & RunSts_Effective) == 0)
		&&((SysData.RunSts & RunSts_Plus) == 0))
		{
        Plus_Tick = xTaskGetTickCount();			
				SysData.RunSts |= RunSts_Plus;
		}
}

uint8_t PlusScanSts = 0;
uint8_t PlusScanTimes = 0;
void funSubOutPlus(void)
{
		if((SysData.RunSts & RunSts_Plus) != 0)
		{
				SysData.RunSts &= ~RunSts_Plus;	
        PlusScanSts = 0;	
        PlusScanTimes = 0;			
				drvPWM_PLUS(0);
		}
}

void funSubPlus(void)//��3��,��27S,������10��  �ϼ�5����  1KHZ,5%ռ�ձ�
{
		 if(SysData.Fault == 0)
     {                                     				
					switch(PlusScanSts)
					{
						 case 0://
						 if((xTaskGetTickCount() - Plus_Tick) <= 3000){drvPWM_PLUS(10);}//3S  10%ռ�ձ�
						 else                                         {drvPWM_PLUS(0);PlusScanSts = 1;}                         
						 break;	
						 
						 case 1://
						 if((xTaskGetTickCount() - Plus_Tick) > 30000){PlusScanSts = 2;}//27S  0%ռ�ձ�                   
						 break;				 
				 
						 case 2://
							Plus_Tick = xTaskGetTickCount();
							PlusScanSts = 0;
							PlusScanTimes++;
						  if(PlusScanTimes >= 10)
              {
							    PlusScanTimes = 0;
								  funSubOutPlus();//0%
						  }
						  break;				 
				 
						  default:
						  break;
					}					 
		 }
		 else
		 {
					PlusScanSts = 0;
					PlusScanTimes = 0;
					funSubOutPlus();//0%  
		 }	
}	
	  
/******************************************************************************
������Կ���
*******************************************************************************/
uint32_t Res_Tick;
void funSubToRes(uint8_t mode)
{
	  if((SysData.Fault == 0)
    &&((SysData.RunSts & RunSts_Act) == 0) 			
		&&((SysData.RunSts & RunSts_Res) == 0)
		&&(((SysData.RunSts & RunSts_Effective) == 0) || (((SysData.RunSts & RunSts_Effective) != 0) && (Res_En == 1)))
		&&((SysData.RunSts & RunSts_Plus) == 0))
	  {
				Res_Tick = xTaskGetTickCount();
				SysData.RunSts |= RunSts_Res;
	  }
}

void funSubOutRes(uint8_t mode)//�˳��������ģʽ  
{			
		SysData.RunSts &= ~RunSts_Res;
	  Res_Switch_Flag = 0;
		drvPWM_RES(0);	
}

//�������
void funSubRes(void)
{
		 if(((xTaskGetTickCount() - Res_Tick) < 3000)//3S
		 &&(SysData.Fault == 0))	 
		 {
				drvPWM_RES(50);//TIM4_CH2 50%
		 }
		 else
		 {
			  funSubOutRes(ActMode_Auto);//TIM4_CH2 0%  
		 }
}

/******************************************************************************
�����
*******************************************************************************/
uint32_t  Act_Tick;
void funSubToAct(void)
{
	  if((SysData.Fault == 0)		
		&&((SysData.RunSts & RunSts_Act) == 0)	
		&&((SysData.RunSts & RunSts_Res) == 0)
		&&((SysData.RunSts & RunSts_Effective) == 0) 
		&&((SysData.RunSts & RunSts_Plus) == 0))
	  {
				Act_Tick = xTaskGetTickCount();
				SysData.RunSts |= RunSts_Act;
	  }	
}

void funSubOutAct(void)	//�˳������
{
		SysData.RunSts &= ~RunSts_Act;
}


void funSubAct(void)//ConfigData.Ukm_Act_Limit 
{
	  if((SysData.Fault == 0) && (SysData.sVolt_BatmV >= ConfigData.Ukm_Act_Limit))//�޹��ϡ���ص�ѹ����(����218V)  2M�ж�һ��
		{
			  if((xTaskGetTickCount() - Act_Tick) > 600000)
				{
					  funSubOutAct();
				}																						
		}
    else
		{
			  funSubOutAct();
		}	
}

/******************************************************************************
������Ч�Լ���߼�
*******************************************************************************/
void funSubToEffective(uint16_t mode)
{
	  if((SysData.Fault == 0)
    &&((SysData.RunSts & RunSts_Act) == 0) 			
		&&((SysData.RunSts & RunSts_Res) == 0)
		&&((SysData.RunSts & RunSts_Effective) == 0)
		&&(Effective_Next_En == 1)
		&&((SysData.RunSts & RunSts_Plus) == 0))
		{		
				SysData.RunSts |= RunSts_Effective;
			  Effective_Next_En = 0;
			  Res_Switch_Flag = 0;
			  Effective_Auto_En  = 0;				
		}
}	

void funSubOutEffective(uint16_t mode)
{
		SysData.RunSts &= ~RunSts_Effective;
	  EffectiveScanSts = 0;  	  
		drvPWM_PLUS(0);
		drvPWM_Eff2(0);	   
}	

//��Ч�Բ���
uint8_t  EffectiveScanSts = 0, K = 0, M = 0;
uint8_t  Switch_Off_Flag, Load_Over_Flag, Res_Over_Flag, Res_Switch_Flag, Effective_Switch_Flag;
uint32_t Effective_Tick, temp1, temp2;
int16_t  Bat_V[91] = { 0 };
int16_t  AAA, BBB,CCC,DDD; 
uint8_t  i, j = 0;
int16_t  UU[12] = { 0 };
void funSubEffective(void)
{  
	  //                                                        32V
	  if((SysData.Fault == 0) && (SysData.sVolt_YcmV < ConfigData.Uyc_Limit_Max))//�޹��ϡ�ѹ���ѹ����(����32V)  2M�ж�һ��
		{
					switch(EffectiveScanSts)
					{
						 case 0://�ж�ĸ�ߵ�ѹ�Ƿ�����
							Effective_Switch_Flag = 0;//��λ���������������־
						  Res_En = 0;               //Ŀǰ������������
						  //                                                                                240V
							if((SysData.sVolt_BatmV > ConfigData.Ukm_Limit) && (SysData.sVolt_BatmV < (ConfigData.Ukm_Limit + 1000)))//�����ѹֵ<Ukm<�����ѹֵ+10V
              {
							    EffectiveScanSts = 1;
							}
							else
							{
								  Switch_Off_Flag = 1;
								  UU[0] = SysData.sVolt_BatmV;
							}	 
						  break;  

              case 1://�жϳ��������Ƿ�����  3A
              if(SysData.sCurrcA < ConfigData.Icd_Limit)								
              {
							    EffectiveScanSts = 2;
								  Effective_Switch_Flag = 1;//��λ�����ضϿ������־,׼����ʽ��ʼ����
								  Effective_Tick = xTaskGetTickCount();	
							}
							else
							{
								  Switch_Off_Flag = 1;
								  UU[1] = SysData.sCurrcA;
							}	 
						  break; 

							case 2://����ѹ���ж�
							temp1 = xTaskGetTickCount() - Effective_Tick;	
							if(temp1 >= 1000)													
							{
									//�ж�ѹ���Ƿ�С������ѹ������ֵ  25V
									if(SysData.sVolt_YcmV >= ConfigData.Uyc_Limit_Res){Load_Over_Flag = 1;Switch_Off_Flag = 1;UU[2] = SysData.sVolt_YcmV;}
									else                                             	{EffectiveScanSts = 3;}																																							
							}
							break;
							
              case 3:	//��������軷��						
						  Res_En = 1;//��λ��������������Ա�־
              funSubToRes(Auto);	
              EffectiveScanSts = 4;
              break;			

              case 4://��������̼���							
						  Res_En = 0;
              if((SysData.RunSts & RunSts_Res) == 0)//������Խ���
              {
								  //                                2000mm��
								  if(SysData.sCellRes > ConfigData.Res_Limit){Res_Over_Flag = 1;Switch_Off_Flag = 1;}
							    else                                       {Res_Over_Flag = 0;EffectiveScanSts = 5;Effective_Tick = xTaskGetTickCount();}
							}
              else
              {
									//                                  240V  
									if(SysData.sVolt_ChgmV >  ConfigData.Ukm_Limit + 1000)
                      {Switch_Off_Flag = 1;UU[4] = SysData.sVolt_ChgmV;}								
							}								
              break;

							case 5:
							    if((xTaskGetTickCount() - Effective_Tick) >= 1000)
                   {EffectiveScanSts = 6;Effective_Tick = xTaskGetTickCount();}//���1��
              break;

							case 6:	
							EffectiveScanSts = 7;
							drvPWM_PLUS(100);//�������һ·PWM����100%
							drvPWM_Eff2(100);//������ض�·PWM����100%									
							Effective_Tick = xTaskGetTickCount();
              break; 	 	

							case 7:	//�ж�1Sѹ��
							temp1 = xTaskGetTickCount() - Effective_Tick;		
							if(temp1 >= 1000)
							{   
								  //                                   10V
								  if(SysData.sVolt_YcmV >= ConfigData.Uyc_Limit_1S){Load_Over_Flag = 1;Switch_Off_Flag = 1;UU[7] = SysData.sVolt_YcmV;}
								  else                                             {EffectiveScanSts = 8;}									
									Effective_Tick = xTaskGetTickCount();
							}
              break; 	

							case 8:	//�ж�6Sѹ��							
							temp1 = xTaskGetTickCount() - Effective_Tick;	
							if(temp1 >= 1000)
							{
									j++;
								  //                                    15V
									if(SysData.sVolt_YcmV >= ConfigData.Uyc_Limit_6S){Load_Over_Flag = 1;Switch_Off_Flag = 1;UU[8] = SysData.sVolt_YcmV;}				
									else                                             {if(j >= 5){EffectiveScanSts = 9;}}								
									Effective_Tick = xTaskGetTickCount();							
							}	
							break; 

							case 9:	//�ж�15Sѹ��
							K = 0;							
							temp1 = xTaskGetTickCount() - Effective_Tick;
							if(temp1 >= 1000)
              {
								  j++;
								  //                                    20V
									if(SysData.sVolt_YcmV >= ConfigData.Uyc_Limit_15S){Load_Over_Flag = 1;Switch_Off_Flag = 1;UU[9] = SysData.sVolt_YcmV;}				
									else                                              
									{
											if(j >= 9)    //ԭΪ14����Ϊ10sѹ��
                      {
												 EffectiveScanSts = 10;											 
												 drvPWM_PLUS(0);//�������һ·PWM�ر�
												 drvPWM_Eff2(0);//������ض�·PWM�ر�
                         Bat_V[K] = SysData.sVolt_BatmV;												
										  }    
									}
                  Effective_Tick = xTaskGetTickCount();																																												
							}
              break;							
																			 
							case 10:	//���90���ڼ��ĸ�ߵ�ѹÿ��仯��,�ȴ����ص�ѹ�����ȶ���								
							temp1 = xTaskGetTickCount() - Effective_Tick;	
							if(temp1 >= 1000)
              {
								  j++;
								  K++;
									Bat_V[K] = SysData.sVolt_BatmV;
									if((Bat_V[K - 1] - Bat_V[K]) < 10){EffectiveScanSts = 11;}//ĸ�ߵ�ѹ�½��ʵ���100mV/S
									else                              {if(j >= 104){EffectiveScanSts = 11;}}                 
                  Effective_Tick = xTaskGetTickCount();										
							}
              break;																

							case 11://�����ĸ�ѭ��������ɼ���
							if((xTaskGetTickCount() - Effective_Tick) <= 1000)//��1��
              {
									drvPWM_PLUS(100);//��Ч�Բ���һ·PWM����100%
									drvPWM_Eff2(100);//��Ч�Բ��Զ�·PWM����100%								
							}
              else if((xTaskGetTickCount() - Effective_Tick) <= 30000)//��29��	
              {
									drvPWM_PLUS(0);
									drvPWM_Eff2(0);				
							} 
              if((xTaskGetTickCount() - Effective_Tick) >= 30000)
              {
								  Effective_Tick = xTaskGetTickCount();
									M++;
									if(M >= 4)//����4�ν������Թ���
									{
										 M = 0;
										 Switch_Off_Flag = 1;
									}									  
							} 								
							
							if(SysData.sVolt_BatmV < ConfigData.Ukm_Trip){Load_Over_Flag = 1;Switch_Off_Flag = 1;UU[11] = SysData.sVolt_BatmV;}                        
						  break;							
								
						  default:
						  break;
					}	
          
					//���賬����ָ��߼�
          if(Res_Over_Flag == 1){SysData.Alarm  |= Inter_ResOver;}
          else                  {SysData.Alarm &= ~Inter_ResOver;}
					//���س�����ָ��߼�
          if(Load_Over_Flag == 1){SysData.Alarm  |= Load_Over;}
          else                   {SysData.Alarm &= ~Load_Over;}					
			   
					if(Switch_Off_Flag == 1)
          {
						  funSubOutEffective(Auto);
						  funSubOutRes(Auto);
						
						  EffectiveScanSts = 0;						
						  Res_Over_Flag = 0;
						  Load_Over_Flag = 0;
						  Switch_Off_Flag = 0;
						  Effective_Switch_Flag = 0;
						
						  K = 0;
						  M = 0;
						  j = 0;
					}									
		}
    else
    {  
					if(SysData.sVolt_YcmV >= ConfigData.Uyc_Limit_Max){SysData.Alarm  |= Load_Over;}//ѹ���ѹ�쳣(����32V)
					
					funSubOutEffective(Auto);
					funSubOutRes(Auto);

					EffectiveScanSts = 0;				
					Res_Over_Flag = 0;
					Load_Over_Flag = 0;
					Switch_Off_Flag = 0;
					Effective_Switch_Flag = 0;
				
					K = 0;
					M = 0;
					j = 0;									
		}			
}	

/********************************************************************************************************************
������ͨ��
********************************************************************************************************************/
int16_t DataZero = 0;

int16_t *Rx04table[] = 
{
		//0-9
		&SysData.Alarm,      //�澯��     30001
		&SysData.Fault,      //������     30002
		&SysData.RunSts,     //����״̬   30003
		&SysData.sVolt_BatmV,//��ص�ѹ   30004
		&SysData.sCurrcA,    //��ص���   30005
		&SysData.sVolt_ChgmV,//�ܵ�ѹ     30006
		&SysData.sVolt_YcmV, //�Ŷѵ�ѹ   30007
		&SysData.sTemp[0],   //�����¶�   30008
		&SysData.sTemp[1],   //����3�¶�  30009
		&SysData.sTemp[2],   //����2�¶�  30010
	
		//10-19
		&SysData.sTemp[3],   //����1�¶�  30011
		&SysData.sCellRes,   //�������   30012
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		
		//20-29
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		
		//30-39
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		
		//40-49
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		
		//50-59
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		
		//60-69
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		
		//70-79
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		
		//80-89
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		
		//90-99
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		
		//100-109
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
		&DataZero,
};


int16_t funSubModbusRx03_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat)//40001��ʼ
{
		int16_t i;
		int16_t len = 0;
		int16_t *pdata;
	
		//       100              100 + 22
		if((reg >= 100) && ((reg + num) <= 132))//�û���������
		{
				pdata = (int16_t *)&ConfigData;
			
				redat[len++] = addr;   //
				redat[len++] = 0x03;   //TxBuf[1]Ϊ0x04
				redat[len++] = num * 2;//TxBuf[2]Ϊdat * 2
				
				for(i = 0; i < num; i++)
				{      
						redat[len++] = pdata[reg + i - 100] >> 8;  //��8λ
						redat[len++] = pdata[reg + i - 100] & 0xFF;//��8λ
				}		
		}
		return len;
}

int16_t HostTxLen;
int16_t funSubModbusRx04_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat)//30001��ʼ
{
		int16_t i;
		int16_t len = 0;
	
		if((reg < 100) && ((reg + num) < 100))
		{
				redat[len++] = addr;
				redat[len++] = 0x04;
				redat[len++] = num * 2;
				for(i = 0; i < num; i++)
				{
						redat[len++] = *Rx04table[reg + i] >> 8;
						redat[len++] = *Rx04table[reg + i] & 0xFF;			
				}		
		}
		
		return len;
}

	
int16_t funSubModbusRx06_CallBack(uint8_t addr, uint16_t reg, uint16_t dat, uint8_t *redat)
{	
	  ConfigureStruct   ConfigTempData;
		int16_t len = 0,*pdat;
	
		redat[len++] = addr;
	
		if((reg >= 100) && (reg <= 116))//����
		{
			
			  memcpy(&ConfigTempData, (void *)&ConfigData, sizeof(ConfigureStruct));//ConfigData������ConfigTempData
			
				pdat = (int16_t *)&ConfigTempData;
		
				pdat[reg - 100] = (shostUSART_RxBuf[4] << 8) | shostUSART_RxBuf[5];//ˢ��ConfigTempData����
					
				
				//���û��������ݱ�����Flash
				ConfigTempData.Check = 0x55AA;
        Modbus_Send((uint8_t *)&ConfigTempData, sizeof(ConfigureStruct) - 2);	
				
				STMFLASH_Write(FLASH_SAVE_ADDR2, (u16 *)&ConfigTempData, (sizeof(ConfigureStruct) / 2));//��ConfigTempData���ݴ���Flash
				
				funConfig_Cal_Init();	 
			  pdat = (int16_t *)&ConfigData;
			  
				redat[len++] = 0x06;
				redat[len++] = reg >> 8;
				redat[len++] = reg & 0xFF;
				redat[len++] = pdat[reg - 100] >> 8;
				redat[len++] = pdat[reg - 100] & 0xFF;
		}

	
		else if(reg ==0)//0 �����
		{
				if(dat == 0xFF55)	    //65365  ��������
				{
						funSubToAct();
						redat[len++] = addr;
						redat[len++] = 0x06;
						redat[len++] = reg >> 8;
						redat[len++] = reg & 0xFF;
						redat[len++] = dat >> 8;
						redat[len++] = dat & 0xFF;
				}
				else if(dat == 0xFF00)//65280  �˳������
				{
						funSubOutAct();
						redat[len++] = addr;
						redat[len++] = 0x06;
						redat[len++] = reg >> 8;
						redat[len++] = reg & 0xFF;
						redat[len++] = dat >> 8;
						redat[len++] = dat & 0xFF;
				}
				else
				{
						redat[len++] = addr;
						redat[len++] = 0x86;
						redat[len++] = 1;
				}
		}
		else if(reg == 1)//1 �����������
		{
				if(dat == 0xFF55)
				{
						funSubToRes(ActMode_Remo);
					  Res_Switch_Flag = 1;//����������,�����Ͽ����п���
						redat[len++] = addr;
						redat[len++] = 0x06;
						redat[len++] = reg >> 8;
						redat[len++] = reg & 0xFF;
						redat[len++] = dat >> 8;
						redat[len++] = dat & 0xFF;
				}
				else if(dat == 0xFF00)
				{
						funSubOutRes(ActMode_Remo);
						redat[len++] = addr;
						redat[len++] = 0x06;
						redat[len++] = reg >> 8;
						redat[len++] = reg & 0xFF;
						redat[len++] = dat >> 8;
						redat[len++] = dat & 0xFF;
				}
				else
				{
						redat[len++] = addr;
						redat[len++] = 0x86;
						redat[len++] = 1;
				}
		}
		else if(reg == 2)//2 �������
		{	
				if(dat == 0xFF55)
				{
						funSubToPlus();
						redat[len++] = addr;
						redat[len++] = 0x06;
						redat[len++] = reg >> 8;
						redat[len++] = reg & 0xFF;
						redat[len++] = dat >> 8;
						redat[len++] = dat & 0xFF;
				}
				else if(dat == 0xFF00)
				{
						funSubOutPlus();
						redat[len++] = addr;
						redat[len++] = 0x06;
						redat[len++] = reg >> 8;
						redat[len++] = reg & 0xFF;
						redat[len++] = dat >> 8;
						redat[len++] = dat & 0xFF;
				}
		}
		else if(reg == 3)	//3 ��Ч�Բ���
		{	
				if(dat == 0xFF55)
				{
						funSubToEffective(Remo);  
						redat[len++] = addr;
						redat[len++] = 0x06;
						redat[len++] = reg >> 8;
						redat[len++] = reg & 0xFF;
						redat[len++] = dat >> 8;
						redat[len++] = dat & 0xFF;
				}
				else if(dat == 0xFF00)
				{
						funSubOutEffective(Remo);  
						redat[len++] = addr;
						redat[len++] = 0x06;
						redat[len++] = reg >> 8;
						redat[len++] = reg & 0xFF;
						redat[len++] = dat >> 8;
						redat[len++] = dat & 0xFF;
				}
		}		
		else if((reg >= 9000) && (reg <= 9200))//У׼  49001��ʼ
		{
				funADC_Adj(reg - 9000, dat);
				redat[len++] = 0x06;
				redat[len++] = reg >> 8;
				redat[len++] = reg & 0xFF;
				redat[len++] = dat >> 8;
				redat[len++] = dat & 0xFF;
		}
		else
		{
				redat[len++] = 0x86;
				redat[len++] = 02;
		}
		
		return len;	
}


//Modbus10�������,д���û��������� 
int16_t funSubModbusRx10_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat)//40001��ʼ
{
		ConfigureStruct   ConfigTempData;
		uint16_t i;  
		int16_t  tlen = 0, *pdat;         
					
		//100 
		if((reg >= 100) && (reg <= 200))//40101��ʼ �Զ������ 
		{
				memcpy(&ConfigTempData, (void *)&ConfigData, sizeof(ConfigureStruct));//ConfigData������ConfigTempData
			
				pdat = (int16_t *)&ConfigTempData;
			
				for(i = 0; i < num; i++)
				{
						if((i + reg) < 132)
						{
								pdat[i + reg - 100] = (shostUSART_RxBuf[7 + (2 * i)] << 8) | shostUSART_RxBuf[8 + (2 * i)];//ˢ��ConfigTempData����
						}
						else{break;}
				}
				
				//���û��������ݱ�����Flash
				ConfigTempData.Check = 0x55AA;
        Modbus_Send((uint8_t *)&ConfigTempData, sizeof(ConfigureStruct) - 2);	
				
				STMFLASH_Write(FLASH_SAVE_ADDR2, (u16 *)&ConfigTempData, (sizeof(ConfigureStruct) / 2));//��ConfigTempData���ݴ���Flash
				
				funConfig_Cal_Init();	 
				
				tlen = 0;
				redat[tlen++] = addr;					
				redat[tlen++] = 0x10;
				redat[tlen++] = reg >> 8;
				redat[tlen++] = reg & 0xFF;
				redat[tlen++] = num >> 8;
				redat[tlen++] = num & 0xFF;
		}  
		else
		{
				tlen = 0;
				redat[tlen++] = addr;
				redat[tlen++] = 0x90;
				redat[tlen++] = 0x03;
		}
		
		return tlen;
}


void funCanPrase04(uint8_t src, uint8_t cnt, uint8_t cmd , int16_t *dat)
{
		switch(cmd)
		{
			case 0x10:	//��ͨ����
				funCanSend04(src, 0, 0x10, SysData.RunSts ,SysData.Alarm, SysData.iCellcAS / 3600);//״̬������״̬(��Ч), ��ѹ��
				funCanSend04(src, 0, 0x11, SysData.sVolt_BatmV ,SysData.sCurrcA, SysData.sCellRes);	   //��ѹ������ ����
				funCanSend04(src, 0, 0x12, SysData.sTemp[0] , SysData.sTemp[1],  ((SysData.sTemp[2] / 10) << 8) | (SysData.sTemp[3] / 10));//����(���)�¶�1��2�������¶�
				funCanSend04(src, 0, 0x13, SysData.iCellcAS / 3600, 0, 0);	//��ǰ(�ŵ���)����

				CanTimeOutTick = xTaskGetTickCount();
				AlarmFlag &= ~ComErr_04;

				break;
				
			case 0x20:	//���������
				break;
			
			case 0x30:	//����
				break;
			
			case 0xC0:	//���ַ			
				break;
		}
}


void funCanPrase05(uint8_t src, uint8_t cnt, uint8_t cmd , int16_t *dat)
{
		if(SysData.RunSts & RunSts_Init)	//��ʼ��������,������CAN
		{
			  return;
		}
		switch(cmd)
		{
			  case 0x10:	//�
				if(*dat == (int16_t)0xFF55)	    //��������
				{
					  funSubToAct();
				}
				else if(*dat == (int16_t)0xFF00)//�˳������
				{
					  funSubOutAct();
				}
				
			  case 0x11:	//����
				if(*dat == (int16_t)0xFF55)	//��ʼ������
				{
					  funSubToRes(ActMode_Remo);
					  Res_Switch_Flag = 1;//����������,�����Ͽ����п���
				}
				else if(*dat == (int16_t)0xFF00)//ֹͣ������
				{
					  funSubOutRes(ActMode_Remo);
				}
				CanResTimeOutTick = xTaskGetTickCount();
				break;
				
			  case 0x12:	//��Ч�Բ���
				if(*dat == (int16_t)0xFF55)	
				{
					  funSubToEffective(Remo);
				}
				else if(*dat == (int16_t)0xFF00)
				{
					  funSubOutEffective(Remo);
				}					
				break;
				
			  case 0x13:	//����
				if(*dat == (int16_t)0xFF55)	//��ʼ����
				{
					  funSubToPlus();
				}
				else if(*dat == (int16_t)0xFF00)	//ֹͣ����
				{
					  funSubOutPlus();
				}
				CanPlusTimeOutTick = xTaskGetTickCount();
				break;
				
			  case 0x1F:	//2021-08-29���������ڹر�����ģʽ
				if(*dat == (int16_t)0xFF00)	//ֹͣ����
				{					
						if(SysData.RunSts &  RunSts_Plus )
						{
							  funSubOutPlus();
						}					
				}
				break;
		}
}

void funCanPrase(uint8_t src, uint8_t cnt, uint8_t *pData)
{
		int16_t dat[3];
		
		dat[0] = (pData[2] << 8) | pData[3];
		dat[1] = (pData[4] << 8) | pData[5];
		dat[2] = (pData[6] << 8) | pData[7];
	
		switch(pData[0])
		{
				case 0x04:	//��ѯ
					funCanPrase04(src, cnt, pData[1], dat);
					break;
				
				case 0x05:	//����
					funCanPrase05(src, cnt, pData[1], dat);
					break;
				
				case 0x06:	//����
					break;
				
				case 0x10:	//����
					break;
				
				case 0xF0:	//ϵͳ���⹦��
					break;
		}
}

//int32_t  temp32;
float  temp32;
void funData(void)
{
	  //��ص�ѹ
	  if(SysData.iAI_Value[ADC_ChnlSub_Volt2] < SysData.iAI_Value[ADC_ChnlSub_Volt1])
		{
			  SysData.sVolt_BatmV  = SysData.iAI_Value[ADC_ChnlSub_Volt2];//0       ��ص�ѹ
		}
    else
		{
			  SysData.sVolt_BatmV  = SysData.iAI_Value[ADC_ChnlSub_Volt1];//0       ��ص�ѹ
		}	
		
    //�ܵ�ѹ		
		SysData.sVolt_ChgmV  = SysData.iAI_Value[ADC_ChnlSub_Volt1];//1           �ܵ�ѹ

    //ѹ��(�Ŷ�)��ѹ		
    if(SysData.sVolt_ChgmV >= SysData.sVolt_BatmV){SysData.sVolt_YcmV = SysData.sVolt_ChgmV - SysData.sVolt_BatmV;}//   �Ŷѵ�ѹ
    else                                          {SysData.sVolt_YcmV = 0;} 	 	
		
		//��ص���
	  SysData.sCurrcA  = SysData.iAI_Value[ADC_ChnlSub_AI_I_CT];//2  3  ��ص���
											
		//�¶ȼ���                                                                     7
		SysData.sTemp[0] = drvTempCal(drvADC_Value[ADC_ChnlSub_T1], drvADC_Value[ADC_ChnlSub_TREF]);//11
		SysData.sTemp[1] = drvTempCal(drvADC_Value[ADC_ChnlSub_T2], drvADC_Value[ADC_ChnlSub_TREF]);//10
		SysData.sTemp[2] = drvTempCal(drvADC_Value[ADC_ChnlSub_T3], drvADC_Value[ADC_ChnlSub_TREF]);//9
		SysData.sTemp[3] = drvTempCal(drvADC_Value[ADC_ChnlSub_T4], drvADC_Value[ADC_ChnlSub_TREF]);//8
	
	  if(SysData.RunSts & RunSts_Res)//������� 
		{
				temp32 = ((float)drvADC_Value[ADC_ChnlSub_VRES] * 1000) / SysData.iAI_Value[ADC_ChnlSub_Volt2];
				temp32 += AdjData.CALdata[ADC_ChnlSub_VRES].offset;
				temp32 *= ADC_RADIO ;
				temp32 = temp32 /  AdjData.CALdata[ADC_ChnlSub_VRES].radio;
				if(temp32 > 3000)  { temp32 = 3000;}//����������Χ3000mm��
				else if(temp32 < 0){ temp32 = 0;}				
				SysData.sCellRes = (int16_t)temp32;//	

				//�����������ʱ�����ж����賬��״̬
				if(Res_Switch_Flag == 1)
				{
						if(SysData.sCellRes > ConfigData.Res_Limit){SysData.Alarm |=  Inter_ResOver;}
						else                                       {SysData.Alarm &= ~Inter_ResOver;}					
				}	
		}		
}

//============================================================================================================================
// No more.
//============================================================================================================================
