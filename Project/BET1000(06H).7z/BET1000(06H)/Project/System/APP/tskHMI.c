#include "stm32f4xx.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include "sys.h"
#include "configure.h"
#include "bspBIMS.h"
#include "BSP.h"
#include "BSP.h"

#include <string.h>

extern AlarmRecordStruct AlarmList[AlarmListMax];
extern AlarmRecordStruct AlarmRpt[AlarmRptMax] ;
extern ResRecordStruct ResRpt[ResRptMax] ;
extern ActRecordStruct ActRpt[ActRptMax] ;


extern int8_t drvFramReadConfig(int16_t Number, int16_t *dat);
extern int8_t drvFramWriteConfig(int16_t Number, int16_t *dat);
extern int32_t drvFramWrite(uint16_t FramAddr, uint8_t *buf, int32_t len);
extern unsigned short Modbus_CRC16(unsigned char *updata, unsigned short len);
extern unsigned short Modbus_Send(unsigned char *updata, unsigned short len);

//UART5  HMI  �ⲿ��̬��
//UART2  LCD 	�Դ���

#define HMI_SerialPort	5		//�ⲿ��̬��	-485
//#define HMI_SerialPort	4		//�ⲿ��̬��
#define LCD_SerialPort	1		//�Դ���

#define LCD_RxBufMax	264
#define HMI_RxBufMax	264
#define LCD_TxBufMax	264
#define HMI_TxBufMax	264


void funConfig_Init(void);

uint8_t LCD_RxBuf[LCD_RxBufMax], LCD_TxBuf[LCD_TxBufMax];
uint8_t HMI_RxBuf[HMI_RxBufMax], HMI_TxBuf[HMI_TxBufMax];



int16_t HMI_RxLenTemp;
int16_t sHMI_RxLen, sLCD_RxLen;
int16_t sHMI_TxLen, sLCD_TxLen;

int16_t funSubModbusRx03_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat);
int16_t funSubModbusRx04_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat);
int16_t funSubModbusRx06_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat);
int16_t funSubModbusRx10_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *dat, uint8_t *redat);

//BIMSConfig_STRUCT ConfigTemp;	//���ڱ���Ĳ�������
extern uint8_t ComSrc;


void threadHMI(void *pvParameters)
{
	uint16_t reg, dat;
	USARTx_Init(LCD_SerialPort, 115200, USART_Parity_No);	
	
	USARTx_Init(HMI_SerialPort, 115200, USART_Parity_No);	
	for(;;)
	{
		//�Դ�LCD
		HMI_RxLenTemp = USARTx_Rec(LCD_SerialPort, &LCD_RxBuf[sLCD_RxLen], LCD_RxBufMax - sLCD_RxLen);
		sLCD_RxLen += HMI_RxLenTemp;
		if((sLCD_RxLen != 0) && (HMI_RxLenTemp == 0))
		{
			//USARTx_Send(LCD_SerialPort, LCD_RxBuf, sLCD_RxLen);
#if 1		
			if((sLCD_RxLen >= 5)
				&& ((LCD_RxBuf[0] == 0x01) || (LCD_RxBuf[0] == 0x00)))	//��ַ�Ի�㲥
			{
				if(Modbus_CRC16(LCD_RxBuf, sLCD_RxLen) == 0)
				{
					sLCD_TxLen = 0;
					reg = (LCD_RxBuf[2] << 8 ) | LCD_RxBuf[3];
					dat = (LCD_RxBuf[4] << 8 ) | LCD_RxBuf[5];
					
					switch(LCD_RxBuf[1])
					{
						case 0x03:
							if(sLCD_RxLen == 8)
							{
								ComSrc = 0;
								sLCD_TxLen = funSubModbusRx03_CallBack(LCD_RxBuf[0], reg, dat, LCD_TxBuf);
							}
							break;
						case 0x04:
							if(sLCD_RxLen == 8)
							{
								ComSrc = 0;
								sLCD_TxLen = funSubModbusRx04_CallBack(LCD_RxBuf[0], reg, dat, LCD_TxBuf);
							}
							break;
						case 0x06:
							if(sLCD_RxLen == 8)
							{
								ComSrc = 0;
								sLCD_TxLen = funSubModbusRx06_CallBack(LCD_RxBuf[0], reg, dat, LCD_TxBuf);
							}
							break;
						case 0x10:
							//if(sLCD_RxLen == 8)
							{
								ComSrc = 0;
								sLCD_TxLen = funSubModbusRx10_CallBack(LCD_RxBuf[0], reg, dat, &LCD_RxBuf[7], LCD_TxBuf);
							}
							break;
					}
					if((sLCD_TxLen > 0) && (LCD_TxBuf[0] != 0))
					{
						sLCD_TxLen = Modbus_Send(LCD_TxBuf, sLCD_TxLen);
						USARTx_Send(LCD_SerialPort,  LCD_TxBuf, sLCD_TxLen);
					}
				}
			}
#endif			
			sLCD_RxLen = 0;
		}
#if 1		
		//������̬��
		HMI_RxLenTemp = USARTx_Rec(HMI_SerialPort, &HMI_RxBuf[sHMI_RxLen], HMI_RxBufMax - sHMI_RxLen);
		sHMI_RxLen += HMI_RxLenTemp;
		if((sHMI_RxLen != 0) && (HMI_RxLenTemp == 0))
		{
			if((sHMI_RxLen >= 5)
				&& ((HMI_RxBuf[0] == 0x01) || (HMI_RxBuf[0] == 0x00)))	//��ַ�Ի�㲥
			{
				if(Modbus_CRC16(HMI_RxBuf, sHMI_RxLen) == 0)
				{
					sHMI_TxLen = 0;
					reg = (HMI_RxBuf[2] << 8 ) | HMI_RxBuf[3];
					dat = (HMI_RxBuf[4] << 8 ) | HMI_RxBuf[5];
					
					switch(HMI_RxBuf[1])
					{
						case 0x03:
							if(sHMI_RxLen == 8)
							{
								ComSrc = 1;
								sHMI_TxLen = funSubModbusRx03_CallBack(HMI_RxBuf[0], reg, dat, HMI_TxBuf);
							}
							break;
						case 0x04:
							if(sHMI_RxLen == 8)
							{
								ComSrc = 1;
								sHMI_TxLen = funSubModbusRx04_CallBack(HMI_RxBuf[0], reg, dat, HMI_TxBuf);
							}
							break;
						case 0x06:
							if(sHMI_RxLen == 8)
							{
								ComSrc = 1;
								sHMI_TxLen = funSubModbusRx06_CallBack(HMI_RxBuf[0], reg, dat, HMI_TxBuf);
							}
							break;
					}
					if((sHMI_TxLen > 0) && (HMI_TxBuf[0] != 0))
					{
						sHMI_TxLen = Modbus_Send(HMI_TxBuf, sHMI_TxLen);
						USARTx_Send(HMI_SerialPort,  HMI_TxBuf, sHMI_TxLen);
					}
				}
			}
			sHMI_RxLen = 0;
		}
#endif		
		
		vTaskDelay(5/portTICK_RATE_MS);
	}
}




//extern const int16_t *HMI_table03_1[] ;
extern const int16_t *HMI_table04_1[];

int16_t funHmiModbusRx03_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat)
{
	int16_t i, txLen;
	uint16_t datreg;
	
	txLen = 0;
	if(num > 127)
	{
		return -1;
	}
	redat[txLen++] = addr;
	redat[txLen++] = 0x03;
	redat[txLen++] = num * 2;
	
	for(i = 0; i < num; i++)
	{
		datreg = reg + i;
		
		datreg ++;
			redat[txLen++] = datreg >> 8;
			redat[txLen++] = datreg & 0xFF;
		
		
		
#if 0		
		if(datreg < 100)
		{
			redat[txLen++] = SysData.ConfigData[datreg] >> 8;
			redat[txLen++] = SysData.ConfigData[datreg] & 0xFF;
			
//			if(HMI_table03_1[datreg] != NULL)
//			{
//				redat[txLen++] = *HMI_table03_1[datreg] >> 8;
//				redat[txLen++] = *HMI_table03_1[datreg] & 0xFF;
//			}
//			else
//			{
//				redat[txLen++] = 0;
//				redat[txLen++] = 0;
//			}			
		}
#endif		
	}
	return txLen;
}



int16_t funBIMStoAct(int8_t code);
int16_t funBIMSoutAct(int8_t code);
int16_t funBIMStoRes(int8_t code);
int16_t funBIMSoutRes(int8_t code);
int16_t funBIMStoAddr(int8_t code);




int16_t tabelNone;

