/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include <string.h>

#include "sys.h"
#include "configure.h"
#include "bspBIMS.h"
#include "drvAI.h"
#include "protect.h"

#define ADC_FilltNum    64
#define ADC_Rate        10000


#define LED_ERR_PIN 0x01

#define LED_OK_PIN 0x02

#define LED_ALARM_PIN 0x20


extern const uint32_t NTC10K_RES[];

extern uint16_t FanErrTim;

const uint8_t MonPerDays[12] = 
{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};


static void funBSP_AI(void);

static uint16_t usADC_Fillt[ADC_ChannelNum][ADC_FilltNum];

static uint16_t usADC_FilltSN;
static uint32_t usADC_Ave[ADC_ChannelNum];
typedef struct
{
  float offset;
  float div;
}ADC_ADJ_STRUCT ;

typedef struct
{
  ADC_ADJ_STRUCT ADC_Ratio[ADC_ChannelNum + DAC_ChannelNum];
  uint16_t Flag;
}ADC_ADJSAVE_STRUCT ;

ADC_ADJSAVE_STRUCT ADC_SAVE;

#define LED_SegDP 0x80
uint8_t LED_SegCode[] =
{
  0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,    //0~9
	//A		B		C			d		E			F		H			c			d		 o
  0x77,0x7F,0x39,0x5E,0x79,0x71,0x76,0x58,0x5E,0x5c,    //A~F,H
	//u
	0x1c,
};
uint8_t LED_Code[5];

static float funADC_Cal(uint8_t sn);
static void funADC_Cal_Init(void);
static float funADC_Cal_Temp(uint8_t sn);

static uint8_t funBSP_Addr(void);
static void funBSP_LED(void);
static void funBSP_LEDPage(int8_t dir);
static void funBSP_Key(void);

static void funBSP_Beep(void);

void drvBSP_PWMtask(void);
//BSP���񣬰���AI,DI DO�� PWM SEG
void threadBSP(void *pvParameters)  
{
  static uint8_t LedReDrawTim;
  drvAI_Init();
  funADC_Cal_Init();
//  funBSP_LEDPage(0);
  while(1)
  {
		SysData.Shouhu |= 0x01;
    SysData.Addr = funBSP_Addr();
    funBSP_Beep();
    funBSP_AI();
    funBSP_Key();
    LedReDrawTim++;
    if(LedReDrawTim > 30)
    {
      LedReDrawTim = 0;
      funBSP_LEDPage(0);  //ˢ����ʾ����
    }
    funBSP_LED();       //��ʾ
    drvBSP_PWMtask();

		SysData.sBatCurr = (int16_t)((SysData.AdcValue[ADC_Cnl_IChg] - SysData.AdcValue[ADC_Cnl_IBat])* 100);
//		if(((drvBSP_CtrlIO_Sts(bspCtrlIO_CHGBat) == 0) || ((SysData.RunSts & SysSts_LineO) == 0)) 	//�޳�� �� ���е����
//			&& ((SysData.RunSts & SysSts_BatO) != 0))		//��ؿ��Էŵ�
//		{//��طŵ�
//			SysData.sBatCurr = -(int16_t)(SysData.AdcValue[ADC_Cnl_IBat]* 100);
//						
//		}
//		else  if(drvBSP_CtrlIO_Sts(bspCtrlIO_CHGBat) != 0)
//		{//���
//			SysData.sBatCurr = (int16_t)(SysData.AdcValue[ADC_Cnl_IChg] * 100);
//		}
//		else
//		{
//			SysData.sBatCurr = -(int16_t)(SysData.AdcValue[ADC_Cnl_IBat]* 100);
//		}
		
    vTaskDelay(3/portTICK_RATE_MS);  
//    vTaskDelay(3);  
  }
}



static void funBSP_Beep(void)
{
  static uint32_t  beepTim;
  beepTim++;
  if(SysData.DevErr != 0)
  {
    if(beepTim < 30)
    {
      bspBeepON;
    }    
    else
    {
      bspBeepOFF;
    }
    if(beepTim > 300)
    {
      beepTim = 0;
    }
  }
  else if(SysData.Alarm != 0)
  {
    if(beepTim < 30)
    {
      bspBeepON;
    }    
    else
    {
      bspBeepOFF;
    }
    if(beepTim > 1000)
    {
      beepTim = 0;
    }
  }
  else
  {
    bspBeepOFF;
  }
}
/*
  if(SysData.Alarm != 0)
  {
    LED_Code[4] = LED_ALARM_PIN;
  }
  else
  {
    LED_Code[4] = LED_OK_PIN;
  }
  */


static uint8_t funBSP_Addr(void)
{
	static uint8_t nowAddr = 0 , AddrTimes = 0, lastAddr;
  uint8_t di;
  di = drvBSP_ReadE & 0x3F;
  di = 0x3F - di;
  if(lastAddr == di)
  {
    AddrTimes++;
    if(AddrTimes >= 100)
    {
      AddrTimes = 100;
      nowAddr = lastAddr;
    }
  }
  else
  {
    lastAddr = di;
    AddrTimes = 0;
  }
	di = 0;
	if((nowAddr & 0x20) != 0)
	{	di |= 0x01;}
	if((nowAddr & 0x10) != 0)
	{	di |= 0x02;}
	
	if((nowAddr & 0x08) != 0)
	{	di |= 0x04;}
	if((nowAddr & 0x04) != 0)
	{	di |= 0x08;}
	
	if((nowAddr & 0x02) != 0)
	{	di |= 0x10;}
	if((nowAddr & 0x01) != 0)
	{	di |= 0x20;}
	if(di == 0)
	{
		di = 1;
	}
  return di;
}



static void funBSP_LED(void)
{
  static uint8_t LED_Setp = 0;
  
  LED_Setp++;
  if(LED_Setp >= 5)
  {
    LED_Setp = 0;
  }
  //
  
  drvBSP_LedCom(0);
  drvBSP_LedSeg(LED_Code[LED_Setp]);
  drvBSP_LedCom(LED_Setp+1);
}

static void funBSP_LEDPage(int8_t dir)
{
#define MaxLedPage 7
  static int8_t LedPage = 0;
  int16_t volt,curr,dat;
  float ftemp;
  if(dir > 0)
  {
    LedPage++;
  }
  else if(dir < 0)
  {
    LedPage--;
  }
  LedPage = LedPage < MaxLedPage ? LedPage : 0;
  LedPage = LedPage >= 0 ? LedPage : (MaxLedPage - 1);
  
  if(SysData.DevErr != 0)
  {
    LED_Code[4] = LED_ERR_PIN;
  }
  else if(SysData.Alarm != 0)
  {
    LED_Code[4] = LED_ALARM_PIN;
  }
  else
  {
    LED_Code[4] = LED_OK_PIN;
  }
  
  ftemp = SysData.AdcValue[ADC_Cnl_VlineOut] > SysData.AdcValue[ADC_Cnl_VBatOut] ?
    SysData.AdcValue[ADC_Cnl_VlineOut] : SysData.AdcValue[ADC_Cnl_VBatOut];
    
  volt = (int16_t)(ftemp * 10);
#if (defined LxD1000)  
	//volt = (int16_t)ftemp;
#endif	
//  ftemp = SysData.AdcValue[ADC_Cnl_IlineOut] + SysData.AdcValue[ADC_Cnl_IBatOut];
//  curr = (int16_t)(ftemp * 10);
  
  if((drvBSP_CtrlIO_Sts(bspCtrlIO_RlyLin) != 0)
        && (drvBSP_CtrlIO_Sts(bspCtrlIO_PFCLin) != 0)
        && (drvBSP_CtrlIO_Sts(bspCtrlIO_OutLin) != 0))
  {
    curr = (int16_t)(SysData.AdcValue[ADC_Cnl_IlineOut] * 10);
  }
  else if((drvBSP_CtrlIO_Sts(bspCtrlIO_RlyBat) != 0)
        && (drvBSP_CtrlIO_Sts(bspCtrlIO_OutBat) != 0))
  {
    curr = (int16_t)(SysData.AdcValue[ADC_Cnl_IBatOut] * 10);
  }
  else
  {
    curr = 0;
  }
  
//  if(SysData.usAcCtrlSts & CtrlSts_AC_OUT)    //AC�����
//  {
//    volt = (int16_t)(SysData.AdcValue[ADC_Cnl_VlineOut] * 10);
//    curr = (int16_t)(SysData.AdcValue[ADC_Cnl_IlineOut] * 10);
//  }
//  else
//  {
//    volt = (int16_t)(SysData.AdcValue[ADC_Cnl_VBatOut] * 10);
//    curr = (int16_t)(SysData.AdcValue[ADC_Cnl_IBatOut] * 10);
//  }
  //SysData.AdcValue[ADC_Cnl_VlineOut] 
	//2020-06-05 �޸���ʾָʾ
	
	//A		B		C			d		E			F		H			c			o		 u
  switch(LedPage)
  {
  case 0:       //�����ѹ xxx.x
    //LED_Code[3] = LED_SegCode[1] | LED_SegDP;
    if(volt > 9999)
    {
      volt = 9999;
    }
    else if(volt < 0)
    {
      volt = 0;
    }  
    LED_Code[3] = LED_SegCode[volt / 1000];
		volt %= 1000;
    LED_Code[2] = LED_SegCode[volt / 100];
    volt %= 100;
    LED_Code[1] = LED_SegCode[volt / 10];
//#if (defined LxT600)
    LED_Code[1] |=  LED_SegDP;    
//#endif		
    LED_Code[0] = LED_SegCode[volt % 10];
    
    break;
  case 1:       //������� oxx.x
    LED_Code[3] = LED_SegCode[19];
    
	  curr = (int16_t)(SysData.AdcValue[ADC_Cnl_IlineOut] * 10)
					+ (int16_t)(SysData.AdcValue[ADC_Cnl_IBatOut] * 10);
	
	
    if(curr > 999)
    {
      curr = 999;
    }
    else if(curr < 0)
    {
      curr = 0;
    }  
    LED_Code[2] = LED_SegCode[curr / 100];
    curr %= 100;
    LED_Code[1] = LED_SegCode[curr / 10] | LED_SegDP;
    LED_Code[0] = LED_SegCode[curr % 10];
    break;
  case 2:       //����ѹ uxx.x
    LED_Code[3] = LED_SegCode[20];
    
    dat = (int16_t)(SysData.AdcValue[ADC_Cnl_VChg] * 10);
    if(dat > 999)
    {
      dat = 999;
    }
    else if(dat < 0)
    {
      dat = 0;
    }
    LED_Code[2] = LED_SegCode[dat / 100];
    dat %= 100;
    LED_Code[1] = LED_SegCode[dat / 10] | LED_SegDP;
    LED_Code[0] = LED_SegCode[dat % 10];
    
    break;
  case 3:       //������ cxx.x ->��Ϊ��ص���
//		if(((drvBSP_CtrlIO_Sts(bspCtrlIO_CHGBat) == 0) || ((SysData.RunSts & SysSts_LineO) == 0)) 	//�޳�� �� ���е����
//			&& ((SysData.RunSts & SysSts_BatO) != 0))		//��ؿ��Էŵ�
//		{//��طŵ�
//			dat = (int16_t)(SysData.AdcValue[ADC_Cnl_IBat]);
//			
//			LED_Code[2] = 0x40;
//			dat %= 100;
//			LED_Code[1] = LED_SegCode[dat / 10];
//			LED_Code[0] = LED_SegCode[dat % 10];
//			
//		}
//		else  if(drvBSP_CtrlIO_Sts(bspCtrlIO_CHGBat) != 0)
//		{//���
//			dat = (int16_t)(SysData.AdcValue[ADC_Cnl_IChg] * 10);
//			
//    LED_Code[2] = LED_SegCode[dat / 100];
//    dat %= 100;
//    LED_Code[1] = LED_SegCode[dat / 10] | LED_SegDP;
//    LED_Code[0] = LED_SegCode[dat % 10];
//		}
//		else
//		{
//			LED_Code[2] = LED_SegCode[0];
//			LED_Code[1] = LED_SegCode[0];
//			LED_Code[0] = LED_SegCode[0];
//		}
		if(SysData.sBatCurr < 0)
		{
			
			dat = -(SysData.sBatCurr / 100);
			LED_Code[2] = 0x40;
			dat %= 100;
			LED_Code[1] = LED_SegCode[dat / 10];
			LED_Code[0] = LED_SegCode[dat % 10];
		}
		else
		{
			dat = SysData.sBatCurr / 10;
			dat %= 1000;
			LED_Code[2] = LED_SegCode[dat / 100];
			dat %= 100;
			LED_Code[1] = LED_SegCode[dat / 10] | LED_SegDP;
			LED_Code[0] = LED_SegCode[dat % 10];
		}
	
    LED_Code[3] = LED_SegCode[17] ;//| LED_SegDP;
    
//    dat = (int16_t)(SysData.AdcValue[ADC_Cnl_IChg] * 10);
//    if(dat > 999)
//    {
//      dat = 999;
//    }
//    else if(dat < 0)
//    {
//      dat = 0;
//    }
//    LED_Code[2] = LED_SegCode[dat / 100];
//    dat %= 100;
//    LED_Code[1] = LED_SegCode[dat / 10] | LED_SegDP;
//    LED_Code[0] = LED_SegCode[dat % 10];
    
    break;
  case 4:       //SOH HXXXX
    LED_Code[3] = LED_SegCode[16];
    
//    dat = (int16_t)(SysData.SOH );
    dat = (int16_t)((SysData.SOH * ConfigData.sRatioAH) / 100);

    if(dat > 999)
    {
      dat = 999;
    }
    else if(dat < 0)
    {
      dat = 0;
    }
    LED_Code[2] = LED_SegCode[dat / 100];
    dat %= 100;
    LED_Code[1] = LED_SegCode[dat / 10];
    LED_Code[0] = LED_SegCode[dat % 10];
    
    break;
  case 5:       //SOC Cxxx
    LED_Code[3] = LED_SegCode[12];
    
    dat = (int16_t)(SysData.SOC);
    if(dat > 999)
    {
      dat = 999;
    }
    else if(dat < 0)
    {
      dat = 0;
    }
    LED_Code[2] = LED_SegCode[dat / 100];
    dat %= 100;
    LED_Code[1] = LED_SegCode[dat / 10];
    LED_Code[0] = LED_SegCode[dat % 10];
    
    break;
  case 6:       //ģ���ַ
    LED_Code[3] = LED_SegCode[10];
    LED_Code[2] = LED_SegCode[18];
    dat = (int16_t)SysData.Addr;
    if(dat > 99)
    {
      dat = 99;
    }
    else if(dat < 0)
    {
      dat = 0;
    }
    //LED_Code[2] = LED_SegCode[dat / 100];
    //dat %= 100;
    LED_Code[1] = LED_SegCode[dat / 10];
    LED_Code[0] = LED_SegCode[dat % 10];
    
    break;
  default:       //
    LedPage = 0;
    break;
  }
}

static void funBSP_Key(void)
{
  static uint8_t Key1Dey, Key2Dey;
  
  if(drvBSP_ReadKey1 == SET)    //Ĭ��
  {
    if(Key1Dey > 10)
    {//�Ϸ�ҳ
      funBSP_LEDPage(1);
    }
    Key1Dey = 0;
  }
  else
  {
    if(Key1Dey < 250)
    {
      Key1Dey++;
    }
  }
  
  if(drvBSP_ReadKey2 == SET)    //Ĭ��
  {
    if(Key2Dey > 10)
    {//�·�ҳ
      funBSP_LEDPage(-1);
    }
    Key2Dey = 0;
  }
  else
  {
    if(Key2Dey < 250)
    {
      Key2Dey++;
    }
  }  
}


static void funBSP_AI(void)
{
  uint16_t i,j;
 // int16_t acbase;
  uint32_t usADC_Sum[ADC_ChannelNum];
  if(drvAI_Finish != 0)
  {
    drvAI_Finish = 0;
    usADC_FilltSN++;
    if(usADC_FilltSN >= ADC_FilltNum)
    {
      usADC_FilltSN = 0;
    }
    
    for(i = 0; i < ADC_ChannelNum; i++) //�ɼ��ۼ�
    {
      usADC_Fillt[i][usADC_FilltSN] = drvADC_Value[i];
      usADC_Sum[i] = 0;
      for(j = 0; j < ADC_FilltNum; j ++)
      {
        usADC_Sum[i] += usADC_Fillt[i][j];
      }
      
      usADC_Ave[i] = usADC_Sum[i]/(ADC_FilltNum / 16);  //�Ŵ�16��
    }
    for(i = 0; i < 12; i++)
    {
      //���� --��Լ2.5V=3400  AdcValue
      SysData.AdcValue[i] = funADC_Cal(i);
			if(SysData.AdcValue[i] < 0)
			{SysData.AdcValue[i] = 0;}
      SysData.AdcValue_D[i] = (int32_t)(SysData.AdcValue[i] * 100);
    }
    //�е��ѹ����
    SysData.AdcValue[ADC_Cnl_Vac] += SysData.AdcValue[ADC_Cnl_IlineOut] * 1.2f;
    
    if(SysData.AdcValue[ADC_Cnl_Vac] < 50.0f)
    {
      SysData.AdcValue[ADC_Cnl_Vac] = 0.0f;
      SysData.AdcValue_D[ADC_Cnl_Vac] = 0;
    }
		
    if(drvBSP_CtrlIO_Sts(bspCtrlIO_CHGBat) != 0)
		{
			SysData.AdcValue[ADC_Cnl_IBat] = 0;
		}
    //���ڵ�ؼ��� ADC_Cnl_VBat2
		if(CellNum == 1)
		{
			SysData.CellVolt[0] = (int16_t)(SysData.AdcValue[ADC_Cnl_VBat1] * 1000);
			SysData.CellVolt[1] = 0;
			SysData.CellVolt[2] = 0;
			SysData.CellVolt[3] = 0;
			SysData.fBatVolt = SysData.AdcValue[ADC_Cnl_VBat1] ;
		}
		if(CellNum == 2)
		{//
			SysData.CellVolt[0] = (int16_t)(SysData.AdcValue[ADC_Cnl_VBat1] * 1000);
			SysData.CellVolt[1] = (int16_t)(SysData.AdcValue[ADC_Cnl_VBat2] * 1000);
			//SysData.CellVolt[1] = (int16_t)((SysData.AdcValue[ADC_Cnl_VBat] - SysData.AdcValue[ADC_Cnl_VBat2]) * 1000);
			SysData.CellVolt[2] = 0;
			SysData.CellVolt[3] = 0;
			SysData.fBatVolt = SysData.AdcValue[ADC_Cnl_VBat1] + SysData.AdcValue[ADC_Cnl_VBat2];
		}
		SysData.sBatVolt = (int16_t)(SysData.fBatVolt * 100);
		
		SysData.CellMaxVolt = SysData.CellVolt[0];
		SysData.CellMinVolt = SysData.CellVolt[0];
		for(i = 1; i < CellNum; i++)
		{
			if(SysData.CellVolt[i] < 0)
			{
				SysData.CellVolt[i] = 0;
			}
			if(SysData.CellMaxVolt < SysData.CellVolt[i])
			{
				SysData.CellMaxVolt = SysData.CellVolt[i];
			}
			if(SysData.CellMinVolt > SysData.CellVolt[i])
			{
				SysData.CellMinVolt = SysData.CellVolt[i];
			}
		}
		
		
		
    if(usADC_Ave[ADC_Cnl_Fan] < (1000 *  16))
    {
      if(FanErrTim > 0)
      {
        FanErrTim--;
      }
    }
    else if(usADC_Ave[ADC_Cnl_Fan] > (3000 *  16))
    {
      if(FanErrTim < 100)
      {
        FanErrTim++;
      }
    }
    
    if((SysData.RunSts & SysSts_LineO)
			&& ((SysData.DevErr & AlarmLinOutErr) == 0))
		{
			SysData.VoltOut = SysData.AdcValue_D[ADC_Cnl_VlineOut] ;
			SysData.CurrOut = SysData.AdcValue_D[ADC_Cnl_IlineOut] ;
		}
		else if((SysData.RunSts & SysSts_BatO)
			&& ((SysData.DevErr & AlarmBatOutErr) == 0))
		{
			SysData.VoltOut = SysData.AdcValue_D[ADC_Cnl_VBatOut] ;
			SysData.CurrOut = SysData.AdcValue_D[ADC_Cnl_IBatOut] ;
		}
		else
		{
			SysData.VoltOut = 0 ;
			SysData.CurrOut = 0;
		}
		SysData.CurrOut = SysData.AdcValue_D[ADC_Cnl_IBatOut] + SysData.AdcValue_D[ADC_Cnl_IlineOut] ;
		
//    SysData.AdcValue_D[ADC_Cnl_Vac] = usADC_Ave[ADC_Cnl_Vac];
    
//    
//    if((drvBSP_CtrlIO_Sts(bspCtrlIO_RlyLin) == 0)
//        || (drvBSP_CtrlIO_Sts(bspCtrlIO_PFCLin) == 0)
//        || (drvBSP_CtrlIO_Sts(bspCtrlIO_OutLin) == 0))
//    {
//      SysData.AdcValue[ADC_Cnl_VlineOut] = 0.0f;
//      SysData.AdcValue_D[ADC_Cnl_VlineOut] = 0;
//      
//      SysData.AdcValue[ADC_Cnl_IlineOut] = 0.0f;
//      SysData.AdcValue_D[ADC_Cnl_IlineOut] = 0;
//    }
//    
//    
//    if((drvBSP_CtrlIO_Sts(bspCtrlIO_RlyBat) == 0)
//        || (drvBSP_CtrlIO_Sts(bspCtrlIO_OutBat) == 0))
//    {
//      SysData.AdcValue[ADC_Cnl_VBatOut] = 0.0f;
//      SysData.AdcValue_D[ADC_Cnl_VBatOut] = 0;
//      
//      SysData.AdcValue[ADC_Cnl_IBatOut] = 0.0f;
//      SysData.AdcValue_D[ADC_Cnl_IBatOut] = 0;
//    }
    
    //���㽻��AC  
    //acbase = usADC_Ave[8] / 16;
    //SysData.AdcValue[8] = 220;
    //SysData.AdcValue_D[8] = SysData.AdcValue[8]*100;
    
    //�¶ȼ���  funADC_Cal_Temp
    SysData.AdcValue[ADC_Cnl_Tbat] = funADC_Cal_Temp(ADC_Cnl_Tbat);
    SysData.AdcValue[ADC_Cnl_T1] = funADC_Cal_Temp(ADC_Cnl_T1);
    SysData.AdcValue[ADC_Cnl_T2] = funADC_Cal_Temp(ADC_Cnl_T2);
    
    SysData.AdcValue_D[ADC_Cnl_Tbat] = (int16_t)(SysData.AdcValue[ADC_Cnl_Tbat] *10);
    SysData.AdcValue_D[ADC_Cnl_T1] = (int16_t)(SysData.AdcValue[ADC_Cnl_T1] *10);
    SysData.AdcValue_D[ADC_Cnl_T2] = (int16_t)(SysData.AdcValue[ADC_Cnl_T2] *10);
    
//#define ADC_Cnl_Vac     8
//#define ADC_Cnl_Tbat    12
//#define ADC_Cnl_Fan     13
//#define ADC_Cnl_T1      14
//#define ADC_Cnl_T2      15
    
  }
}

int32_t TEST;
int32_t CHN;
float DAT1 = 0.1f,DAT2 = 0.1f;
void funBSP_AO(uint8_t chnl, float dat)
{
  float PWM_TEST = 0.1f;
  //static float pwm = 0;
  CHN = ADC_ChannelNum + chnl;
  
  if(CHN >= (ADC_ChannelNum + DAC_ChannelNum))
  {
    return ;
  }
  PWM_TEST = ADC_SAVE.ADC_Ratio[CHN].div * dat;
  PWM_TEST -= ADC_SAVE.ADC_Ratio[CHN].offset ;
  
//  DAT1 = ADC_SAVE.ADC_Ratio[CHN].div;
//  DAT2 *= dat;
//  DAT1 *= DAT2;
//  DAT2 = ADC_SAVE.ADC_Ratio[CHN].offset ;
//  DAT1 += DAT2;
//  TEST = (int32_t)DAT1;
  if(PWM_TEST < 0)
  {
    PWM_TEST = 0;
  }
  else if(PWM_TEST >= PWM_CYC)
  {
    PWM_TEST = PWM_CYC - 1;
  }
  drvBSP_PWM(chnl,(uint16_t) PWM_TEST);
}


static void funADC_Cal_Init(void)
{
  uint8_t i;
  
  bspLoad(AdjCfgAddr, (uint8_t *)&ADC_SAVE,sizeof(ADC_ADJSAVE_STRUCT));
	
  if(ADC_SAVE.Flag != 0xAA55)
  {
    for(i = 0; i < ADC_ChannelNum; i++)
    {
      ADC_SAVE.ADC_Ratio[i].div = 21840;
      ADC_SAVE.ADC_Ratio[i].offset = 0;
    }
    ADC_SAVE.ADC_Ratio[ADC_Cnl_VChg].div = 4550;   //2.5V=12V
    ADC_SAVE.ADC_Ratio[ADC_Cnl_IChg].div = 5460;   //2.5V=10A
    
    ADC_SAVE.ADC_Ratio[ADC_Cnl_VlineOut].div = 1137.5; //2.5V=48V
    ADC_SAVE.ADC_Ratio[ADC_Cnl_IlineOut].div = 5460;   //2.5V=10A  
    
    ADC_SAVE.ADC_Ratio[ADC_Cnl_VBatOut].div = 1137.5; //2.5V=48V
    ADC_SAVE.ADC_Ratio[ADC_Cnl_IBatOut].div = 5460;   //2.5V=10A
    
    ADC_SAVE.ADC_Ratio[ADC_Cnl_VBat1].div = 4550;   //2.5V=12V
    ADC_SAVE.ADC_Ratio[ADC_Cnl_VBat2].div = 4550;   //2.5V=12V
    ADC_SAVE.ADC_Ratio[ADC_Cnl_IBat].div = 910;    //2.5V=60A
    
    ADC_SAVE.ADC_Ratio[ADC_Cnl_Vac].div = 248.18;     //2.5V=220V
    
  }

//  
//    ADC_SAVE.ADC_Ratio[18].div = 37.037;
//    ADC_SAVE.ADC_Ratio[18].offset =1177;
}

#define VoltTempRef 72072//4528.4	//0xFFF0
//#define VoltTempRef 86486// //0xFFF0��Ӧ2.5V/3.3V
static float funADC_Cal_Temp(uint8_t sn)
{
  int16_t funC_i;
  float retdat;
  int64_t itp;
  int32_t itemp;
  itp = usADC_Ave[sn];
  itp *= 10000;    //10k=100000
  itp /= VoltTempRef - usADC_Ave[sn];     //itp=��ֵ
  itemp = (int32_t)itp;
          //����������¶�
  if(itemp >= NTC10K_RES[0])
  {
          retdat = -55;
  }
  else if(itemp <= NTC10K_RES[180])
  {
          retdat = 125;
  }
  else
  {
          for(funC_i = 0; funC_i <= 180; funC_i++)
          {
                  if(itemp >= NTC10K_RES[funC_i])
                  {
                          if(funC_i >= 1)
                          {
                                  itemp = itemp - NTC10K_RES[funC_i];
                                  //itemp *= 10;
														retdat = itemp;
                                  retdat /= NTC10K_RES[funC_i - 1] - NTC10K_RES[funC_i];
                                  retdat = retdat > 0 ? retdat : 0;
                                  retdat = retdat < 1 ? retdat : 1;
                                  retdat = funC_i - retdat;
                                  retdat -= 55; //��ȥ����40��  --��ƫ��
                                  //ftemp *= 10;
                                  //retdat = itemp;//(int16_t)(ftemp * 10);
                          }
                          else
                          {
                                  retdat = -55;
                          }
                          break;//�ҵ����˳�ѭ��
                  }
          }
  }
  
  return retdat;
}

//#define ADC_Cnl_Vac     11
//#define ADC_Cnl_Tbat    12
//#define ADC_Cnl_Fan     13
//#define ADC_Cnl_T1      14
//#define ADC_Cnl_T2      15


static float funADC_Cal(uint8_t sn)
{
  float ftemp;
  ftemp = usADC_Ave[sn] ;
  ftemp += ADC_SAVE.ADC_Ratio[sn].offset;
  ftemp /= ADC_SAVE.ADC_Ratio[sn].div;
  
  return ftemp;
}

static ADC_ADJSAVE_STRUCT ADC_SaveTemp;
static uint32_t ADJ_Time;
static uint8_t ADJ_SaveFlag;
static int32_t AdjValue[ADC_ChannelNum + DAC_ChannelNum][4];
int32_t iADJ_Def;
#define ADJ_Sec 600000
void funADC_Adj(uint16_t no,uint16_t data)
{
  int32_t ch,point;
  float ftemp;
//  int32_t itemp;
  if(no == 0)      //start ADJ
  {
//    SysData.ADJ_EN = 1;
    SysData.RunSts |= SysSts_Adj;
    SysData.RunSts &= ~SysSts_AdjRdy;
    ADJ_Time = xTaskGetTickCount();
    drvBSP_PWM(PWM_OutIqL,PWM_OutIqMid);
    drvBSP_PWM(PWM_OutIqB,PWM_OutIqMid);
  }
  else if(no == 1)       //End ADJ
  {
    SysData.RunSts &= ~SysSts_Adj;
    SysData.RunSts &= ~SysSts_AdjRdy;
  }
  else if(((xTaskGetTickCount() - ADJ_Time) < ADJ_Sec) && ((SysData.RunSts & SysSts_Adj) != 0))
  {
    if(no == 2)       //Read Para
    {
      memcpy(&ADC_SaveTemp,&ADC_SAVE,sizeof(ADC_ADJSAVE_STRUCT));
      SysData.RunSts |= SysSts_AdjRdy;
      drvBSP_PWM(PWM_OutIqL,PWM_OutIqMid);
      drvBSP_PWM(PWM_OutIqB,PWM_OutIqMid);
			drvBSP_CtrlIO_ON(bspCtrlIO_CHGBat);	//�����
			drvBSP_CtrlIO_ON(bspCtrlIO_RlyBat);	//�����
    }
    else if((no == 3) && ((SysData.RunSts & SysSts_AdjRdy) != 0))       //Save ADJ
    {
      if(ADJ_SaveFlag != 0)
      {
        ADC_SaveTemp.Flag = 0xAA55;
        bspSave(AdjCfgAddr,(uint8_t *)&ADC_SaveTemp,sizeof(ADC_ADJSAVE_STRUCT));
        funADC_Cal_Init();
        ADJ_SaveFlag = 0;
      }
    }
    else if((no >= 11) &&  (no < 100) )  //У׼��2��
    {
      ch = no - 11;
      point = ch % 2;
      ch /= 2;
      if(ch < ADC_ChannelNum)
      {
        AdjValue[ch][point] = data;
        AdjValue[ch][point + 2] = usADC_Ave[ch];         //�ɼ�ֵ
        if(point == 1)
        {//����
          ftemp = AdjValue[ch][3] - AdjValue[ch][2];
          ftemp *= 100; //2λС��
          iADJ_Def = AdjValue[ch][1] - AdjValue[ch][0];
          ADC_SaveTemp.ADC_Ratio[ch].div = ftemp / iADJ_Def;
          //ƫ�Ƽ���
          ftemp = AdjValue[ch][1] * ADC_SaveTemp.ADC_Ratio[ch].div;
          ftemp /= 100; //2λС��
          ADC_SaveTemp.ADC_Ratio[ch].offset  = ftemp - AdjValue[ch][3];
          ADJ_SaveFlag = 1;
        }
      }
      else if(ch < (ADC_ChannelNum + DAC_ChannelNum))
      {
        AdjValue[ch][point] = data;
        AdjValue[ch][point + 2] = drvPWM_Value[ch - ADC_ChannelNum];         //�ɼ�ֵ
        if(point == 1)
        {//����
          ftemp = AdjValue[ch][3] - AdjValue[ch][2];
          ftemp *= 100; //2λС��
          iADJ_Def = AdjValue[ch][1] - AdjValue[ch][0];
          ADC_SaveTemp.ADC_Ratio[ch].div = ftemp / iADJ_Def;
          //ƫ�Ƽ���
          ftemp = AdjValue[ch][1] * ADC_SaveTemp.ADC_Ratio[ch].div;
          ftemp /= 100; //2λС��
          ADC_SaveTemp.ADC_Ratio[ch].offset  = ftemp - AdjValue[ch][3];
          
          
          
          ADJ_SaveFlag = 1;
        }
      }
    }
    else if(no >= 101)  //�������
    {
      drvBSP_PWM(no - 101, data * 100);
    }
  }
  else
  {
    SysData.RunSts &= ~SysSts_Adj;
  }
}
//ʱ��ת��ΪS
uint32_t fun2KDTToSec(DateTimeStruct *Dt)
{
  uint32_t Sec, Days;
  uint16_t temp , i;
//  int16_t itemp;
	
//	if (0 >= (int) (Dt->Mon -= 2)) //1��2���㵽ǰһ��	
//	{	
//		Dt->Mon += 12;
//		Dt->Year -= 1;
//	}
//	Days = 367 * Dt->Mon /12 + Dt->Day;
//	
	
  Days = Dt->Year * 365; //���������
  temp = (Dt->Year + 3) / 4;    //������
  Days += temp;
  
  for(i = 1; i <= 12; i++)      //���µ�����
  {
    if(i < Dt->Mon)
    {
      Days += MonPerDays[i - 1];
    }
    else
    {
      break;
    }
  }
  if((Dt->Mon >=3) && ((Dt->Year & 4) == 0))    //������3�º�
  {
    Days++;     //��������1��
  }
  Days += Dt->Day;      //��������
  
  Sec = Dt->Sec;
  Sec+= Dt->Hour * 3600;
  Sec+= Dt->Min * 60;
  
  Sec += Days * 86400;  
  
  return Sec;
}
//��ת��Ϊʱ��
uint32_t fun2KSecToDT(DateTimeStruct *Dt,uint32_t Secs)
{
  int32_t Days,year;
//  uint16_t temp , i;
	
	Days = Secs / 86400;	//ת��Ϊ����
  Secs %= 86400;	
	
	Days -= 31 + 29 ;	//2000��1�£�2��	//
	if(Days < 0)//����2000���1�»����
	{
		Dt->Year = 0;	//2000��
		
		Days += 60;	//31+29
		if(Days < 31)
		{
			Dt->Mon = 1;
			Dt->Day = Days + 1;
		}
		else
		{
			Days -= 31;
			Dt->Mon = 2;
			Dt->Day = Days + 1;
		}
	}
	else	//Days = 0~xxxx
	{
		year = Days / 365;	//����
		Days %= 365;	//ʣ������   0~364
		Days -= year / 4 + year / 100;	//������������
		if(Days <= 0)	//��������
		{
			Days += 365;
			if(( year % 4) == 0)
			{
				Days ++;
			}
			year --;
		}
		Dt->Mon = (12 * Days) / 367;

		if(Dt->Mon == 0)
		{
			Dt->Day = Days + 1;
		}
		else
		{
			Days -= 367 * Dt->Mon / 12;
			Dt->Day = Days;
		}
		
		Dt->Year = year;
		Dt->Mon += 3;	//0->3��
		if(Dt->Mon > 12)	//����1��
		{
			Dt->Mon -= 12;
			Dt->Year ++;
		}
	}
	
	
//	Days = Secs / 86400;	//������
//	Secs = Secs % 86400;	//ʣ������
//	Dt->Year = Days / 366;		//��������ȫ�������㣬��������
//	Days = Days % 366;
//	temp = (Dt->Year + 3) / 4;	//ʵ��������
//	Days += Dt->Year - temp;	//����
//	
//	temp = 365;
//	if((Dt->Year % 4) == 0)	//����������
//	{
//		temp++;
//	}
//	if(Days >= temp)	//��1��
//	{
//		Days -= temp;
//		Dt->Year++;
//	}
//	
//	for(i = 1; i <= 12; i++)      //���µ�����
//  {
//		if(Days >= MonPerDays[i - 1])
//		{
//			if((i == 2) && ((Dt->Year % 4) == 0)	)	//����2��
//			{
//				if(Days >= 29)
//				{
//					Days -= 29;
//				}
//				else
//				{
//					break;
//				}
//			}
//			else
//			{
//				Days -= MonPerDays[i - 1];
//			}
//		}
//		else	//����1����
//		{
//			break;	//�˳�
//		}
//  }
//	Dt->Mon = i;
//	Dt->Day = Days + 1;	//���ܳ���X��0��
//	
	Dt->Hour = Secs / 3600;
	Secs = Secs % 3600;
	Dt->Min = Secs / 60;
	Dt->Sec = Secs % 60;
  return Secs;
}


uint32_t bspSetDateTime(DateTimeStruct *dt)
{
  RTC_TimeTypeDef  RTC_Time;
  RTC_DateTypeDef  RTC_Date;


  RTC_Date.RTC_Year = dt->Year;
  RTC_Date.RTC_Month = dt->Mon;
  RTC_Date.RTC_Date = dt->Day;

  RTC_Time.RTC_Hours  = dt->Hour;
  RTC_Time.RTC_Minutes = dt->Min;
  RTC_Time.RTC_Seconds = dt->Sec;

  RTC_SetTime(RTC_Format_BIN, &RTC_Time);
  RTC_SetDate(RTC_Format_BIN, &RTC_Date);
	
  return 1;
}




uint8_t BCDtoHex(uint8_t bcd)
{
	uint8_t hex;
	hex = (bcd >> 4) & 0x0F;
	hex *= 10;
	hex += bcd & 0x0F;
	return hex;
}
uint32_t bspGetDateTime(DateTimeStruct *dt)
{
	uint32_t date, time;
	uint8_t date_temp;
	
	time = RTC->TR;
	date = RTC->DR;
	if(time != RTC->TR)	//ʱ�䷢���˱仯
	{//�ٶ�һ��
		time = RTC->TR;
		date = RTC->DR;
	}	
	date_temp = (date >> 20) & 0x0F;
	date_temp *= 10;
	
	
  dt->Year = BCDtoHex((date >> 16) & 0xFF);
  dt->Mon = BCDtoHex((date >> 8) & 0x1F);
  dt->Day = BCDtoHex(date & 0x3F);

  dt->Hour = BCDtoHex((time >> 16) & 0x3F);
  dt->Min = BCDtoHex((time >> 8) & 0x7F);
  dt->Sec = BCDtoHex(time & 0x7F);

	if(time & 0x00400000)
	{
		dt->Hour  += 12;
	}
  return 1;
}



/*
int funDateTimeCmp(DateTimeStruct *Dt1, DateTimeStruct *Dt2)
{
  uint32_t Sec1, Sec2;
  Sec1 = funFrom2KSec(Dt1);
  Sec2 = funFrom2KSec(Dt2);
  
}
*/

//const uint32_t NTC10K_RES[] = 	//MK52-10K
//{
//	//      0       9       8       7       6       5       4       3       2       1
//	1905562, 1834132, 1756740, 1676467, 1595647, 1515975, 1438624, 1364361, 1293641, 1226678,	//-40~-31
//	1163519, 1104098, 1048272,  995847,  946608,  900326,  856778,  815747,  777031,  740442,
//	 705811,  672987,  641834,  612233,  584080,  557284,  531766,  507456,  484294,  462224,	//-20~-11
//	 441201,  421180,  402121,  383988,  366746,  350362,  334802,  320035,  306028,  292750,	//-10~-1
//	
//	//0       1       2       3       4       5       6       7       8       9
//	280170, 268255, 256972, 246290, 236276, 226597, 217522, 208916, 200749, 192988,	//0~9
//	185600, 184818, 181489, 176316, 169917, 162797, 155350, 147867, 140551, 133536,	//10~19
//	126900, 120684, 114900, 109539, 104582, 100000,  95762,  91835,  88186,  84784,	//20~29
//	 81600,  78608,  75785,  73109,  70564,  68133,  65806,  63570,  61418,  59343,
//	 57340,  55405,  53534,  51725,  49976,  48286,  46652,  45073,  43548,  42075, 
//   
//	//0     1       2       3       4       5 6       7       8       9
//	40650, 39271, 37936, 36639, 35377, 34146, 32939, 31752, 30579, 29424,	//50~59
//	28250, 27762, 27179, 26523, 25817, 25076, 24319, 23557, 22803, 22065,
//	21350, 20661, 20004, 19378, 18785, 18225, 17696, 17197, 16727, 16282,
//	15860, 15458, 15075, 14707, 14352, 14006, 13669, 13337, 13009, 12684,
//	12360, 12037, 12724, 12390, 11067, 10744, 10422, 10104,  9789,  9481,	
//	
//	 9180	//100
//};

const uint32_t NTC10K_RES[] = 	//MK52-10K
{
	 //0       9       8       7       6       5       4       3       2       1
                                        569200, 525197, 485735, 450209, 418112,   //-55~-51
389014, 362552, 338416, 316341, 296100, 277494, 260354, 244532, 229897, 216336,  //-50~-41
203750, 192049, 181156,171001,  161522, 152664, 144377, 136617, 129343, 122518,  //-40~-31
116110, 110088, 104425,  99096,  94078,  89350,  84892,  80688,  76720,  72973,  //-30~-21
 69434,  66089,  62926,  59935,  57104,  54425,  51888,  49484,  47206,  45047,  //-20~-11
 43000,  41057,  39214,  37465,  35804,  34226,  32727,  31303,  29949,  28661,  //-10~-1

	//0       1       2       3       4       5       6       7       8       9
 27513,  26271,  25162,  24107,  23101,  22144,  21231,  20362,  19533,  18742,  //0~9
 18016,  17269,  16583,  15928,  15302,  14704,  14134,  13588,  13067,  12568,  //10~19
 12092,  11636,  11199,  10782,  10382,  10000,   9633,   9282,   8946,   8623,  //20~29
  8314,   8018,   7734,   7461,   7199,   6948,   6707,   6476,   6254,   6040,  //30~39
  5835,   5638,   5449,   5267,   5091,   4923,   4761,   4605,   4455,   4311,  //40~49

	//0       1       2       3       4       5       6       7       8       9
  4168,   4038,   3909,   3785,   3665,   3550,   3439,   3332,   3229,   3129,  //50~59
  3033,   2941,   2851,   2765,   2682,   2602,   2524,   2449,   2377,   2307,  //60~69
  2240,   2175,   2112,   2051,   1992,   1935,   1880,   1827,   1776,   1726,  //70~79
  1678,   1632,   1587,   1543,   1501,   1461,   1421,   1383,   1346,   1310,  //80~89
	1275,   1242,   1209,   1178,   1147,   1117,   1089,   1061,   1034,   1008,  //90~99
	
	//0       1       2       3       4       5       6       7       8       9
	 983,    958,    934,    911,    889,    867,    846,    825,    805,    786,  //100~109
	 767,    749,    732,    714,    698,    682,    666,    651,    636,    622,  //110~119
	 608,    594,    581,    568,    556,    544,                                  //120~125
};

