/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include "sys.h"
#include "configure.h"
#include "BSP.h"
#include "tskmain.h"
//#include "protect.h"
#include <string.h>

#define   CanMASK  	0x1FFFF800   //29bit
#define   CanProNo	(0x191 << 20)//29bit

#define   MODBUS_ERR_CODE	  0x01
#define   MODBUS_ERR_REG	  0x02
#define   MODBUS_ERR_DATA	  0x03

#define   ThisAddr   SysData.ConfigData[Cfg_Addr]//7

#if (defined  BIMS)//0
#define ThisCanAddr 0xF0
#else
#define ThisCanAddr ThisAddr
#endif

//#define HOST_SerialPort	0//ԭF407�汾Ϊ����1
#define HOST_SerialPort	2  //��F103�汾��Ϊ����3 

extern unsigned short Modbus_CRC16(unsigned char *updata, unsigned short len);
extern unsigned short Modbus_Send(unsigned char *updata, unsigned short len);

#define   shostUSART_RxBufMax	  264

int16_t shostUSART_TxLen, shostUSART_RxLen;
uint8_t shostUSART_TxBuf[264], shostUSART_RxBuf[shostUSART_RxBufMax];
uint32_t uhostUSART_RxTick;




__weak int16_t funSubModbusRx03_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat)
{
		redat[0] = addr;
		redat[1] = 0x83;
		redat[2] = MODBUS_ERR_CODE;//0x01
		return 3;
}
__weak int16_t funSubModbusRx04_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *redat)
{
		redat[0] = addr;
		redat[1] = 0x84;
		redat[2] = MODBUS_ERR_CODE;
		return 3;
}
__weak int16_t funSubModbusRx05_CallBack(uint8_t addr, uint16_t reg, uint16_t dat, uint8_t *redat)
{
		redat[0] = addr;
		redat[1] = 0x85;
		redat[2] = MODBUS_ERR_CODE;
		return 3;
}
__weak int16_t funSubModbusRx06_CallBack(uint8_t addr, uint16_t reg, uint16_t dat, uint8_t *redat)
{
		redat[0] = addr;
		redat[1] = 0x86;
		redat[2] = MODBUS_ERR_CODE;
		return 3;
}

__weak int16_t funSubModbusRx10_CallBack(uint8_t addr, uint16_t reg, uint16_t num, uint8_t *dat, uint8_t *redat)
{
		redat[0] = addr;
		redat[1] = 0x90;
		redat[2] = MODBUS_ERR_CODE;
		return 3;
}


int8_t funCanSend04(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat1,uint16_t dat2, uint16_t dat3);
	
extern uint8_t ComSrc;
	

uint8_t rxBuf;
__align(4) uint8_t HostTxTest[10] = {0,1,2,3,4,5,6,7,8,9};
uint32_t	HostTxTestTick;
void CanTask(void);
void tskCom(void * argument)
{
		int16_t USART_RxLenTemp;
		int16_t reg, dat;
	
	  /*
	  #if (defined  BIMS)//0	
			switch(SysData.ConfigData[Cfg_Par] )
			{
				case 1:
					USARTx_Init(HOST_SerialPort, SysData.ConfigData[Cfg_Band] ,USART_Parity_Odd);	//
					break;
				
				case 2:
					USARTx_Init(HOST_SerialPort, SysData.ConfigData[Cfg_Band] ,USART_Parity_Even);//
					break;
				
				default:
					USARTx_Init(HOST_SerialPort, SysData.ConfigData[Cfg_Band] ,USART_Parity_No);	//
					break;
			}
	  #else
		  USARTx_Init(HOST_SerialPort, 9600, USART_Parity_No);	                            //����0
	  #endif	
    */
		//USARTx_Init(HOST_SerialPort, 9600, USART_Parity_No);
		
    USART3_Configuration();		
		
		drvCAN_Init();

		for(;;)//USART1_Rec
		{
				USART_RxLenTemp = USARTx_Rec(HOST_SerialPort, &shostUSART_RxBuf[shostUSART_RxLen], shostUSART_RxBufMax - shostUSART_RxLen);
				shostUSART_RxLen += USART_RxLenTemp;

				if((shostUSART_RxLen != 0) && (USART_RxLenTemp == 0))
				{
						if((shostUSART_RxLen >= 5)
						&&((shostUSART_RxBuf[0] == ThisAddr) || (shostUSART_RxBuf[0] == 0x00)))//��ַ�Ի�㲥  ͨ�ŵ�ַ�̶�Ϊ126
						{
								if(Modbus_CRC16(shostUSART_RxBuf, shostUSART_RxLen) == 0)
								{
										shostUSART_TxLen = 0;
									
										reg = (shostUSART_RxBuf[2] << 8 ) | shostUSART_RxBuf[3];//2��3�ֽڵ�ַ  ��ʼ�Ĵ�����ַ
										dat = (shostUSART_RxBuf[4] << 8 ) | shostUSART_RxBuf[5];//4��5�ֽ�      �Ĵ������ݻ�Ĵ�������   �践���ֽ��� = �Ĵ������� * 2(һ���Ĵ�����Ӧ2�ֽ�)
									
										switch(shostUSART_RxBuf[1])//1�ֽ�Ϊ����   Byte1Ϊ������
										{
												case 0x03://���Ĵ���������,��ȡ������������
													if(shostUSART_RxLen == 8)
													{
															ComSrc = 2;
															shostUSART_TxLen = funSubModbusRx03_CallBack(shostUSART_RxBuf[0], reg, dat, shostUSART_TxBuf);
													}
													break;
													
												case 0x04://���Ĵ���������,��ȡң������
													if(shostUSART_RxLen == 8)
													{
															ComSrc = 2;
															shostUSART_TxLen = funSubModbusRx04_CallBack(shostUSART_RxBuf[0], reg, dat, shostUSART_TxBuf);
													}
													break;
													
												case 0x05:
													if(shostUSART_RxLen == 8)
													{
															ComSrc = 2;
															shostUSART_TxLen = funSubModbusRx05_CallBack(shostUSART_RxBuf[0], reg, dat, shostUSART_TxBuf);
													}
													break;
													
												case 0x06://д�Ĵ���������,���ù�������
													if(shostUSART_RxLen == 8)
													{
															ComSrc = 2;
															shostUSART_TxLen = funSubModbusRx06_CallBack(shostUSART_RxBuf[0], reg, dat, shostUSART_TxBuf);
													}
													break;
													
												case 0x10://д�Ĵ���������,�û���������
													if((shostUSART_RxLen == (shostUSART_RxBuf[6] + 9)) && ((dat * 2) == shostUSART_RxBuf[6]))
													{
														  shostUSART_TxLen = funSubModbusRx10_CallBack(shostUSART_RxBuf[0], reg, dat, &shostUSART_RxBuf[7] , shostUSART_TxBuf);
													}
													break;
										}
										
										if((shostUSART_TxLen > 0) && (shostUSART_TxBuf[0] != 0))
										{
												shostUSART_TxLen = Modbus_Send(shostUSART_TxBuf, shostUSART_TxLen);//��ȡshostUSART_TxBuf[TxLen]��shostUSART_TxBuf[TxLen+1]����
											
												USARTx_Send(HOST_SerialPort,  shostUSART_TxBuf, shostUSART_TxLen);//��shostUSART_TxBuf[0]shostUSART_TxBuf[TxLen+1]����
										}
								}				
						}
						
						shostUSART_RxLen = 0;
				}	
				
				CanTask();	
				
				vTaskDelay(5/portTICK_RATE_MS); 
		}
}




#define   CanProFIFOLen	  64
CanTxMsg  CanProFIFO[CanProFIFOLen];
int8_t CanProFIFO_start, CanProFIFO_end; //����Ǳ�ʾ������

void CanTask(void)
{
		if(((CAN1->TSR & CAN_TSR_TME) != 0)	   //�п�����
		&&(CanProFIFO_start != CanProFIFO_end))//������
		{
				CAN_Transmit(CAN1, &CanProFIFO[CanProFIFO_start]);
			
				CanProFIFO_start++;
				if(CanProFIFO_start >= CanProFIFOLen)
				{
					  CanProFIFO_start = 0; 
				}
		}
}

void funAddCanFram(uint8_t da, uint8_t *buf, uint8_t cnt)
{
		int8_t next;
		CanTxMsg TxMessage;
		
		TxMessage.ExtId = CanProNo | (da << 11) | (ThisCanAddr << 3);
	
		if(da != 0xFF)
		{
				TxMessage.ExtId |= 1<< 19;	//
		}
		if(cnt != 0)
		{
				TxMessage.ExtId |= 0x04;	//cnt
		}
		
		TxMessage.RTR = CAN_RTR_DATA;
		TxMessage.IDE = CAN_ID_EXT;
		TxMessage.DLC = 8;	
		
		next = CanProFIFO_end + 1;
		if(next >= CanProFIFOLen)
		{
				next = 0; 
		}
		if(CanProFIFO_start != next)	//�п�λ
		{
				CanProFIFO[CanProFIFO_end].ExtId = TxMessage.ExtId;
				CanProFIFO[CanProFIFO_end].RTR = TxMessage.RTR;
				CanProFIFO[CanProFIFO_end].IDE = TxMessage.IDE;
				CanProFIFO[CanProFIFO_end].DLC = TxMessage.DLC;
				CanProFIFO[CanProFIFO_end].Data[0] = buf[0];
				CanProFIFO[CanProFIFO_end].Data[1] = buf[1];
				CanProFIFO[CanProFIFO_end].Data[2] = buf[2];
				CanProFIFO[CanProFIFO_end].Data[3] = buf[3];
				CanProFIFO[CanProFIFO_end].Data[4] = buf[4];
				CanProFIFO[CanProFIFO_end].Data[5] = buf[5];
				CanProFIFO[CanProFIFO_end].Data[6] = buf[6];
				CanProFIFO[CanProFIFO_end].Data[7] = buf[7];
				
				CanProFIFO_end = next;
		}
}

void funCanProReadReFram(uint8_t cmd, uint8_t No, int16_t dat1,int16_t dat2,int16_t dat3,uint8_t *buf)
{
		buf[0] = cmd;
		buf[1] = No;				
		buf[2] = (dat1 >> 8) & 0xFF;	
		buf[3] = dat1 & 0xFF;
		buf[4] = (dat2 >> 8) & 0xFF;	
		buf[5] = dat2 & 0xFF;	
		buf[6] = (dat3 >> 8) & 0xFF;
		buf[7] = dat3 & 0xFF;				
}

int8_t funCanSend04(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat1,uint16_t dat2, uint16_t dat3)
{
		uint8_t buf[8];
		
		funCanProReadReFram(0x04, cmd, dat1, dat2, dat3, buf);	
		funAddCanFram(dst, buf, cnt);
		return 1;
}

int8_t funCanSend05(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat1,uint16_t dat2, uint16_t dat3)
{
		uint8_t buf[8];
		
		funCanProReadReFram(0x05, cmd, dat1, dat2, dat3, buf);	
		funAddCanFram(dst, buf, cnt);
		return 1;
}

int8_t funCanSend06(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat1,uint16_t dat2, uint16_t dat3)
{
		uint8_t buf[8];
		
		funCanProReadReFram(0x06, cmd, dat1, dat2, dat3, buf);	
		funAddCanFram(dst, buf, cnt);
		return 1;
}


int8_t funCanSend10(uint8_t dst, uint8_t cnt, uint8_t cmd, uint16_t dat)
{
		uint8_t buf[8];
		
		funCanProReadReFram(0x10, cmd, dat, 0, 0, buf);	
		funAddCanFram(dst, buf, cnt);
		return 1;
}

__weak void funCanPrase(uint8_t src, uint8_t cnt, uint8_t *pData)
{
}


void funCanRX(uint32_t rxID, uint8_t *pData)
{
		uint8_t dst, src, cnt, ptp;
	
		if((rxID & 0x1FF00000) == CanProNo)
		{
				ptp = (rxID >> 19) & 0x01;
				dst = (rxID >> 11) & 0xFF;
				src = (rxID >> 3) & 0xFF;
				cnt = (rxID >> 2) & 0x01;
				
				if(((ptp != 0) && (dst == ThisCanAddr))	//������ַ
				|| ((ptp == 0) && (dst == 0xFF)))		//�㲥��ַ
				{
						funCanPrase(src, cnt, pData);
				}
		}
}
