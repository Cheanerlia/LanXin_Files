/********************************************************************************
������¼����FRAM
������¼����FRAM
�ŵ��¼����BK SRAM
ʵʱ���ݴ���SPI FLASH

*********************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include "sys.h"
#include "configure.h"
#include "bspBIMS.h"
#include "protect.h"
#include <string.h>




extern unsigned short Modbus_CRC16(unsigned char *updata, unsigned short len);
extern unsigned short Modbus_Send(unsigned char *updata, unsigned short len);

int32_t drvFramWrite(uint16_t FramAddr, uint8_t *buf, int32_t len);
int32_t drvFramRead(uint16_t FramAddr, uint8_t *buf, int32_t len);


ResRecordStruct ResRpt[ResRptMax] 	__attribute__ ((aligned (4)));
ActRecordStruct ActRpt[ActRptMax] 	__attribute__ ((aligned (4)));

AlarmRecordStruct AlarmRpt[AlarmRptMax] 	__attribute__ ((aligned (4)));
AlarmRecordStruct ProtectRpt[ProtectRptMax] 	__attribute__ ((aligned (4)));

AlarmRecordStruct AlarmList[AlarmListMax] ;


int8_t funDateTimeCmp(DateTimeStruct *time1, DateTimeStruct * time2);


//	int16_t sLastResValue[DevSubMax];
//	DateTimeStruct sLastResTime[DevSubMax];
void ActRptInit(void);
void ResRptInit(void);
void AlarmRptInit(void);
void funRptInit(void)
{
	ActRptInit();
	ResRptInit();
	
	AlarmRptInit();
}

void funClrRecord(void)
{
	SysData.sResRptNum = 0;	
	SysData.sResRptLast = 0;
	
	memset(SysData.sLastResTime, 0, sizeof(SysData.sLastResTime));
	memset(SysData.sLastResValue, 0, sizeof(SysData.sLastResValue));
	
	memset(&ResRpt, 0, sizeof(ResRpt));
	drvFramWrite(ResTestRptAddr, (uint8_t *)&ResRpt, sizeof(ResRpt));
	
	
	SysData.ActionListLast = 0;
	SysData.ActionListNum = 0;
	
	memset(SysData.sLastActTime, 0, sizeof(SysData.sLastActTime));
	memset(SysData.sLastActValue, 0, sizeof(SysData.sLastActValue));
	
	memset(ActRpt, 0, sizeof(ActRpt));
	drvFramWrite(ActRptAddr, (uint8_t *)&ActRpt, sizeof(ActRpt));
	//�澯��ʼ��
	SysData.AlarmRptLast = 0;
	SysData.AlarmRptNum = 0;
	
	memset(AlarmRpt, 0, sizeof(AlarmRpt));
	drvFramWrite(AlarmRptAddr, (uint8_t *)&AlarmRpt, sizeof(AlarmRpt));

}
/****************************************************************************************
������Լ�¼
******************************************************************************************/
void ResRptInit(void)
{
	int16_t i;
	drvFramRead(ResTestRptAddr, (uint8_t *)&ResRpt, sizeof(ResRpt));
	
	SysData.sResRptLast = 0;
	SysData.sResRptNum = 0;
	
	memset(SysData.sLastResTime, 0, sizeof(SysData.sLastResTime));
	memset(SysData.sLastResValue, 0, sizeof(SysData.sLastResValue));
	
	for(i = 0; i < ResRptMax; i ++)
	{
		if((ResRpt[i].Valive == Valive_True)	//��¼��Ч
			&& (Modbus_CRC16((uint8_t *)&ResRpt[i], sizeof(ResRecordStruct)) == 0))
		{
			if((ResRpt[i].CellNumber  >= 1) && (ResRpt[i].CellNumber <= DevSubMax))
			{
				if(funDateTimeCmp(&ResRpt[i].Time, &SysData.sLastResTime[ResRpt[i].CellNumber - 1]) > 0)	//�Ƿ񱾵�����¼�¼
				{
					SysData.sLastResValue[ResRpt[i].CellNumber - 1] = ResRpt[i].Value;
					memcpy(&SysData.sLastResTime[ResRpt[i].CellNumber - 1], &ResRpt[i].Time, sizeof(DateTimeStruct));
				}
			}
			if(SysData.sResRptNum == 0)
			{
				SysData.sResRptLast = i;
			}
			else
			{//Serial
				if(funDateTimeCmp(&ResRpt[i].Time, &ResRpt[SysData.sResRptLast].Time) > 0)
				{
					SysData.sResRptLast = i;
				}
				else if(funDateTimeCmp(&ResRpt[i].Time, &ResRpt[SysData.sResRptLast].Time) == 0)	//ʱ����ͬ
				{
					if(ResRpt[i].Serial > ResRpt[SysData.sResRptLast].Serial)
					{
						SysData.sResRptLast = i;
					}
				}
			}			//
			SysData.sResRptNum++;
		}
	}
	//�������Ҫ�����2�μ��飬�޳��������ļ�¼
}

DateTimeStruct ResLastTime;
uint16_t ResLastSerial;
void ResRptAdd(uint8_t cell, int16_t reaValue)
{
	int16_t last;
	
	if(SysData.sResRptNum == 0)	//�޼�¼
	{
		last = 0;
	}
	else
	{
		last = SysData.sResRptLast + 1;
	}
	if(last >= ResRptMax)
	{
		last = 0;
	}
	
	memcpy(&ResRpt[last].Time, &Now, sizeof(DateTimeStruct));
	ResRpt[last].CellNumber = cell;
	ResRpt[last].Valive = Valive_True;
	ResRpt[last].Value = reaValue;
	if(funDateTimeCmp(&ResLastTime, &ResRpt[last].Time) == 0)	//ʱ����ͬ
	{
		ResLastSerial++;
		ResRpt[last].Serial = ResLastSerial;
	}
	else
	{
		
		ResLastSerial = 0;
		ResRpt[last].Serial = 0;
	}	
	memcpy(&ResLastTime, &ResRpt[last].Time, sizeof(DateTimeStruct));
	
	Modbus_Send((uint8_t *)&ResRpt[last], sizeof(ResRecordStruct) - 2);
	//����	
	drvFramWrite(ResTestRptAddr + (last * sizeof(ResRecordStruct)), (uint8_t *)&ResRpt[last], sizeof(ResRecordStruct));
	
	SysData.sResRptLast = last;
	SysData.sResRptNum++;
	if(SysData.sResRptNum > ResRptMax)
	{
		SysData.sResRptNum = ResRptMax;
	}
}

void ResAdd(uint8_t cell, int16_t reaValue)
{
	if((cell  >= 1) && (cell <= DevSubMax))
	{
		SysData.sLastResValue[cell - 1] = reaValue;
		memcpy(&SysData.sLastResTime[cell - 1], &Now, sizeof(DateTimeStruct));
		
		ResRptAdd(cell, reaValue);
	}
}
//#define ActType_PreChg	0x01
//#define ActType_DisChg	0x02
//#define ActType_EndChg	0x03
//#define ActType_PlusChg	0x04
/****************************************************************************************
���¼
******************************************************************************************/
void ActRptInit(void)
{
	int16_t i;	//ActRecordStruct
	drvFramRead(ActRptAddr, (uint8_t *)&ActRpt, sizeof(ActRpt));
	
	SysData.ActionListLast = 0;
	SysData.ActionListNum = 0;
	
	memset(SysData.sLastActTime, 0, sizeof(SysData.sLastActTime));
	memset(SysData.sLastActValue, 0, sizeof(SysData.sLastActValue));
	
	for(i = 0; i < ActRptMax; i ++)
	{
		if((ActRpt[i].StopValive != 0)	//��¼��Ч
			&& (Modbus_CRC16((uint8_t *)&ActRpt[i], sizeof(ActRecordStruct)) == 0))
		{
			if((ActRpt[i].CellNumber  >= 1) && (ActRpt[i].CellNumber <= DevSubMax))
			{
				if((ActRpt[i].StopValive == ActMode_Auto)	//�Զ�ֹͣ�����ŵ���������
					&& (ActRpt[i].ActType == ActType_DisChg))	//�ŵ�
				{
					if(funDateTimeCmp(&ActRpt[i].Start, &SysData.sLastActTime[ActRpt[i].CellNumber - 1]) > 0)	//�Ƿ񱾵�����¼�¼
					{
						SysData.sLastActValue[ActRpt[i].CellNumber - 1] = ActRpt[i].Value;
						memcpy(&SysData.sLastActTime[ActRpt[i].CellNumber - 1], &ActRpt[i].Start, sizeof(DateTimeStruct));
					}
				}
			}
			if(SysData.ActionListNum == 0)
			{
				SysData.ActionListLast = i;
			}
			else
			{//Serial
				if(funDateTimeCmp(&ActRpt[i].Start, &ActRpt[SysData.ActionListLast].Start) > 0)
				{
					SysData.ActionListLast = i;
				}
				else if(funDateTimeCmp(&ActRpt[i].Start, &ActRpt[SysData.sResRptLast].Start) == 0)	//ʱ����ͬ
				{
					if(ActRpt[i].Serial > ActRpt[SysData.ActionListLast].Serial)
					{
						SysData.ActionListLast = i;
					}
				}
			}			//
			SysData.ActionListNum++;
		}
	}
	//�������Ҫ�����2�μ��飬�޳��������ļ�¼
}

DateTimeStruct ActLastTime;
uint16_t ActLastSerial;
void ActRptAddStart(uint8_t cell, int8_t ActType)
{
	int16_t last;
	
	if(SysData.ActionListNum == 0)	//�޼�¼
	{
		last = 0;
	}
	else
	{
		last = SysData.ActionListLast + 1;
	}
	if(last >= ActRptMax)
	{
		last = 0;
	}
	
	memcpy(&ActRpt[last].Start, &Now, sizeof(DateTimeStruct));
	memset(&ActRpt[last].Stop, 0, sizeof(DateTimeStruct));
	ActRpt[last].CellNumber = cell;
	ActRpt[last].ActType = ActType;
	
	ActRpt[last].Value = 0;
	ActRpt[last].StopValive = 0;
	ActRpt[last].ActTime = 0;
	
	if(funDateTimeCmp(&ActLastTime, &ActRpt[last].Start) == 0)	//ʱ����ͬ
	{
		ActLastSerial++;
		ActRpt[last].Serial = ActLastSerial;
	}
	else
	{
		
		ActLastSerial = 0;
		ActRpt[last].Serial = 0;
	}	
	memcpy(&ActLastTime, &ActRpt[last].Start, sizeof(DateTimeStruct));
	
	Modbus_Send((uint8_t *)&ActRpt[last], sizeof(ActRecordStruct) - 2);
	//����	
	drvFramWrite(ActRptAddr + (last * sizeof(ActRecordStruct)), (uint8_t *)&ActRpt[last], sizeof(ActRecordStruct));
	
	SysData.ActionListLast = last;
	SysData.ActionListNum++;
	if(SysData.ActionListNum > ActRptMax)
	{
		SysData.ActionListNum = ActRptMax;
	}
}

void ActRptAddStop(uint8_t cell, int8_t stop, int16_t Value, uint16_t time)
{	
	if(ActRpt[SysData.ActionListLast].CellNumber == cell)
	{
		if(ActRpt[SysData.ActionListLast].ActType == ActType_DisChg)	//�ŵ����
		{
			if(stop == ActMode_Auto)	//�Զ����
			{//����SOH
				if((cell >= 1) && (cell <= DevSubMax))
				{
						SysData.sLastActValue[cell - 1] = Value;
						memcpy(&SysData.sLastActTime[cell - 1], &Now, sizeof(DateTimeStruct));
				}
			}
		}
		memcpy(&ActRpt[SysData.ActionListLast].Stop, &Now, sizeof(DateTimeStruct));

		ActRpt[SysData.ActionListLast].CellNumber = cell;
		
		ActRpt[SysData.ActionListLast].Value = Value;
		ActRpt[SysData.ActionListLast].StopValive = stop;
		ActRpt[SysData.ActionListLast].ActTime = 0;
		
		Modbus_Send((uint8_t *)&ActRpt[SysData.ActionListLast], sizeof(ActRecordStruct) - 2);
		//����
		drvFramWrite(ActRptAddr + (SysData.ActionListLast * sizeof(ActRecordStruct)), (uint8_t *)&ActRpt[SysData.ActionListLast], sizeof(ActRecordStruct));
	}
}












/****************************************************************************************
�澯��������¼
******************************************************************************************/
void AlarmRptInit(void)
{
	int16_t i;
	drvFramRead(AlarmRptAddr, (uint8_t *)&AlarmRpt, sizeof(AlarmRpt));
	drvFramRead(ProteRptAddr, (uint8_t *)&ProtectRpt, sizeof(ProtectRpt));

	//�澯��ʼ��
	SysData.AlarmRptLast = 0;
	SysData.AlarmRptNum = 0;
	for(i = 0; i < AlarmRptMax; i ++)
	{
		if((AlarmRpt[i].Alarm != 0)	//��¼��Ч
			&& (AlarmRpt[i].Alarm != 0xFF)
			&& (Modbus_CRC16((uint8_t *)&AlarmRpt[i], sizeof(AlarmRecordStruct)) == 0))
		{
			if(SysData.AlarmRptNum == 0)	//��1������
			{
				SysData.AlarmRptLast = i;
			}
			else
			{
				if(funDateTimeCmp(&AlarmRpt[i].Time, &AlarmRpt[SysData.AlarmRptLast].Time) > 0)	//���������
				{
					SysData.AlarmRptLast = i;
				}
				else if(funDateTimeCmp(&AlarmRpt[i].Time, &AlarmRpt[SysData.AlarmRptLast].Time) == 0)	//ʱ����ͬ
				{
					if(AlarmRpt[i].Serial > AlarmRpt[SysData.AlarmRptLast].Serial)
					{
						SysData.AlarmRptLast = i;
					}
				}
			}			
			SysData.AlarmRptNum++;
		}
	}
	//�������Ҫ�����2�μ��飬�޳��������ļ�¼
	
	//������¼��ʼ��
//	SysData.ProteRptLast = 0;
//	SysData.ProteRptNum = 0;
//	for(i = 0; i < ProtectRptMax; i ++)
//	{
//		if((ProtectRpt[i].Alarm != 0)	//��¼��Ч
//			&& (ProtectRpt[i].Alarm != 0xFF)
//			&& (Modbus_CRC16((uint8_t *)&ProtectRpt[i], sizeof(AlarmRecordStruct)) == 0))
//		{
//			if(SysData.ProteRptNum == 0)	//��1������
//			{
//				SysData.ProteRptLast = i;
//			}
//			else
//			{
//				if(funDateTimeCmp(&ProtectRpt[i].Time, &ProtectRpt[SysData.ProteRptLast].Time) > 0)	//���������
//				{
//					SysData.ProteRptLast = i;
//				}
//				else if(funDateTimeCmp(&ProtectRpt[i].Time, &ProtectRpt[SysData.ProteRptLast].Time) == 0)	//ʱ����ͬ
//				{
//					if(ProtectRpt[i].Serial > ProtectRpt[SysData.ProteRptLast].Serial)
//					{
//						SysData.ProteRptLast = i;
//					}
//				}
//			}			
//			SysData.ProteRptNum++;
//		}
//	}
}


DateTimeStruct AlarmLastTime, ProtectLastTime;
uint16_t AlarmSerial, ProtectSerial;
void AlarmRptAdd(uint8_t AlarmType, uint8_t cell, int16_t reaValue)
{
	int16_t last;
	
//	if(AlarmType & 0x40)	//�澯
	{
		if(SysData.AlarmRptNum == 0)	//�޼�¼
		{
			last = 0;
		}
		else
		{
			last = SysData.AlarmRptLast + 1;
		}
		if(last >= AlarmRptMax)
		{
			last = 0;
		}
		//�ҵ������Ҫ���µ�λ��
		memcpy(&AlarmRpt[last].Time, &Now, sizeof(DateTimeStruct));	//ʱ��Ǽ�		
		AlarmRpt[last].CellNumber = cell;	//��غ�
		AlarmRpt[last].Alarm = AlarmType & ~0x40;	//�澯����
		AlarmRpt[last].Value = reaValue;	//�澯ֵ
		if(funDateTimeCmp(&AlarmLastTime, &AlarmRpt[last].Time) == 0)	//ʱ����ͬ
		{
			AlarmSerial++;
			AlarmRpt[last].Serial = AlarmSerial;
		}
		else
		{
			
			AlarmSerial = 0;
			AlarmRpt[last].Serial = 0;
		}	
		memcpy(&AlarmLastTime, &AlarmRpt[last].Time, sizeof(DateTimeStruct));
		
		Modbus_Send((uint8_t *)&AlarmRpt[last], sizeof(AlarmRecordStruct) - 2);
		//����	
		drvFramWrite(AlarmRptAddr + (last * sizeof(AlarmRecordStruct)), (uint8_t *)&AlarmRpt[last], sizeof(AlarmRecordStruct));
		
		SysData.AlarmRptLast = last;
		SysData.AlarmRptNum++;
		if(SysData.AlarmRptNum > AlarmRptMax)
		{
			SysData.AlarmRptNum = AlarmRptMax;
		}	
	}
//	else	//����
//	{
//		if(SysData.ProteRptNum == 0)	//�޼�¼
//		{
//			last = 0;
//		}
//		else
//		{
//			last = SysData.ProteRptLast + 1;
//		}
//		if(last >= ProtectRptMax)
//		{
//			last = 0;
//		}
//		//�ҵ������Ҫ���µ�λ��
//		memcpy(&ProtectRpt[last].Time, &Now, sizeof(DateTimeStruct));	//ʱ��Ǽ�		
//		ProtectRpt[last].CellNumber = cell;	//��غ�
//		ProtectRpt[last].Alarm = AlarmType;	//�澯����
//		ProtectRpt[last].Value = reaValue;	//�澯ֵ
//		if(funDateTimeCmp(&ProtectLastTime, &ProtectRpt[last].Time) == 0)	//ʱ����ͬ
//		{
//			ProtectSerial++;
//			ProtectRpt[last].Serial = ProtectSerial;
//		}
//		else
//		{
//			
//			ProtectSerial = 0;
//			ProtectRpt[last].Serial = 0;
//		}	
//		memcpy(&ProtectLastTime, &ProtectRpt[last].Time, sizeof(DateTimeStruct));
//		
//		Modbus_Send((uint8_t *)&ProtectRpt[last], sizeof(AlarmRecordStruct) - 1);
//		
//	
//		//����	
//		drvFramWrite(ProteRptAddr + (last * sizeof(AlarmRecordStruct)), (uint8_t *)&ProtectRpt[last], sizeof(AlarmRecordStruct));
//		
//		SysData.ProteRptLast = last;
//		SysData.ProteRptNum++;
//		if(SysData.ProteRptNum > ProtectRptMax)
//		{
//			SysData.ProteRptNum = ProtectRptMax;
//		}	
//	}
}
void AlarmListInit(void)
{
	SysData.AlarmListNum = 0;
	
	memset(&AlarmList, 0, sizeof(AlarmList));
}


void AlarmAdd(uint8_t AlarmType, uint8_t cell, int16_t reaValue)
{
	int16_t i;
	
	for(i = AlarmListMax - 1; i > 0; i--)
	{
		memcpy(&AlarmList[i], &AlarmList[i - 1], sizeof(AlarmRecordStruct));
	}
	
	memcpy(&AlarmList[0].Time, &Now, sizeof(DateTimeStruct));
	AlarmList[0].CellNumber = cell;
	AlarmList[0].Alarm = AlarmType;
	AlarmList[0].Value = reaValue;
	SysData.AlarmListNum++;
	if(SysData.AlarmListNum > AlarmListMax)
	{
		SysData.AlarmListNum = AlarmListMax;
	}
	AlarmRptAdd(AlarmType, cell, reaValue);
}


void AlarmDel(uint8_t AlarmType, uint8_t cell, int16_t reaValue)
{
	int16_t i;
	
	for(i = 0; i < SysData.AlarmListNum; i++)
	{
		if((AlarmList[i].CellNumber == cell)
			&& (AlarmList[i].Alarm == AlarmType))
		{//�ҵ���
			memset(&AlarmList[i], 0, sizeof(AlarmRecordStruct));	//��0
			
			for(; i < AlarmListMax - 1; i++)
			{
				memcpy(&AlarmList[i], &AlarmList[i + 1], sizeof(AlarmRecordStruct));
			}
			memset(&AlarmList[AlarmListMax - 1], 0, sizeof(AlarmRecordStruct));	//�����һ��
			SysData.AlarmListNum--;
			break;
		}
	}
	AlarmRptAdd(AlarmType | 0x80, cell, reaValue);
}




















//	int16_t AlarmListNum;	

//typedef struct
//{
//  DateTimeStruct Time;	//��ʼʱ��	6byte
//	uint16_t Serial;			//���к�
//	uint8_t CellNumber;		//��ر�ż� 2
//  uint8_t Alarm;       //�������� 1
//  int16_t Value;       //ֵ 1

//	uint8_t res[2];	//����
//	uint16_t checkCRC;
//}AlarmRecordStruct;	//16Byte

//uint8_t RecordNew = 0;


//void drvFram_Init(void);

//void funActionListInit(void);
//void funAlarmListInit(void);


//unsigned short Modbus_CRC16(unsigned char *updata, unsigned short len);

//uint8_t AlarmListNew;


////�����ݱ��浽FRAM
//void threadRecord(void *pvParameters) 
//{
//	drvFram_Init();
////	drvEEPROMWrite(0,"1234567890",10);
////	drvEEPROMRead(0,TESTBUF,10);
//	funAlarmListInit();
//	
//	funActionListInit();
//	
//	
//	//��ȡ��¼
//	
//	// *(__IO uint32_t *) (BKPSRAM_BASE + uwIndex) = uwIndex;
//	
//	
//	
//	
//	for(;;)
//	{
//		if(AlarmListNew != 0)
//		{
//		}
//		//����зŵ��¼������
////		SysData.Shouhu |= 0x08;
////		if(RecordNew)
////		{
////			ActionNow.crc = Modbus_CRC16((unsigned char *)&ActionNow, sizeof(ActionStruct) - 2);
////			drvEEPROMWrite(64,(uint8_t *)&ActionNow,sizeof(ActionStruct));	//���1����¼
////			vTaskDelay(2/portTICK_RATE_MS);  
////			if(RecordNew > 1)	//������ЧSOH�ļ�¼
////			{
////				drvEEPROMWrite(0,(uint8_t *)&ActionNow,sizeof(ActionStruct));	//
////			}
////			RecordNew = 0;
////		}
//		vTaskDelay(10/portTICK_RATE_MS);  
//	}
//}

//int8_t funCheckAlarm(AlarmRecordStruct *alarm)
//{
//	if((Modbus_CRC16((uint8_t *)alarm, sizeof(AlarmRecordStruct)) == 0)
//		&& (alarm->Valid == AlarnList_Valid))
//	{
//		return 1;
//	}
//	return 0;
//}


//void funActionListInit(void)
//{
//	uint8_t i;
//	
//	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
//	PWR_BackupAccessCmd(ENABLE);
//	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_BKPSRAM, ENABLE);
//	
//	SysData.ActionListNum = *(__IO uint16_t *) BKPSRAM_BASE; 
//	memcpy(ActionRecord, (void *)(BKPSRAM_BASE + 4), sizeof(ActionRecord));
//	
//	if(SysData.ActionListNum > ActionListMax)
//	{ SysData.ActionListNum = ActionListMax;}
//	
//	for(i = 0; i < SysData.ActionListNum; i++)
//	{
//		if((Modbus_CRC16((uint8_t *)&ActionRecord[i], sizeof(ActionRecordStruct)) != 0)
//			|| (ActionRecord[i].Valid != AlarnList_Valid))
//		{
//			SysData.ActionListNum = i ;
//			break;
//		}
//	}	
//}

//void funActionListAdd(void)
//{
//	uint8_t i;
//	
//	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
//	PWR_BackupAccessCmd(ENABLE);
//	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_BKPSRAM, ENABLE);
//	
//	SysData.ActionListNum = *(__IO uint16_t *) BKPSRAM_BASE; 
//	memcpy(ActionRecord, (void *)(BKPSRAM_BASE + 4), sizeof(ActionRecord));
//	
//	if(SysData.ActionListNum > ActionListMax)
//	{ SysData.ActionListNum = ActionListMax;}
//	
//	for(i = 0; i < SysData.ActionListNum; i++)
//	{
//		if((Modbus_CRC16((uint8_t *)&ActionRecord[i], sizeof(ActionRecordStruct)) != 0)
//			|| (ActionRecord[i].Valid != AlarnList_Valid))
//		{
//			SysData.ActionListNum = i ;
//			break;
//		}
//	}	
//}


//void funAlarmListInit(void)
//{
//	int16_t i;
//	int16_t Last = 0;
//	if(funCheckAlarm(&AlarmHis[Last]) <= 0)
//	{
//		AlarmHis[Last].AlarmTime.Year = 0;
//		AlarmHis[Last].AlarmTime.Mon = 1;
//		AlarmHis[Last].AlarmTime.Day = 1;
//		AlarmHis[Last].AlarmTime.Hour = 0;
//		AlarmHis[Last].AlarmTime.Min = 0;
//		AlarmHis[Last].AlarmTime.Sec = 0;
//		AlarmHis[Last].AlarmType = 0;
//	}
//	for(i = 0; i < AlarmHisMax; i++)
//	{
//		if(funCheckAlarm(&AlarmHis[i]) > 0)
//		{
//			if(funDateTimeCmp(&AlarmHis[i].AlarmTime, &AlarmHis[Last].AlarmTime) >= 0)
//			{
//				Last = i;
//			}
//		}
//	}
//	//�Ѳ���������
//	if(funCheckAlarm(&AlarmHis[Last]) <= 0)
//	{//����Ч����
//		SysData.AlarmHisLast = 0;
//		SysData.AlarmHisNum = 0;
//	}
//	else
//	{
//		SysData.AlarmHisLast = Last;
//		for(i = 0; i < AlarmHisMax; i++)
//		{
//			if(funCheckAlarm(&AlarmHis[(Last + AlarmHisMax - i) % 100]) > 0)
//			{
//				SysData.AlarmHisNum++;
//			}
//			else
//			{
//				break;
//			}
//		}
//	}
//}


////void funAlarmHisAdd(int8_t AlarmType, int8_t ch,  int16_t sub)
//void funAlarmListAdd(AlarmRecordStruct *record)
//{
////	if((AlarmType & 0x80) == 0)
////	{	
////		ScrBeepEn = 1;
////	}
//	if(SysData.AlarmHisNum == 0)
//	{
//		SysData.AlarmHisLast = 0;
//		SysData.AlarmHisNum = 1;
//	}
//	else
//	{
//		SysData.AlarmHisLast = (SysData.AlarmHisLast + 1) % AlarmHisMax;
//		if(SysData.AlarmHisNum < AlarmHisMax)
//		{
//			SysData.AlarmHisNum ++;
//		}
//	}
//	
////	AlarmNow.AlarmTime.Year = SystemData.DateTime.Year;
////	AlarmNow.AlarmTime.Mon = SystemData.DateTime.Mon;
////	AlarmNow.AlarmTime.Days = SystemData.DateTime.Days;
////	AlarmNow.AlarmTime.Hour = SystemData.DateTime.Hour;
////	AlarmNow.AlarmTime.Min = SystemData.DateTime.Min;
////	AlarmNow.AlarmTime.Sec = SystemData.DateTime.Sec;
////	
////	AlarmNow.AlarmType = AlarmType;
////	AlarmNow.Seg = ch + 1;
////	AlarmNow.Valid = AlarnList_Valid;
////	Modbus_Send((uint8_t *)&AlarmNow, sizeof(ALARMTypeDef_Struct) - 2);


//	memcpy(&AlarmHis[SysData.AlarmHisLast], record,sizeof(AlarmRecordStruct));
//	//Modbus_Send((uint8_t *)&AlarmHis[SystemData.AlarmHisLast], sizeof(ALARMTypeDef_Struct) - 2);
//	AlarmRecoedFlag[SysData.AlarmHisLast] = 1;
//	
//	AlarmListNew = 1;
//}


int8_t funDataCmp(int8_t d1, int8_t d2)
{
	if(d1 > d2)
	{	return 1;}
	else if(d1 < d2)
	{
		return -1;
	}
	return 0;		
}
int8_t funDateTimeCmp(DateTimeStruct *time1, DateTimeStruct * time2)
{
	int8_t ret;
	ret = funDataCmp(time1->Year , time2->Year);
	
	if(ret == 0)//�����
	{
		ret = funDataCmp(time1->Mon , time2->Mon);
		
		if(ret == 0)//���
		{
			ret = funDataCmp(time1->Day , time2->Day);
			
			if(ret == 0)//���
			{
				ret = funDataCmp(time1->Hour , time2->Hour);
				
				if(ret == 0)//���
				{
					ret = funDataCmp(time1->Min , time2->Min);
					
					if(ret == 0)//���
					{
						ret = funDataCmp(time1->Sec , time2->Sec);
					}					
				}				
			}
		}
	}
	return ret;
}

