/*******************************************************************************************************
	D28~D20	|	D19	|	D18~D11	|	D10~D3	|	D2	|	D1~D0	
	PRO_NO		PTP		DA(Bbit)	SA(8bit)	CNT		RES

PRO_NO:	0x190			
PTP:	1����Ե�  0:�㲥���㲥ʱDA=0xFF
DA:	Ŀ���ַ
SA:	Դ��ַ
CNT:������־��1:�к���	0:���һ֡

MSGTYPE	Fun	Data Information
1Byte	1Byte	6Bytes
MSGTYPE��������0x04Ϊ��ѯ	������0x10Ϊ����	0xF0Ϊ����������

*******************************************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include "sys.h"
#include "configure.h"
#include "bspBIMS.h"
#include "BSP.h"
#include "drvAI.h"
#include "tskmain.h"
#include "protect.h"
#include <string.h>

#define CANBUS CAN1

#define CanProNo	0x190

#define CanCMDRead		0x04
#define CanCMDWrite		0x10
#define CanCMDFaDef		0xF0
#define CanProFramAve	0xF0


#define CanProFIFOLen	64
CanTxMsg CanProFIFO[CanProFIFOLen];
int8_t CanProFIFO_start, CanProFIFO_end;	//����Ǳ�ʾ������

void funToFloat(void);
void funToEquel(void);




void CanConfigSave(void);


void threadCanPro(void *pvParameters) 
{
	for(;;)
	{
		
		
		while(((CANBUS->TSR & CAN_TSR_TME) != 0)	//�п�����
			&& (CanProFIFO_start != CanProFIFO_end))	//������
		{
			CAN_Transmit(CANBUS, &CanProFIFO[CanProFIFO_start]);
			CanProFIFO_start++;
			if(CanProFIFO_start >= CanProFIFOLen)
			{
				CanProFIFO_start = 0; 
			}
		}
		
		
		CanConfigSave();
		vTaskDelay(5/portTICK_RATE_MS);  
	}
}



void funCanFramInit()
{
	CanProFIFO_start = 0;
	CanProFIFO_end = 0;
}


void funAddCanFram(uint8_t da, uint8_t *buf, uint8_t cnt)
{
	int8_t next;
	CanTxMsg TxMessage;
	
	TxMessage.ExtId = (CanProNo << 20) | (da << 11) | (SysData.Addr << 3);
	if(da != 0xFF)
	{
		TxMessage.ExtId |= 1<< 19;	//
	}
	if(cnt != 0)
	{
		TxMessage.ExtId |= 0x04;	//cnt
	}
  
  TxMessage.RTR = CAN_RTR_DATA;
  TxMessage.IDE = CAN_ID_EXT;
  TxMessage.DLC = 8;	
	
	next = CanProFIFO_end + 1;
	if(next >= CanProFIFOLen)
	{
		next = 0; 
	}
	if(CanProFIFO_start != next)	//�п�λ
	{
		CanProFIFO[CanProFIFO_end].ExtId = TxMessage.ExtId;
		CanProFIFO[CanProFIFO_end].RTR = TxMessage.RTR;
		CanProFIFO[CanProFIFO_end].IDE = TxMessage.IDE;
		CanProFIFO[CanProFIFO_end].DLC = TxMessage.DLC;
		CanProFIFO[CanProFIFO_end].Data[0] = buf[0];
		CanProFIFO[CanProFIFO_end].Data[1] = buf[1];
		CanProFIFO[CanProFIFO_end].Data[2] = buf[2];
		CanProFIFO[CanProFIFO_end].Data[3] = buf[3];
		CanProFIFO[CanProFIFO_end].Data[4] = buf[4];
		CanProFIFO[CanProFIFO_end].Data[5] = buf[5];
		CanProFIFO[CanProFIFO_end].Data[6] = buf[6];
		CanProFIFO[CanProFIFO_end].Data[7] = buf[7];
		
		CanProFIFO_end = next;
	}
}





void funCanAveCurr(void)
{
	uint8_t TBuf[8];
	int16_t AvePwm;
	
  TBuf[0] = CanCMDFaDef;
  TBuf[1] = CanProFramAve;
	
	if(((SysData.RunSts &	SysSts_LineO) != 0)
		&& ((SysData.DevErr &	AlarmLinOutErr) == 0))
  {	//�е�ģʽ���
		
    AvePwm = drvBSP_PWMGet(PWM_OutIqL);		
		TBuf[2] = 1;
		TBuf[3] = 0;
		if(SysData.RunSts & SysSts_Active)
		{
			TBuf[3] = 1;
		}
		else if(SysData.RunSts & SysSts_Res)
		{
			TBuf[3] = 2;
		}
		TBuf[4] = (SysData.AdcValue_D[ADC_Cnl_IlineOut] >> 8) & 0xFF;
		TBuf[5] = SysData.AdcValue_D[ADC_Cnl_IlineOut] & 0xFF;
		TBuf[6] = (AvePwm >> 8) & 0xFF;
		TBuf[7] = AvePwm & 0xFF;
  }
//  else if((drvBSP_CtrlIO_Sts(bspCtrlIO_RlyBat) != 0)
//        && (drvBSP_CtrlIO_Sts(bspCtrlIO_OutBat) != 0
	else if(((SysData.RunSts &	SysSts_BatO) != 0)
		&& ((SysData.DevErr &	AlarmBatOutErr) == 0))
  {	//���ģʽ
    AvePwm = drvBSP_PWMGet(PWM_OutIqB);
		TBuf[2] = 2;
		TBuf[3] = 0;
		TBuf[5] = SysData.AdcValue_D[ADC_Cnl_IBatOut] & 0xFF;
		TBuf[4] = (SysData.AdcValue_D[ADC_Cnl_IBatOut] >> 8) & 0xFF;
		TBuf[7] = AvePwm & 0xFF;
		TBuf[6] = (AvePwm >> 8) & 0xFF;
  }
  else	//����
  {
		TBuf[2] = 0;
		TBuf[3] = 0;
		TBuf[4] = 0;
		TBuf[5] = 0;
		TBuf[6] = 0;
		TBuf[7] = 0;
  }
	
	funAddCanFram(0xFF, TBuf, 0);

  //
}


//#define CanProFramAve	0xF0


int16_t funCanYX1(void)
{
	int16_t yx;
	
	yx = 0;
	if(SysData.Alarm & AlarmACOV )
	{ yx |= 0x0001;	}
	if(SysData.Alarm & AlarmACUV )
	{ yx |= 0x0002;	}	
	
	if((SysData.DevErr & AlarmLinOutErr )
		&& (SysData.DevErr & AlarmBatOutErr ))
	{ yx |= 0x0020;	}
	if(SysData.DevErr & AlarmDevOTErr )
	{ yx |= 0x0080;	}	
	
	if(SysData.Alarm & AlarmBATNOK )
	{ yx |= 0x0400;	}
	if(SysData.Alarm & AlarmBATOT )
	{ yx |= 0x0800;	}
	if(SysData.Alarm & (AlarmCellOV | AlarmBATOV))
	{ yx |= 0x2000;	}
	if(SysData.Alarm & (AlarmCellUV | AlarmBATUV))
	{ yx |= 0x4000;	}
	return yx;
}
int16_t funCanYX2(void)
{
	int16_t yx;
	yx = 0;
	if(SysData.AdcValue[ADC_Cnl_VBatOut] > SysData.AdcValue[ADC_Cnl_VlineOut] )
	{
		yx	|= 0x01;
	}
	//if(drvBSP_CtrlIO_Sts(bspCtrlIO_CHGBat) != 0)
	if(SysData.sBatCurr < 0)
	{
		yx	|= 0x02;
	}
	if(SysData.RunSts & SysSts_Queal)
	{
		yx	|= 0x04;
	}
	if(SysData.RunSts & SysSts_Active)
	{
		yx	|= 0x08;
	}
//	if((drvBSP_CtrlIO_Sts(bspCtrlIO_OutLin) == 0)
//		&& (drvBSP_CtrlIO_Sts(bspCtrlIO_OutBat) == 0)
//		&& (drvBSP_CtrlIO_Sts(bspCtrlIO_CHGBat) == 0))
	if((SysData.RunSts & SysSts_ON) == 0)
	{
		yx	|= 0x10;
	}
	if(SysData.DevErr & AlarmDevOTErr )
	{ yx |= 0x0200;	}	
	
	return yx;
}


void funCanProReadReFram(uint8_t No, int16_t dat1,int16_t dat2,int16_t dat3,uint8_t *buf)
{
	buf[0] = CanCMDRead;
	buf[1] = No;				
	buf[2] = (dat1 >> 8) & 0xFF;	
	buf[3] = dat1 & 0xFF;
	buf[4] = (dat2 >> 8) & 0xFF;	
	buf[5] = dat2 & 0xFF;	
	buf[6] = (dat3 >> 8) & 0xFF;
	buf[7] = dat3 & 0xFF;				
}
extern uint32_t ComErrTick;
void funCanProRead(uint8_t dst, uint8_t src, uint8_t *buf)
{
	uint8_t TBuf[8];
	uint16_t cmd;
	int16_t sData[3];
	float ftemp;
	if(buf[0] != CanCMDRead)
	{return ; }
	if (dst != SysData.Addr)	//�㲥��ַ��Ӧ�𣬱��뱾����ַ
	{return ; }
	
	ComErrTick = xTaskGetTickCount();
	SysData.ComErrCnt = 0;
	
	cmd = buf[2] | (buf[3] << 8);
	switch(buf[1])
	{
		case 0x10:
			if(cmd == 0)
			{
				//0x10
				ftemp = SysData.AdcValue[ADC_Cnl_VlineOut] > SysData.AdcValue[ADC_Cnl_VBatOut] ?
					SysData.AdcValue[ADC_Cnl_VlineOut] : SysData.AdcValue[ADC_Cnl_VBatOut];
				sData[0] = (int16_t)(ftemp * 10);		
					
				if((drvBSP_CtrlIO_Sts(bspCtrlIO_RlyLin) != 0)
							&& (drvBSP_CtrlIO_Sts(bspCtrlIO_PFCLin) != 0)
							&& (drvBSP_CtrlIO_Sts(bspCtrlIO_OutLin) != 0))
				{
					sData[1] = (int16_t)(SysData.AdcValue[ADC_Cnl_IlineOut] * 10);
				}
				else if((drvBSP_CtrlIO_Sts(bspCtrlIO_RlyBat) != 0)
							&& (drvBSP_CtrlIO_Sts(bspCtrlIO_OutBat) != 0))
				{
					sData[1] = (int16_t)(SysData.AdcValue[ADC_Cnl_IBatOut] * 10);
				}
				else
				{
					sData[1] = 0;
				}		
				sData[1]  = (int16_t)(SysData.AdcValue[ADC_Cnl_IBatOut] * 10) + (int16_t)(SysData.AdcValue[ADC_Cnl_IlineOut] * 10);
				
				ftemp = SysData.AdcValue[ADC_Cnl_T1] > SysData.AdcValue[ADC_Cnl_T2] ?
								SysData.AdcValue[ADC_Cnl_T1] : SysData.AdcValue[ADC_Cnl_T2];
				sData[2] = (int16_t)(ftemp * 10);						
				funCanProReadReFram(0x10,sData[0], sData[1], sData[2],TBuf);
				funAddCanFram(src, TBuf, 1);
				
				//0x11			
//				if((drvBSP_CtrlIO_Sts(bspCtrlIO_RlyLin) != 0)
//							&& (drvBSP_CtrlIO_Sts(bspCtrlIO_PFCLin) != 0)
//							&& (drvBSP_CtrlIO_Sts(bspCtrlIO_CHGBat) != 0))
//				{
//					//funCanProReadReFram(0x11,(int16_t)(SysData.fBatVolt * 10), (int16_t)(SysData.AdcValue[ADC_Cnl_IChg] * 10), (int16_t)(ConfigData.sRatioAH * 10),  TBuf);
//					sData[0] = (int16_t)(SysData.AdcValue[ADC_Cnl_IChg] * 10);
//				}
//				else
//				{
//					sData[0] = -(int16_t)(SysData.AdcValue[ADC_Cnl_IBat] * 10);
//				}
				
				//funCanProReadReFram(0x11,(int16_t)(SysData.fBatVolt * 10), (int16_t)(SysData.AdcValue[ADC_Cnl_IBat] * 10), (int16_t)(ConfigData.sRatioAH * 10),  TBuf);
				funCanProReadReFram(0x11,(int16_t)(SysData.fBatVolt * 10), SysData.sBatCurr / 10, (int16_t)(ConfigData.sRatioAH * 10),  TBuf);
				funAddCanFram(src, TBuf, 1);
				//0x12							
				if(SysData.RunSts & SysSts_Active)
				{
					sData[2] = 3;	//����
				}
				else if(SysData.RunSts & SysSts_Queal)
				{
					sData[2] = 1;	//����
				}
				else
				{
					sData[2] = 0;	//����
				}
				funCanProReadReFram(0x12,(int16_t)((SysData.SOH * ConfigData.sRatioAH) / 10), (int16_t)(SysData.AdcValue[ADC_Cnl_Tbat] * 10), sData[2],  TBuf);
				funAddCanFram(src, TBuf, 1);
				//0x13
				//funCanProReadReFram(0x13,funCanYX1(), funCanYX2(),  (int16_t)(SysData.AdcValue[ADC_Cnl_Vac] * 10),  TBuf);
				funCanProReadReFram(0x13,(int16_t)(SysData.AdcValue[ADC_Cnl_VBat1] * 10), (int16_t)(SysData.AdcValue[ADC_Cnl_VBat2] * 10),  
														(int16_t)(SysData.AdcValue[ADC_Cnl_Vac] * 10),  TBuf);
				funAddCanFram(src, TBuf, 0);
			}
			break;
		case 0x20:
			if(cmd == 0)
			{
				funCanProReadReFram(0x20,funCanYX1(), funCanYX2(),  0,  TBuf);
				funAddCanFram(src, TBuf, 0);
			}
			break;
		case 0x30:
			if(cmd == 0)
			{
				funCanProReadReFram(0x30,1, ConfigData.sRatioAH,  ConfigData.sBatFloatVolt / 10,  TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x31, ConfigData.sBatEqualVolt / 10, 
																	(BatChgCurrMax * 100) / ConfigData.sRatioAH < 10 ? (BatChgCurrMax * 100) / ConfigData.sRatioAH :10,  
																	ConfigData.sBatEqualStartCurr / ConfigData.sRatioAH,  TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x32, ConfigData.sBatEqualStopCurr / ConfigData.sRatioAH, 0,  0,  TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x33, 0, 0,  0,  TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x34, BatOT_Value, -40,  25,  TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x35, ConfigData.sTempComp, ConfigData.sBatUV_cv / 10,  0,  TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x36, ((SysData.RunSts & SysSts_Active) != 0), (ActionNow.StartMode != ActionStartRemo),  ((SysData.RunSts & SysSts_Queal) != 0),  TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x37, (drvBSP_CtrlIO_Sts(bspCtrlIO_CHGBat) != 0), (drvBSP_CtrlIO_Sts(bspCtrlIO_OutBat) != 0),  (drvBSP_CtrlIO_Sts(bspCtrlIO_OutBat) != 0) || (drvBSP_CtrlIO_Sts(bspCtrlIO_OutLin) != 0),  TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x38, 10, 0,  0,  TBuf);
				funAddCanFram(src, TBuf, 0);
			}
			break;
		case 0x40:
			if(cmd == 0)
			{
				funCanProReadReFram(0x40,ConfigData.sLineOV_cv / 10,  ConfigData.sLineUV_cv / 10,  0, TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x41, LinOutUv * 10, 0, DevOT_Value * 10,  TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x42, 0, ConfigData.sCellOV_mv / 100, ConfigData.sCellUV_mv / 100,   TBuf);
				funAddCanFram(src, TBuf, 1);
				
				funCanProReadReFram(0x43, 0, 0,  0,  TBuf);
				funAddCanFram(src, TBuf, 0);
			}
			break;
		case 0x49:
			if(cmd == 0)
			{		
				TBuf[0] = CanCMDRead;
				TBuf[1] = 0x49; 
				TBuf[2] = SysData.Now.Year;
				TBuf[3] = SysData.Now.Mon;
				TBuf[4] = SysData.Now.Day;
				TBuf[5] = SysData.Now.Hour;
				TBuf[6] = SysData.Now.Min;
				TBuf[7] = SysData.Now.Sec;				
				funAddCanFram(src, TBuf, 0);
			}
			break;
	}
}



ConfigureStruct CanConfigTempData;
uint8_t CanConfigReady = 0;
uint8_t CanConfigEnd = 0;
uint8_t CanConfigChange = 0;
uint32_t CanConfigTick;

void CanConfigSave(void)
{
	if((xTaskGetTickCount() - CanConfigTick) >= 5000)
	{
		CanConfigTick = xTaskGetTickCount();
		if(CanConfigEnd != 0)
		{
			if((CanConfigReady != 0) && (CanConfigChange != 0))
			{
				//
				bspSave(UserCfgAddr, (uint8_t *)&CanConfigTempData, sizeof(ConfigureStruct));
				UserConfigInit();
			}
		}		
		CanConfigReady = 0;
		CanConfigEnd = 0;
		CanConfigChange = 0;
	}
}
void CanConfigCheckReady(void)
{
	if(CanConfigReady == 0)
	{
		CanConfigReady = 1;
		memcpy(&CanConfigTempData,(void *)&ConfigData,sizeof(ConfigureStruct));
	}
}
void funCanProWrite(uint8_t dst, uint8_t src, uint8_t *buf, uint8_t cnt)
{
	uint8_t TBuf[8];
	uint16_t cmd;
	int16_t sData[3];
	float ftemp;
	if(buf[0] != CanCMDWrite)
	{return ; }
	//if (dst != SysData.Addr)	//�㲥��ַ��Ӧ�𣬱��뱾����ַ
	//{return ; }
	cmd = buf[3] | (buf[2] << 8);
	switch(buf[1])
	{
		case 0x49:	//ʱ������
			SysData.Now.Year = buf[2];
			SysData.Now.Mon = buf[3];
			SysData.Now.Day = buf[4];
			SysData.Now.Hour = buf[5];
			SysData.Now.Min = buf[6];
			SysData.Now.Sec = buf[7];
			bspSetDateTime(&SysData.Now);
			if(dst == SysData.Addr)
			{
				funAddCanFram(src, buf, 0);
			}
			break;
		case 0x62:
			if(cmd == 0)	//ֹͣ����
			{
				ActiveEnd(ActionEndRemo);
				if(dst == SysData.Addr)
				{
					funAddCanFram(src, buf, 0);
				}
			}
			else if(cmd == 1)	//����
			{
				ActiveStart(ActionStartRemo) ;
				if(dst == SysData.Addr)
				{
					funAddCanFram(src, buf, 0);
				}
			}
			break;
		case 0x64:
			if(cmd == 0)
			{
				funToFloat();
				if(dst == SysData.Addr)
				{
					funAddCanFram(src, buf, 0);
				}
			}
			else if(cmd == 1)	//����
			{
				funToEquel();
				if(dst == SysData.Addr)
				{
					funAddCanFram(src, buf, 0);
				}
			}
			break;
		case 0x67:
			if(cmd == 0)
			{		
				SysData.RunSts |= SysSts_ON;
				if(dst == SysData.Addr)
				{
					funAddCanFram(src, buf, 0);
				}
			}
			else if(cmd == 1)
			{		
				SysData.RunSts &= ~SysSts_ON;
				if(dst == SysData.Addr)
				{
					funAddCanFram(src, buf, 0);
				}
			}
			break;
		case 0x51:
			if((cmd >= 25) && (cmd <= 200) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sRatioAH != cmd)
				{
					CanConfigTempData.sRatioAH = cmd;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
		case 0x52:
			if((cmd >= 200) && (cmd <= 300) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sBatFloatVolt != (cmd * 10))
				{
					CanConfigTempData.sBatFloatVolt = cmd * 10;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
		case 0x53:
			if((cmd >= 200) && (cmd <= 300) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sBatEqualVolt != (cmd * 10))
				{
					CanConfigTempData.sBatEqualVolt = cmd * 10;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
		case 0x55:
			if((cmd <= 10) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sBatEqualStartCurr != (cmd * CanConfigTempData.sRatioAH))
				{
					CanConfigTempData.sBatEqualStartCurr = cmd * CanConfigTempData.sRatioAH;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
		case 0x56:
			if((cmd <= 10) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sBatEqualStopCurr != (cmd * CanConfigTempData.sRatioAH))
				{
					CanConfigTempData.sBatEqualStopCurr = cmd * CanConfigTempData.sRatioAH;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
		case 0x5F:
			if((cmd <= 50) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sTempComp != cmd )
				{
					CanConfigTempData.sTempComp = cmd;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
		case 0x5A:
			if((cmd <= 30) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sBatEqualTimLim != cmd )
				{
					CanConfigTempData.sBatEqualTimLim = cmd;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
		case 0x69:
			if((cmd <= 30) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sBatActTimLim != cmd )
				{
					CanConfigTempData.sBatActTimLim = cmd;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
		case 0x71:
			if((cmd >= 100) && (cmd <= 150) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sCellOV_mv != (cmd * 100) )
				{
					CanConfigTempData.sCellOV_mv = cmd * 100;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
		case 0x72:
			if((cmd >= 100) && (cmd <= 150) )
			{
				CanConfigCheckReady();
				if(CanConfigTempData.sCellUV_mv != (cmd * 100) )
				{
					CanConfigTempData.sCellUV_mv = cmd * 100;
					CanConfigChange = 1;
				}
			}
			if(cnt == 0)
			{
				CanConfigEnd = 1;
			}
			CanConfigTick = xTaskGetTickCount();
			break;
	}
}

//50	��ع�����ʽ	1	0-�Զ�  1-�ֶ�   Ĭ��Ϊ�Զ�
//51	��ر������	1	50-200Ah         Ĭ��Ϊ100Ah
//52	��ظ����ѹ	10	10-15V           Ĭ��Ϊ13.4V
//53	��ؾ����ѹ	10	10-15V           Ĭ��Ϊ14.1V
//54	��س������	100	0.05-0.20 C      Ĭ��Ϊ0.1 C
//55	����ת�������	100	0.01-0.10C       Ĭ��Ϊ0.08C
//56	����ת�������	100	0.01-0.10C       Ĭ��Ϊ0.02C
//57	β�������ʱ��	1	0-5H             Ĭ��Ϊ3H
//58	��ʱ���书��	1	0-���� 1-�ر�    Ĭ��Ϊ����
//59	��ʱ��������	1	30-180��         Ĭ��Ϊ90��
//5A	�����ʱ��	1	1-30H            Ĭ��Ϊ18H
//5B	�¶Ȳ�������	1	0-����  1-�ر�   Ĭ��Ϊ����
//	
//5C	��ع��µ�	1	20-80��          Ĭ��Ϊ40��
//5D	���Ƿ�µ�	1	-40-10��         Ĭ��Ϊ-10��
//5E	�²����ĵ�	1	10-40��          Ĭ��Ϊ25��
//5F	�²�ϵ��	1	0-50mV/��       Ĭ��Ϊ10mV/��
//60	����ŵ���ֹ��ѹ	10	10-50V           Ĭ��Ϊ10.8V
//61	���ǿ�Ʒŵ����	1	0-�ر� 1-����    Ĭ��Ϊ�ر�

//62	���ݿ���	1	0-ֹͣ���� 1-��������  Ĭ��Ϊֹͣ
//63	����Զ������	1	0-Զ�� 1-����    Ĭ��ΪԶ��
//64	�������л�	1	0-���� 1-����    Ĭ��Ϊ����

//65	��س�����	1	0-���� 1-�ر�    Ĭ��Ϊ����
//66	��طŵ����	1	0-���� 1-�ر�    Ĭ��Ϊ����
//67	ģ���������	1	0-���� 1-�ر�    Ĭ��Ϊ����

//68	��������	100	0.1C-0.5C        Ĭ��0.1C
//69	����ʱ��	1	0-20H            Ĭ��13H

//6A	���������ѹ�澯ֵ	10	��Χ250-290V,Ĭ��280
//6B	��������Ƿѹ�澯ֵ	10	��Χ160-220V,Ĭ��176
//6C	ģ�������ѹ�澯ֵ	10	��Χ180-242V�� Ĭ��242
//6D	ģ�����Ƿѹ�澯ֵ	10	��Χ180-242V�� Ĭ��200
//6E	ģ������澯ֵ	10	��Χ0-99A��  Ĭ��30
//6F	ģ����¸澯ֵ	10	��Χ40-70�棬 Ĭ��Ϊ70��
//70	ģ����¸澯ֵ	10	��Χ-10-20�棬 Ĭ��Ϊ-10��
//71	��ع�ѹ�澯ֵ	10	��Χ10-15V�� Ĭ��15
//72	���Ƿѹ�澯ֵ	10	��Χ10-15V�� Ĭ��11
//73	��ع����澯ֵ	10	��Χ0-22A��  Ĭ��22

void funCanProFa(uint8_t dst, uint8_t src, uint8_t *buf)
{
  if((src > CurrAveDevMax) || (src == 0) || (src == 0xFF))
  {
    return ;
  }	
  CurrAveDat[src - 1].Mode = buf[2];
	switch(buf[3])
	{
		case 1:
			CurrAveDat[src - 1].ActMode =	1;
			CurrAveDat[src - 1].ResMode =	0;
			break;
		case 2:
			CurrAveDat[src - 1].ActMode =	0;
			CurrAveDat[src - 1].ResMode =	1;
			break;
		default:
			CurrAveDat[src - 1].ActMode =	0;
			CurrAveDat[src - 1].ResMode =	0;
			break;
	}
  CurrAveDat[src - 1].Curr = buf[5] | (buf[4] << 8);
  CurrAveDat[src - 1].Pwm= buf[7] | (buf[6] << 8);
  CurrAveDat[src - 1].time = xTaskGetTickCount();
}

CanRxMsg RxMessage;
void CAN1_RX0_IRQHandler(void)
{
	uint8_t srcAddr,	dstAddr;
	uint8_t ptp;
	uint8_t cnt;
  CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);
	
	if((RxMessage.IDE == CAN_ID_EXT)
		&&  (RxMessage.RTR == CAN_RTR_DATA)
		&&  (RxMessage.DLC == 8))
	{
		srcAddr = (RxMessage.ExtId >> 3 ) & 0xFF;
		dstAddr = (RxMessage.ExtId >> 11 ) & 0xFF;
		ptp = (RxMessage.ExtId >> 19 ) & 0x01;
		cnt = (RxMessage.ExtId >> 2 ) & 0x01;
		if(((ptp != 0) && (dstAddr == SysData.Addr))	//PTP��ַ
			|| ((ptp == 0) && (dstAddr == 0xFF)))	//�㲥��ַ
		{
			switch(RxMessage.Data[0])
			{
				case CanCMDRead:
					funCanProRead(dstAddr, srcAddr, RxMessage.Data);
					break;
				case CanCMDWrite:
					funCanProWrite(dstAddr, srcAddr, RxMessage.Data, cnt);
					break;
				case CanCMDFaDef:
					funCanProFa(dstAddr, srcAddr, RxMessage.Data);
					break;
			}
		}
	}
}

