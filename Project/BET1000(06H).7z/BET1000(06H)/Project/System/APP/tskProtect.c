/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include "sys.h"
#include "configure.h"
#include "bspBIMS.h"
#include "protect.h"


#define Cfg_EnvOTAlarm	48	//��������
#define Cfg_EnvUTAlarm	49	//����Ƿ��

#define Cfg_ChgOCAlarm	50	//������
#define Cfg_DsgOCAlarm	51	//�ŵ����
#define Cfg_PortOTAlarm	55	//���߶��ӹ��¸澯


void AlarmAdd(uint8_t AlarmType, uint8_t cell, int16_t reaValue);
void AlarmDel(uint8_t AlarmType, uint8_t cell, int16_t reaValue);


//ACT_RPT_STRUCT ActRptList[ActRptMax]	__attribute__ ((aligned (4)));
//ACT_RPT_STRUCT ActRptList[ActRptMax]	__attribute__ ((aligned (4)));
/*********************************************************
����:0�澯�ޱ仯�� 1���¸澯�� -1���澯�ָ�
*********************************************************/
int8_t funAlarm(int in_t, int ret_t,	//������������������
							int16_t *AlarmVaue, int16_t AlarmType,
							uint32_t *InTick, uint32_t InTime, uint32_t ReTime)
{
	int16_t AlarmBit;
	if(AlarmType > 0)
	{
		AlarmBit = 1 << (AlarmType - 1);
	}
	else 
	{
		return 0;
	}
	if((*AlarmVaue & AlarmBit)	== 0)	//�޸澯
	{
		if(in_t > 0)	//�ﵽ��ֵ
		{
			if((xTaskGetTickCount() - *InTick) > InTime)	//ʱ�䵽
			{
				*InTick = xTaskGetTickCount();
				*AlarmVaue |= AlarmBit;
				return 1;	//�����澯
			}
		}
		else
		{
			*InTick = xTaskGetTickCount();
		}
	}
	else	//�и澯
	{
		if(ret_t > 0)	//�ﵽ��ֵ
		{
			if((xTaskGetTickCount() - *InTick) > ReTime)	//ʱ�䵽
			{
				*InTick = xTaskGetTickCount();
				*AlarmVaue &= ~AlarmBit;
				return -1;	//ȡ���澯
			}
		}
		else
		{
			*InTick = xTaskGetTickCount();
		}
	}
	return 0;
}


/*********************************************************
����:0�澯�ޱ仯�� 1���¸澯�� -1���澯�ָ�
*********************************************************/
int8_t funAlarmSubTotle(int16_t *AlarmVaue, int16_t AlarmType,	//�ܱ���
							int16_t *AlarmSubVaue, int16_t AlarmSubType)		//�ӱ���
{
	int16_t AlarmBit, AlarmSubBit;
	
	if(AlarmType > 0)
	{
		AlarmBit = 1 << (AlarmType - 1);
	}
	else 
	{
		return 0;
	}
	
	if(AlarmSubType > 0)
	{
		AlarmSubBit = 1 << (AlarmSubType - 1);
	}
	else 
	{
		return 0;
	}	

	if((*AlarmVaue & AlarmBit)	== 0)	//�޸澯
	{
			//�Ƿ��¸澯
		if((*AlarmSubVaue & AlarmSubBit)	!= 0)
		{
			*AlarmVaue |= AlarmBit;
			return 1;	//�����澯
		}
	}
	else	//�и澯
	{
		if((*AlarmSubVaue & AlarmSubBit)	== 0)
		{
			*AlarmVaue &= ~AlarmBit;
			return -1;	//ȡ���澯
		}
	}
	return 0;
}


void funAlarmSubTotleAll(int16_t AlarmSubAll)		
{
	//���Ƿѹ
	switch(funAlarmSubTotle(&SysData.Alarm, AlarmCellUV,
							&AlarmSubAll, AlarmSubUV)   )
	{
		case 1:
			AlarmAdd(AlarmCellUV , 0, 0);
			break;
		case -1:
			AlarmDel(AlarmCellUV , 0, 0);
			break;
	}
	//��ع�ѹ
	switch(funAlarmSubTotle(&SysData.Alarm, AlarmCellOV,
							&AlarmSubAll, AlarmSubOV)   )
	{
		case 1:
			AlarmAdd(AlarmCellOV , 0, 0);
			break;
		case -1:
			AlarmDel(AlarmCellOV , 0, 0);
			break;
	}
	//��ص���
	switch(funAlarmSubTotle(&SysData.Alarm, AlarmCellUT,
							&AlarmSubAll, AlarmSubUT)   )
	{
		case 1:
			AlarmAdd(AlarmCellUT , 0, 0);
			break;
		case -1:
			AlarmDel(AlarmCellUT , 0, 0);
			break;
	}
	//��ظ���
	switch(funAlarmSubTotle(&SysData.Alarm, AlarmCellOT,
							&AlarmSubAll, AlarmSubOT)   )
	{
		case 1:
			AlarmAdd(AlarmCellOT , 0, 0);
			break;
		case -1:
			AlarmDel(AlarmCellOT , 0, 0);
			break;
	}
	
	//����Խ��
	switch(funAlarmSubTotle(&SysData.Alarm, AlarmRes,
							&AlarmSubAll, AlarmSubOR)   )
	{
		case 1:
			AlarmAdd(AlarmRes , 0, 0);
			break;
		case -1:
			AlarmDel(AlarmRes , 0, 0);
			break;
	}
	//����Խ��
	switch(funAlarmSubTotle(&SysData.Alarm, AlarmSoh,
							&AlarmSubAll, AlarmSubOH)   )
	{
		case 1:
			AlarmAdd(AlarmSoh , 0, 0);
			break;
		case -1:
			AlarmDel(AlarmSoh , 0, 0);
			break;
	}
	//���߶��ӹ��ȹ���
	switch(funAlarmSubTotle(&SysData.Alarm, AlarmSubAP,
							&AlarmSubAll, AlarmSubAP)   )
	{
		case 1:
			AlarmAdd(AlarmPortOT , 0, 0);
			break;
		case -1:
			AlarmDel(AlarmPortOT , 0, 0);
			break;
	}
	//ͨ�Ÿ澯
	switch(funAlarmSubTotle(&SysData.Alarm, AlarmDevErr,
							&AlarmSubAll, AlarmSubCOM)   )
	{
		case 1:
			AlarmAdd(AlarmDevErr , 0, 0);
			break;
		case -1:
			AlarmDel(AlarmDevErr , 0, 0);
			break;
	}
}



extern uint8_t ComFlag[DevSubMax];
uint8_t ComErrTimes[DevSubMax];
uint32_t ComErrTick[DevSubMax];
void funAlarmCom(void)
{
	uint8_t i, num;
	num = DevSubMax < SysData.ConfigData[Cfg_SubDevNum]? 
				DevSubMax : SysData.ConfigData[Cfg_SubDevNum];
	for(i = 0; i < num; i++)
	{
		if((ComFlag[i] & 0x0F) == 0X0F)
		{	//ͨ������
			ComErrTick[i] = xTaskGetTickCount();
			ComFlag[i] = 0;
			ComErrTimes[i] = 0;
		}
		else if((xTaskGetTickCount() - ComErrTick[i]) >= 5000)
		{	//�쳣1��
			ComErrTimes[i] ++;
			if(ComErrTimes[i] >= 5) 
			{//���쳣
				ComErrTimes[i] = 5;
			}
			ComErrTick[i] = xTaskGetTickCount();
			ComFlag[i] = 0;
		}
		
		if(SysData.Sub[i].Alarm & AlarmSubCOMBit)	//�б���
		{
			if((ComErrTimes[i] < 5) && ((SysData.Sub[i].SubAlarm & Alarm_SubComErr) == 0))
			{
			}
		}
		else	//�ޱ���
		{
			if((ComErrTimes[i] >= 5) || (SysData.Sub[i].SubAlarm & Alarm_SubComErr))
			{//ͨ���쳣
			}
		}		
		
		
	}
	

	
	//�������
	for(i = num; i < DevSubMax; i++)
	{
		SysData.Sub[i].Alarm &= ~0x80;
	}
	//���Ӳɼ�ģ��ͨ�ű���Ӱ���ܱ���
	num = 0;
	for(i = 0; i < DevSubMax; i++)
	{
		if(SysData.Sub[i].Alarm & 0x80)
		{
			num = 1;
		}
	}	
	if(SysData.Alarm & AlarmDevErr)	//�и澯
	{
		if(num == 0)
		{
			AlarmDel(AlarmDevErr , 0, 0);
		}
	}
	else	//�޸澯
	{
		if(num != 0)
		{
			AlarmAdd(AlarmDevErr , 0, 0);
		}
	}
	//
}














//��ѹ��ѹ��Ƿѹ
uint32_t BatAlarmUVTick, BatAlarmOVTick;
void funAlarmBatVolt(void)
{
	//Ƿѹ
	switch (funAlarm((SysData.sBatVolt < SysData.ConfigData[Cfg_BatUVAlarm]),						//����������
									((SysData.sBatVolt - 200) > SysData.ConfigData[Cfg_BatUVAlarm]),	//��������
									&SysData.Alarm, AlarmBatUV,		//�澯ֵ��λ
									&BatAlarmUVTick,5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmBatUV , 0, SysData.sBatVolt);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmBatUV , 0, SysData.sBatVolt);
			break;
		}	
	//��ѹ
	switch (funAlarm((SysData.sBatVolt > SysData.ConfigData[Cfg_BatOVAlarm]),						//����������
									((SysData.sBatVolt + 200) < SysData.ConfigData[Cfg_BatOVAlarm]),	//��������
									&SysData.Alarm, AlarmBatOV,		//�澯ֵ��λ
									&BatAlarmOVTick,5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmBatOV , 0, SysData.sBatVolt);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmBatOV , 0, SysData.sBatVolt);
			break;
		}	

}

//����ع�ѹ��Ƿѹ
uint32_t CellAlarmUVTick[DevSubMax];	//, CellProtectUVTick[DevSubMax];
uint32_t CellAlarmOVTick[DevSubMax];	//, CellProtectOVTick[DevSubMax];
void funAlarmCellVolt(int16_t cell)
{
	//Ƿѹ
	switch (funAlarm((SysData.Sub[cell].sVoltmV < SysData.ConfigData[Cfg_CellUVAlarm]),						//����������
									((SysData.Sub[cell].sVoltmV - 500) > SysData.ConfigData[Cfg_CellUVAlarm]),	//��������
									//&SysData.CellAlarm[cell] , AlarmCellUV,		//�澯ֵ��λ
										&SysData.Sub[cell].Alarm,  AlarmSubUV,
									&CellAlarmUVTick[cell],5000, 20000))
		{
		case 1:	//�澯
//			SysData.Alarm |= 0x10;
//			SysData.Sub[cell].Alarm |= 0x01;
			AlarmAdd(AlarmCellUV , cell + 1, SysData.Sub[cell].sVoltmV);
			break;
		case -1:	//�澯�ָ�
			//SysData.Alarm &= ~0x10;
			//SysData.Sub[cell].Alarm &= ~0x01;
			//���лָ��Żָ�
			AlarmDel(AlarmCellUV , cell + 1, SysData.Sub[cell].sVoltmV);
			break;
		}	

	
	//��ѹ
	switch (funAlarm((SysData.Sub[cell].sVoltmV > SysData.ConfigData[Cfg_CellOVAlarm]),						//����������
									((SysData.Sub[cell].sVoltmV + 500) < SysData.ConfigData[Cfg_CellOVAlarm]),	//��������
									//&SysData.CellAlarm[cell] , AlarmCellOV,		//�澯ֵ��λ
									&SysData.Sub[cell].Alarm , AlarmSubOV,		//�澯ֵ��λ
									&CellAlarmOVTick[cell],5000, 20000))
		{
		case 1:	//�澯
			SysData.Alarm |= 0x20;
			//SysData.Sub[cell].Alarm |= 0x02;
			AlarmAdd(AlarmCellOV , cell + 1, SysData.Sub[cell].sVoltmV);
			break;
		case -1:	//�澯�ָ�
			//SysData.Alarm &= ~0x20;
			//SysData.Sub[cell].Alarm &= ~0x02;
		
			AlarmDel(AlarmCellOV , cell + 1, SysData.Sub[cell].sVoltmV);
			break;
		}	

}


//����ع��¡�Ƿ��
uint32_t CellAlarmUTTick[DevSubMax];	//, CellProtectUTTick[DevSubMax];
uint32_t CellAlarmOTTick[DevSubMax];	//, CellProtectOTTick[DevSubMax];
void funAlarmCellTemp(int16_t cell)
{
	int16_t tTemp;
	//����
	tTemp = SysData.Sub[cell].sTemp[0] < SysData.Sub[cell].sTemp[1] ?
					SysData.Sub[cell].sTemp[0] : SysData.Sub[cell].sTemp[1];
	switch (funAlarm((tTemp < SysData.ConfigData[Cfg_CellUTAlarm]),						//����������
									((tTemp- 50) > SysData.ConfigData[Cfg_CellUTAlarm]),	//��������
//									&SysData.CellAlarm[cell] , AlarmCellUT,		//�澯ֵ��λ
									&SysData.Sub[cell].Alarm , AlarmSubUT,		//�澯ֵ��λ
									&CellAlarmUTTick[cell],5000, 20000))
		{
		case 1:	//�澯
			SysData.Alarm |= 0x40;
			SysData.Sub[cell].Alarm |= 0x04;
			AlarmAdd(AlarmCellUT , cell + 1, tTemp);
			break;
		case -1:	//�澯�ָ�
			SysData.Alarm &= ~0x40;
			SysData.Sub[cell].Alarm &= ~0x04;
			AlarmDel(AlarmCellUT , cell + 1, tTemp);
			break;
		}	

	//����
	tTemp = SysData.Sub[cell].sTemp[0] > SysData.Sub[cell].sTemp[1] ?
					SysData.Sub[cell].sTemp[0] : SysData.Sub[cell].sTemp[1];
	switch (funAlarm((tTemp > SysData.ConfigData[Cfg_CellOTAlarm]),						//����������
									((tTemp + 50) < SysData.ConfigData[Cfg_CellOTAlarm]),	//��������
//									&SysData.CellAlarm[cell] , AlarmCellOT,		//�澯ֵ��λ
									&SysData.Sub[cell].Alarm , AlarmSubOT,		//�澯ֵ��λ
									&CellAlarmOTTick[cell],5000, 20000))
		{
		case 1:	//�澯
//			SysData.Alarm |= 0x80;
//			SysData.Sub[cell].Alarm |= 0x08;
			AlarmAdd(AlarmCellOT , cell + 1, tTemp);
			break;
		case -1:	//�澯�ָ�
//			SysData.Alarm &= ~0x80;
//			SysData.Sub[cell].Alarm &= ~0x08;
			AlarmDel(AlarmCellOT , cell + 1, tTemp);
			break;
		}		
}


uint32_t CellAlarmPortOTTick[DevSubMax];	//, CellProtectOTTick[DevSubMax];
void funAlarmCellPortOT(int16_t cell)
{
	int16_t tTemp;
	//����
	tTemp = SysData.Sub[cell].sTemp[2] > SysData.Sub[cell].sTemp[3] ?
					SysData.Sub[cell].sTemp[2] : SysData.Sub[cell].sTemp[3];
	switch (funAlarm((tTemp > SysData.ConfigData[Cfg_PortOTAlarm]),						//����������
									((tTemp + 100) < SysData.ConfigData[Cfg_PortOTAlarm]),	//��������
									&SysData.Sub[cell].Alarm , AlarmSubAP,		//�澯ֵ��λ
									&CellAlarmPortOTTick[cell],5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmPortOT , cell + 1, tTemp);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmPortOT , cell + 1, tTemp);
			break;
		}		
}




void funAlarmCellRes(int16_t cell)
{
	//����
	//if((SysData.CellAlarm[cell] & AlarmRes) == 0)
	if((SysData.Sub[cell].Alarm & AlarmSubORBit) == 0)
	{
		if(SysData.sLastResValue[cell] > SysData.ConfigData[Cfg_ResOVAlarm])
		{
			//SysData.CellAlarm[cell] |= AlarmRes;
//			SysData.Alarm |= 0x1000;
			SysData.Sub[cell].Alarm |= AlarmSubORBit;
			AlarmAdd(AlarmRes , cell + 1, SysData.sLastResValue[cell]);
		}
	}
	else
	{
		if(SysData.sLastResValue[cell] < SysData.ConfigData[Cfg_ResOVAlarm])
		{
			//SysData.CellAlarm[cell] &= AlarmRes;
//			SysData.Alarm &= ~0x1000;
			SysData.Sub[cell].Alarm &= ~AlarmSubORBit;
			AlarmDel(AlarmRes , cell + 1, SysData.sLastResValue[cell]);
		}
	}
}

void funAlarmCellSoh(int16_t cell)
{//���޲������ã�����û�д˱���
	//if((SysData.CellAlarm[cell] & AlarmSoh) == 0)
	if((SysData.Sub[cell].Alarm & AlarmSubOHBit) == 0)
	{
		if(SysData.sLastActValue[cell] > SysData.ConfigData[Cfg_SohOVAlarm])	//SOH ����
		{
			//SysData.CellAlarm[cell] |= AlarmSoh;
  		//SysData.Alarm |= 0x2000;
			SysData.Sub[cell].Alarm |= AlarmSubOHBit;
			AlarmAdd(AlarmSoh , cell + 1, SysData.sLastResValue[cell]);
		}
	}
	else
	{
		if(SysData.sLastActValue[cell] < SysData.ConfigData[Cfg_SohOVAlarm])	//SOH
		{
			//SysData.CellAlarm[cell] &= AlarmSoh;
  		//SysData.Alarm &= ~0x2000;
			SysData.Sub[cell].Alarm &= ~AlarmSubOHBit;
			AlarmDel(AlarmSoh , cell + 1, SysData.sLastResValue[cell]);
		}
	}
}



uint32_t AlarmACUVTick, AlarmACOVTick;
void funAlarmAC(void)
{
	//Ƿѹ����ѹ
	switch (funAlarm((SysData.sLineVolt < SysData.ConfigData[Cfg_LineUVAlarm]) || (SysData.sLineVolt > SysData.ConfigData[Cfg_LineOVAlarm]) ,						//����������
									((SysData.sLineVolt - 500) > SysData.ConfigData[Cfg_LineUVAlarm]) && ((SysData.sLineVolt + 500) < SysData.ConfigData[Cfg_LineOVAlarm]),	//��������
									&SysData.Alarm , AlarmLineErr,		//�澯ֵ��λ
									&AlarmACUVTick,5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmLineErr, 0, SysData.sLineVolt);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmLineErr, 0, SysData.sLineVolt);
			break;
		}	
	
//	//��ѹ
//	switch (funAlarm((SysData.LineVolt < SysData.ConfigData[Cfg_LineUVAlarm]) ,						//����������
//									((SysData.LineVolt - 500) > SysData.ConfigData[Cfg_LineUVAlarm]) ,	//��������
//									&SysData.Alarm , AlarmLineErr,		//�澯ֵ��λ
//									&AlarmACUVTick,5000, 20000))
//		{
//		case 1:	//�澯
//			break;
//		case -1:	//�澯�ָ�
//			break;
//		}	
//	//��ѹ
//	switch (funAlarm((SysData.LineVolt < SysData.ConfigData[Cfg_LineUVAlarm]) || (SysData.LineVolt > SysData.ConfigData[Cfg_LineOVAlarm]) ,						//����������
//									((SysData.LineVolt - 500) > SysData.ConfigData[Cfg_LineUVAlarm]) && ((SysData.LineVolt + 500) < SysData.ConfigData[Cfg_LineOVAlarm]),	//��������
//									&SysData.Alarm , AlarmLineErr,		//�澯ֵ��λ
//									&AlarmACUVTick,5000, 20000))
//		{
//		case 1:	//�澯
//			break;
//		case -1:	//�澯�ָ�
//			break;
//		}	

}



//��ֹ�ѹ
uint32_t AlarmDefTick;
void funAlarmDefVolt(void)
{
	switch (funAlarm((SysData.sDefVoltmV > SysData.ConfigData[Cfg_DefOVAlarm]),						//����������
									((SysData.sDefVoltmV + 500) < SysData.ConfigData[Cfg_DefOVAlarm]),	//��������
									&SysData.Alarm , AlarmCellDef,		//�澯ֵ��λ
									&AlarmDefTick,5000, 20000))
		{
		case 1:	//�澯
			AlarmAdd(AlarmCellDef, 0, SysData.sDefVoltmV);
			break;
		case -1:	//�澯�ָ�
			AlarmDel(AlarmCellDef, 0, SysData.sDefVoltmV);
			break;
		}	
}


//�������¡�Ƿ��
uint32_t AlarmEvnOTTick,AlarmEvnUTTick;
void funAlarmEnvTemp(void)
{
	//����
	switch (funAlarm((SysData.sTemp[0] < SysData.ConfigData[Cfg_EnvUTAlarm]),						//����������
									((SysData.sTemp[0]- 50) > SysData.ConfigData[Cfg_EnvUTAlarm]),	//��������
									&SysData.Alarm , AlarmEnvUT,		//�澯ֵ��λ
									&AlarmEvnUTTick,5000, 20000))
		{
		case 1:	//�澯
//			SysData.Alarm |= AlarmEnvUT;
			AlarmAdd(AlarmEnvUT , 0, SysData.sTemp[0]);
			break;
		case -1:	//�澯�ָ�
//			SysData.Alarm &= ~AlarmEnvUT;
			AlarmDel(AlarmEnvUT , 0, SysData.sTemp[0]);
			break;
		}	

	//����
	switch (funAlarm((SysData.sTemp[0] > SysData.ConfigData[Cfg_EnvOTAlarm]),						//����������
									((SysData.sTemp[0] + 50) < SysData.ConfigData[Cfg_EnvOTAlarm]),	//��������
									&SysData.Alarm , AlarmEnvOT,		//�澯ֵ��λ
									&AlarmEvnOTTick,5000, 20000))
		{
		case 1:	//�澯
//			SysData.Alarm |= AlarmEnvOT;
			AlarmAdd(AlarmEnvOT , 0, SysData.sTemp[0]);
			break;
		case -1:	//�澯�ָ�
//			SysData.Alarm &= ~AlarmEnvOT;
			AlarmDel(AlarmEnvOT , 0, SysData.sTemp[0]);
			break;
		}	
}

////���߶��ӹ���
//uint32_t CellAlarmPortTempTick[DevSubMax];
//void funAlarmCellPortTemp(int16_t cell)
//{
//	int16_t tTemp;
//	tTemp = SysData.Sub[cell].sTemp[2] > SysData.Sub[cell].sTemp[3] ?
//					SysData.Sub[cell].sTemp[2] : SysData.Sub[cell].sTemp[3];
//	switch (funAlarm((tTemp > SysData.ConfigData[Cfg_PortOTAlarm]),						//����������
//									((tTemp + 50) < SysData.ConfigData[Cfg_PortOTAlarm]),	//��������
//									&SysData.Alarm , AlarmPortOT,		//�澯ֵ��λ
//									&CellAlarmPortTempTick[cell],5000, 20000))
//		{
//		case 1:	//�澯
////			SysData.Alarm |= AlarmPortOT;
//			AlarmAdd(AlarmPortOT , cell + 1, tTemp);
//			break;
//		case -1:	//�澯�ָ�
////			SysData.Alarm &= ~AlarmPortOT;
//			AlarmDel(AlarmPortOT , cell + 1, tTemp);
//			break;
//		}		
//}


//������
uint32_t CellAlarmChgTick[DevSubMax];
void funAlarmCellChg(int16_t cell)
{
//		if(((SysData.RunSts & RunSts_Act) != 0)
//		  && ((SysData.Act_Step == 5) || (SysData.Act_Step == 10)))
//	{
	switch (funAlarm((SysData.Sub[cell].sCurrcA > SysData.ConfigData[Cfg_ChgOCAlarm]),						//����������
									((SysData.Sub[cell].sCurrcA + 50) < SysData.ConfigData[Cfg_ChgOCAlarm]),	//��������
									&SysData.Alarm , AlarmChgOC,		//�澯ֵ��λ
									&CellAlarmChgTick[cell],5000, 20000))
		{
		case 1:	//�澯
//			SysData.Alarm |= AlarmChgOC;
			AlarmAdd(AlarmChgOC , cell + 1, SysData.Sub[cell].sCurrcA);
			break;
		case -1:	//�澯�ָ�
//			SysData.Alarm &= ~AlarmChgOC;
			AlarmDel(AlarmChgOC , cell + 1, SysData.Sub[cell].sCurrcA);
			break;
		}		
//	}
}


//�ŵ����
uint32_t CellAlarmDisChgTick[DevSubMax];
void funAlarmCellDisChg(int16_t cell)
{
//	if(((SysData.RunSts & RunSts_Act) != 0)
//		  && (SysData.Act_Step >= 7) 
//	    && (SysData.Act_Step <= 9))
//	{
	switch (funAlarm((-SysData.Sub[cell].sCurrcA> SysData.ConfigData[Cfg_DsgOCAlarm]),						//����������
									((-SysData.Sub[cell].sCurrcA + 50) < SysData.ConfigData[Cfg_DsgOCAlarm]),	//��������
									&SysData.Alarm , AlarmDsgOC,		//�澯ֵ��λ
									&CellAlarmDisChgTick[cell],5000, 20000))
		{
		case 1:	//�澯
//			SysData.Alarm |= AlarmDsgOC;
			AlarmAdd(AlarmDsgOC , cell + 1, -SysData.Sub[cell].sCurrcA);
			break;
		case -1:	//�澯�ָ�
//			SysData.Alarm &= ~AlarmDsgOC;
			AlarmDel(AlarmDsgOC , cell + 1, -SysData.Sub[cell].sCurrcA);
			break;
		}		
//	}
}






