/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"

#include "sys.h"
#include "bsp.h"
#include "configure.h"
#include "bspBIMS.h"
#include "protect.h"
#include <string.h>

#define FlagDataStart	0x00
#define FlagDataList	0x55
#define FlagDataStop	0xFA

extern unsigned short Modbus_CRC16(unsigned char *updata, unsigned short len);
extern unsigned short Modbus_Send(unsigned char *updata, unsigned short len);

#define SPIF_CMD_WriteEN	0x06
#define SPIF_CMD_WriteDIS	0x04
#define SPIF_CMD_DEVID		0x90
#define SPIF_CMD_ReadData	0x03
#define SPIF_CMD_FastRead	0x0B
#define SPIF_CMD_PageProg	0x02
#define SPIF_CMD_SectorErase	0x20
#define SPIF_CMD_BloackErase1	0x52	//32K
#define SPIF_CMD_BloackErase2	0xD8	//64K
#define SPIF_CMD_ChipErase1	0xc7	//
#define SPIF_CMD_ChipErase2	0x60	//

#define SPIF_CMD_ReadSts1		0x05
#define SPIF_CMD_ReadSts2		0x35
#define SPIF_CMD_ReadSts3		0x15

#define SPIF_CMD_ResetEn		0x66
#define SPIF_CMD_ResetDEV		0x99


#define FDataNumMax	12

#define PageSize 256
#define PageInSectorNum	 16	
#define PageInBlockrNum	 256	
#define SectorSize	4096	//4K
#define BlockNum	256
#define SectorNum	(BlockNum * 16)	//4K
#define BlockSize	(SectorSize * 16)	//64K


#define PageStart	0
#define PageEnd		1
#define PageInfo	2


#define FDataNull	0	//��
#define FDataOK		1	//��������
#define FDataErr	2	//�����쳣

//16M = 256 * 64  BLOCK
//1 BLOCK = 16Setor
//1 Setor = 16page

//
/*******************************************
16 16Setor -> 255Block
1-> Setocr -> 1������� ->16BLOCK
Page 0��0~127�� -> Start	
Page 0��128~256�� -> End
Page 1() -> Cell 1--Start(32B)
Page 1() -> Cell 1--End(32B)
Page 1() -> Cell 1--T1(INFO + BLOCK)(32B)
Page 1() -> Cell 1--T2
Page 1() -> Cell 1--T3
Page 1() -> Cell 1--T4
��������

*******************************************/

#define DataSaveListMax	100
uint16_t DataListStart = 0, DataListEnd = 0;

typedef struct
{
	uint32_t Addr;
	uint8_t DataBuf[24];
}DataSaveStruct;	

DataSaveStruct DataSaveList[DataSaveListMax];


	

#define DataFlagStart 0x01
#define DataFlagStop	0x02


//FDataInfo_STRUCT FDataReadHead;

uint32_t FDataBlockValive[BlockNum];	//��¼��״̬
uint32_t FDataList[BlockNum];

uint8_t SPIF_TxBuf[264], SPIF_RxBuf[264];

void funSPIF_Init(void);
uint8_t funSPIF_ReadSts(void);
uint8_t funSPIF_WriteEn(uint8_t enable);
uint16_t funSPIF_EraseChip(void);
uint16_t funSPIF_EraseBlock(uint32_t addr);
uint16_t funSPIF_ReadData(uint32_t addr, uint8_t *buf, int32_t len);
uint16_t funSPIF_WriteData(uint32_t addr, uint8_t *buf, int32_t len);


void funFDataInit(void);
void funFdataRead(uint8_t src, int16_t Block, DataHeadStruct *head);


FDataInfo_STRUCT FDataHeadFram;
int32_t FDataFramCnt;


#define DataFramLcd	0
#define DataFramHMI	1
#define DataFramHost	2

//#define DataFramLen 1200
DataHeadStruct DataFramHead[3];
DataStruct DataFramDat[3][DataFramLen];	//��ȡ�����ݻ���    
int16_t DataReadPara[3][3];
int16_t DataReadAsk = 0;


#define FDataReq_Start	1
#define FDataReq_Data		2
#define FDataReq_Stop		4
#define FDataReq_Read		8

//uint8_t FDataReq = 0;
uint8_t	FDataNum	=	0;


uint8_t FDataStartFlag;
int32_t FDataCnt;	//���ݼ���
uint32_t FDataLastSerialNum = 0;

#define DataInfoMax	8
DataInfoStruct DataInfo[DataInfoMax + 1];	//���32���� 0��ʾ��ǰ������Ϣ����ʼ��ʱ��Ϊ��ʱ����ʼ����ɺ󣬱�ʾ���ڻ�����ݼ�¼

DataStruct DataReadBuf[16];	//16Byte * 16 = 256Byte

static uint8_t FlashClrFlag = 0;

void threadSPIF(void *pvParameters)
{
	uint8_t sts, i;
	uint8_t cellnum;
	int16_t ReadBlock = 0;
	
	drvFlashSPI_Init();
	funSPIF_Init();
	funFDataInit();
	
	//�������µļ�¼
	//funFDataReadData(1);
	for(i = 0; i < 3; i++)
	{
		DataReadPara[i][0] = 1;
		DataReadPara[i][1] = 1;
		DataReadPara[i][2] = 1;
		DataReadAsk |= 1 << i;
	}

	for(;;)
	{
		if(FlashClrFlag != 0)
		{
			FlashClrFlag = 0;
			funSPIF_EraseChip();
		}
		if(DataListStart != DataListEnd)	//��������Ҫ�洢
		{
			if((DataSaveList[DataListStart].Addr % BlockSize) == 0)	//��Ҫ�����
			{	
				sts = funSPIF_ReadSts();
				while((sts & 0x01) != 0)	//æ
				{
					sts = funSPIF_ReadSts();
				}
				funSPIF_EraseBlock(DataSaveList[DataListStart].Addr);	//�����
				//�ȴ��������
				sts = funSPIF_ReadSts();
				while((sts & 0x01) != 0)	//æ
				{
					sts = funSPIF_ReadSts();
				}
			}
			//�ȴ�FLASH����
			sts = funSPIF_ReadSts();
			while((sts & 0x01) != 0)	//æ
			{
				sts = funSPIF_ReadSts();
			}
			//д��Ϣ	
			funSPIF_WriteData(DataSaveList[DataListStart].Addr, DataSaveList[DataListStart].DataBuf, sizeof(DataStruct));

			DataListStart++;
			if(DataListStart >= DataSaveListMax)
			{
				DataListStart = 0;
			}			
		}
		//funFdataRead(DataFramLcd, ReadBlock);
		if(DataReadAsk != 0)
		{
			for(i = 0; i < 3; i++)
			{
				if((DataReadAsk & (1 << i)) == 0)
				{
					continue;
				}
				DataReadAsk &= ~(1 << i);
				if(DataReadPara[i][0] > SysData.FDataValiveNum )	//������¼����
				{
					memset(&DataFramHead[i], 0, sizeof(DataHeadStruct) );
					memset(DataFramDat[i], 0, sizeof(DataStruct) * DataFramLen);
					//DataStruct DataFramDat[3][DataFramLen]
					continue;
				}
				
				cellnum = DataReadPara[i][1] + DataInfo[ DataReadPara[i][0] ].CellStart - 1;
				//δ������¼����
				
				if((cellnum >= 1) 
					&&  (cellnum <= 40) 	//��ر���ڷ�Χ��
					&&  (DataReadPara[i][1] <= DataInfo[ DataReadPara[i][0] ].CellActNum) //�˵���ѻ
					)
				{	
					DataFramHead[i].TypeNum = 0;
					//�׶�����������2ѡ1
					DataFramHead[i].TypeNum = DataInfo[ DataReadPara[i][0] ]. DataCellStepNum[ cellnum - 1 ] ;		//��ؽ׶�����
					
//					if(DataInfo[ DataReadPara[i][0] ]. DataCellFlag[ cellnum - 1 ] & DataFlagStart)
//					{
//						DataFramHead[i].TypeNum = 1;
//					}
//					if(DataInfo[ DataReadPara[i][0] ]. DataCellFlag[ cellnum - 1 ] & ( DataFlagStart << 2) )
//					{
//						DataFramHead[i].TypeNum = 2;
//					}
//					if(DataInfo[ DataReadPara[i][0] ]. DataCellFlag[ cellnum - 1 ] & ( DataFlagStart << 4) )
//					{
//						DataFramHead[i].TypeNum = 3;
//					}
					if((DataReadPara[i][2] <= DataFramHead[i].TypeNum)
					&&  (DataReadPara[i][2] >= 1) 			)
					{
						funFdataRead(i, DataInfo[DataReadPara[i][0]].DataCelBlock[ cellnum - 1 ][ DataReadPara[i][2] - 1] , &DataFramHead[i]);
						if(DataFramHead[i].DataNum >= 1200)
						{
							DataFramHead[i].DataNum = DataInfo[ DataReadPara[i][0] ].DataCellNum[cellnum - 1][DataReadPara[i][2] - 1];
						}
					}
					else
					{
						DataFramHead[i].SerialNumber = 0;
						memset(&DataFramHead[i].StartTime, 0 , sizeof(DateTimeStruct));
						memset(&DataFramHead[i].StopTime, 0 , sizeof(DateTimeStruct));
						DataFramHead[i].Type = 0;
						DataFramHead[i].Cell = 0;
						DataFramHead[i].DataNum = 0;
						DataFramHead[i].AH = 0;
					}
				}
				else
				{
					memset(&DataFramHead[i], 0, sizeof(DataHeadStruct) );
					memset(DataFramDat[i], 0, sizeof(DataStruct) * DataFramLen);
				}			
			}
		}
//		DataInfo[0].CellNum = 18;
//		DataInfo[1].CellNum = 18;
//		DataInfo[2].CellNum = 18;
//		DataInfo[3].CellNum = 18;
//		DataInfo[4].CellNum = 18;
//		DataInfo[5].CellNum = 18;
//		DataInfo[6].CellNum = 18;
//		DataInfo[7].CellNum = 18;
//		DataInfo[8].CellNum = 18;
		vTaskDelay(5/portTICK_RATE_MS);
	}
}
void funFdataReadSet(uint8_t src, uint8_t dat_name, int16_t dat)
{
	if(src >= 3)
	{
		return;
	}
	if(dat_name >= 3)
	{
		return ;
	}
	DataReadPara[src][dat_name] = dat;
	
	if(dat_name == 2)
	{//����
		DataReadAsk |= 1 << src;
	}
}

void funFdataAddList(uint32_t addr, uint8_t *buf, int16_t len)
{
	int16_t next;
	if(len > 32)
	{
		return;
	}
	next = DataListEnd + 1;
	if(next >= DataSaveListMax)
	{
		next = 0;
	}
	if(next == DataListStart)
	{
		return;
	}
	DataSaveList[DataListEnd].Addr = addr;
	memcpy(DataSaveList[DataListEnd].DataBuf , buf, len);
	DataListEnd = next;
}

void funFDataClr(void)
{
	SysData.FDataValiveNum = 0;
	FlashClrFlag = 1;
	DataListStart = 0;
	DataListEnd = 0;
	memset(&DataInfo, 0, sizeof(DataInfo));
}


void funFDdataClrOldInfo(uint8_t sn)
{
	uint8_t i;
	if(sn <= SysData.FDataValiveNum)
	{
		for(i = sn; i < SysData.FDataValiveNum; i++)
		{
			memcpy(&DataInfo[i], &DataInfo[i + 1], sizeof(DataInfoStruct));	
		}
		memset(&DataInfo[SysData.FDataValiveNum], 0, sizeof(DataInfoStruct));
		SysData.FDataValiveNum--;
	}
}


void funBlockCheck(int16_t BlockFind)
{
	uint16_t i;
	//���Ҵ˿��Ƿ񱻱���ʹ��
	for(i = 1; i <= SysData.FDataValiveNum; i++)
	{
		if(DataInfo[i].StartBlock < DataInfo[i].StopBlock)	//δ��ҳ
		{
			if((BlockFind >= DataInfo[i].StartBlock) && (BlockFind <= DataInfo[i].StopBlock))	//�ҵ�
			{//�����ʼ�Ŀ�
				funSPIF_EraseBlock(BlockFind * BlockSize);
				//�����Ϣ
				funFDdataClrOldInfo(i);
			}
		}
		else	//��ҳ
		{
			if((BlockFind >= DataInfo[i].StartBlock) || (BlockFind <= DataInfo[i].StopBlock))	//�ҵ�
			{//�����ʼ�Ŀ�
				funSPIF_EraseBlock(BlockFind * BlockSize);
				//�����Ϣ
				funFDdataClrOldInfo(i);
			}
		}
	}
}

int16_t BlockSave;
//��ʼ�µļ�¼
//STEP == 0 �ܿ�ʼ��CELL �������
//STEP != 0 �׶ο�ʼ CELL ��ر��
void funFDataAddStart(uint8_t Cell, uint8_t step)
{//
	int16_t i;
	int16_t Block;
	DataStruct DataTemp;
	//if((Cell == 0) || (step == 0))	//ȫ�¿�ʼ - �ܿ�ʼ
	if(step == 0)	//ȫ�¿�ʼ - �ܿ�ʼ
	{//���������µ����ݵĿ�
		if(SysData.FDataValiveNum != 0)	//������
		{
			Block = DataInfo[1].StopBlock + 1;
			if(Block >= BlockNum)
			{
				Block = 0;
			}
		}
		else
		{
			Block = 0;
		}	
//		funSPIF_EraseBlock(Block * BlockSize);
		
		if((Cell != 0)  && (Cell <= 40))
		{
			memset(&DataInfo[0], 0, sizeof(DataInfoStruct));
			
			funBlockCheck(Block);	//
			//������ˮ��
			DataInfo[0].SerialNum = 1;
			DataInfo[0].SerialNum |= (Now.Year / 10) << 28;
			DataInfo[0].SerialNum |= (Now.Year % 10) << 24;
			DataInfo[0].SerialNum |= (Now.Mon / 10) << 20;
			DataInfo[0].SerialNum |= (Now.Mon % 10) << 16;
			DataInfo[0].SerialNum |= (Now.Day / 10) << 12;
			DataInfo[0].SerialNum |= (Now.Day % 10) << 8;
			DataInfo[0].CellNum = Cell;
			for(i = 1; i <= SysData.FDataValiveNum; i++)
			{
				if((DataInfo[0].SerialNum & 0xFFFFFF00) == (DataInfo[i].SerialNum & 0xFFFFFF00))	//ͬһ��
				{
					if(DataInfo[0].SerialNum  <= DataInfo[i].SerialNum)
					{
						DataInfo[0].SerialNum  = DataInfo[i].SerialNum + 1;
					}
				}
			}
			memcpy(&DataInfo[0].StartTime, &Now, sizeof(DateTimeStruct));	//��ʼʱ��
			
			DataInfo[0].StartBlock = Block;
			DataInfo[0].StopBlock = Block;
			DataInfo[0].Flag = DataFlagStart;
			//���ӵ�д�б�
			DataTemp.TypeCell = 0;
			DataTemp.Start.SerialNum = DataInfo[0].SerialNum;
			DataTemp.Start.CellNum = Cell;
			DataTemp.DateSerial = 0x00;
			memcpy(&DataTemp.Time, &DataInfo[0].StartTime, sizeof(DateTimeStruct));
			
			funFdataAddList(DataInfo[0].StopBlock * BlockSize, (uint8_t *)&DataTemp, sizeof(DataStruct));
		}
	}
	else	//��ͨ�Ľ׶ο�ʼ
	{
		if((Cell != 0) && (step != 0) && (Cell <= 40))
		{
			DataInfo[0].StopBlock ++;
			if(DataInfo[0].StopBlock >= BlockNum)
			{
				DataInfo[0].StopBlock = 0;
			}
			//���Ҵ˿��Ƿ񱻱���ʹ��
			funBlockCheck(DataInfo[0].StopBlock);	//
			
			
			DataTemp.Start.SerialNum = DataInfo[0].SerialNum;
			DataTemp.DateSerial = 0x00;
			memcpy(&DataTemp.Time, &Now, sizeof(DateTimeStruct));
			
			if(DataInfo[0].CellStart == 0)
			{
				DataInfo[0].CellStart = Cell;
			}
			
			switch(step)
			{
				case 0x01:
					DataTemp.TypeCell = 0x40 | Cell;
					DataInfo[0].DataCellFlag[Cell - 1] |= DataFlagStart;
					DataInfo[0].DataCellNum[Cell - 1][0] = 0;
				
					DataInfo[0].CellActNum++;
					DataInfo[0].DataCellStepNum[Cell - 1] = 1;
					break;
				case 0x02:
					DataTemp.TypeCell = 0x80 | Cell;
					DataInfo[0].DataCellFlag[Cell - 1] |= DataFlagStart << 2;
					DataInfo[0].DataCellNum[Cell - 1][1] = 0;
					DataInfo[0].DataCellStepNum[Cell - 1] = 2;
					break;
				case 0x03:
					DataTemp.TypeCell = 0xC0 | Cell;
					DataInfo[0].DataCellFlag[Cell - 1] |= DataFlagStart << 4;
					DataInfo[0].DataCellNum[Cell - 1][2] = 0;
					DataInfo[0].DataCellStepNum[Cell - 1] = 3;
					break;
			}
			funFdataAddList(DataInfo[0].StopBlock * BlockSize, (uint8_t *)&DataTemp, sizeof(DataStruct));
		}
	}
}


void funFDataAddStop(uint8_t Cell, uint8_t step, int8_t stopcode)
{//
	DataStruct DataTemp;
	if((Cell == 0) || (step == 0))	//ȫ�¿�ʼ - �ܿ�ʼ
	{//���������µ����ݵĿ�
		DataInfo[0].StopBlock ++;
		if(DataInfo[0].StopBlock >= BlockNum)
		{
			DataInfo[0].StopBlock = 0;
		}
		//���Ҵ˿��Ƿ񱻱���ʹ��
		funBlockCheck(DataInfo[0].StopBlock);	//

		memcpy(&DataInfo[0].StartTime, &Now, sizeof(DateTimeStruct));	//��ʼʱ��
		DataInfo[0].Flag |= DataFlagStop;
		
		//���ӵ�д�б�
		DataTemp.TypeCell = 0x00;
		//DataTemp.Start.SerialNum = DataInfo[0].SerialNum;
		DataTemp.DateSerial = FlagDataStop;
		//DataTemp.Stop.DataNum = 
		DataTemp.Stop.StopCode = stopcode;
		memcpy(&DataTemp.Time, &Now, sizeof(DateTimeStruct));
		
		funFdataAddList(DataInfo[0].StopBlock * BlockSize, (uint8_t *)&DataTemp, sizeof(DataStruct));
		//�����б�����
		
	}
	else	//��ͨ�Ľ׶ο�ʼ
	{
		if((Cell != 0) && (step != 0) && (Cell < 40))
		{
			DataTemp.DateSerial = FlagDataStop;
			memcpy(&DataTemp.Time, &Now, sizeof(DateTimeStruct));
			DataTemp.Stop.StopCode = stopcode;
			switch(step)
			{
				case 0x01:
					DataTemp.TypeCell = 0x40 | Cell;
					DataTemp.Stop.DataNum = DataInfo[0].DataCellNum[Cell - 1][0];
					DataInfo[0].DataCellFlag[Cell - 1] |= DataFlagStop;
					DataInfo[0].DataCellNum[Cell - 1][0] = 0;
					break;
				case 0x02:
					DataTemp.TypeCell = 0x80 | Cell;
					DataTemp.Stop.DataNum = DataInfo[0].DataCellNum[Cell - 1][1];
					DataInfo[0].DataCellFlag[Cell - 1] |= DataFlagStop << 2;
					break;
				case 0x03:
					DataTemp.TypeCell = 0xC0 | Cell;
					DataTemp.Stop.DataNum = DataInfo[0].DataCellNum[Cell - 1][2];
					DataInfo[0].DataCellFlag[Cell - 1] |= DataFlagStop << 4;
					DataInfo[0].DataCellNum[Cell - 1][2] = 0;
					break;
			}
			funFdataAddList((DataInfo[0].StopBlock * BlockSize) + ((DataTemp.Stop.DataNum + 1 )* sizeof(DataStruct)), 
											(uint8_t *)&DataTemp, sizeof(DataStruct));
		}
	}
}

void funFDataAddData(uint8_t Cell, uint8_t step, int16_t volt, int16_t Curr,	int16_t AH)
{
	DataStruct DataTemp;
	
	if((step != 0) && (step < 4)
		&& (Cell != 0) && (Cell < 40))
	{
		if(DataInfo[0].DataCellNum[Cell - 1][step - 1] > 1200)
		{
			return;
		}
		DataInfo[0].DataCellNum[Cell - 1][step - 1]++;
		
		DataTemp.Data.Volt = volt;
		DataTemp.Data.Curr = Curr;
		DataTemp.Data.AH = AH;
		DataTemp.DateSerial = 0x55;
		memcpy(&DataTemp.Time, &Now, sizeof(DateTimeStruct));
		
		DataTemp.TypeCell = (step << 6) | Cell;

		funFdataAddList((DataInfo[0].StopBlock * BlockSize) + (DataInfo[0].DataCellNum[Cell - 1][step - 1] * sizeof(DataStruct)), 
			(uint8_t *)&DataTemp, sizeof(DataStruct));
	}
}




void funFDataInit(void)
{
	uint16_t i, j, k;
	uint16_t temp;
	uint8_t Type, Cell;
	uint8_t Block_End = 0;
	
	memset(FDataBlockValive, 0, sizeof(FDataBlockValive));
	memset(&DataInfo, 0, sizeof(DataInfo));
	SysData.FDataValiveNum = 0;

//	funFDataAddStart(0,0);

	funSPIF_ReadData(0, (uint8_t *)DataReadBuf, sizeof(DataStruct));	//����һ����¼
	if((DataReadBuf[0].Start.SerialNum != 0) && (DataReadBuf[0].Start.SerialNum != 0xFFFFFFFF))	//��¼��Ч
	{
		if((DataReadBuf[0].TypeCell != 0) || (DataReadBuf[0].DateSerial != 0))	//��ȫ�ֿ�ʼ����
		{
			DataInfo[SysData.FDataValiveNum].SerialNum = DataReadBuf[0].Start.SerialNum ;	//��ʼ���Ƚ�ֵ
		}
	}
	//Page 0 = Info, 
	//Data[0] = ActStart, Data[1] = ActStop, 	Data[2] = CellStepStart, Data[3] = CellStepStop, 
	//
	for(i = 0; i < BlockNum; i++)	//����ÿ����
	{
		funSPIF_ReadData((BlockSize * i)  , (uint8_t *)DataReadBuf, sizeof(DataStruct));	//һ�ζ�һ����������
		if((DataReadBuf[0].Start.SerialNum == 0) || (DataReadBuf[0].Start.SerialNum == 0xFFFFFFFF))	//���¼��Ч
		{
			continue;	//������һ����
		}
		if(DataInfo[SysData.FDataValiveNum].SerialNum != DataReadBuf[0].Start.SerialNum)
		{
			if((DataReadBuf[0].DateSerial == 0) && (DataReadBuf[0].TypeCell == 0)) //��ʾ���λ��ʼ
			{
				SysData.FDataValiveNum++;
				//�˴������жϳ�����Χ
				if(SysData.FDataValiveNum > DataInfoMax)
				{
					SysData.FDataValiveNum = DataInfoMax;
					//ѭ��������ɼ���ˮ����С
					temp = 1;
					for(j = 1; j <= DataInfoMax; j++) 
					{
						if(DataInfo[j].SerialNum < DataInfo[temp].SerialNum)
						{
							temp = j;
						}
					}
					if(DataReadBuf[0].Start.SerialNum < DataInfo[temp].SerialNum)	//�¶������ݸ���//�Ƴ��������
					{
						continue;
					}
					//�Ƴ��������
					for(j = temp; j < DataInfoMax; j++) 
					{
						memcpy(&DataInfo[j], &DataInfo[j + 1], sizeof(DataInfoStruct));	//
					}
					memset(&DataInfo[DataInfoMax], 0, sizeof(DataInfoStruct));	//
				}

				DataInfo[SysData.FDataValiveNum].SerialNum = DataReadBuf[0].Start.SerialNum;	//��ˮ��
				memcpy(&DataInfo[SysData.FDataValiveNum].StartTime, &DataReadBuf[0].Time, sizeof(DateTimeStruct));	//��ʼʱ��
				DataInfo[SysData.FDataValiveNum].CellNum = DataReadBuf[0].Start.CellNum ;	//�������
				DataInfo[SysData.FDataValiveNum].Flag |= DataFlagStart;	//��ʼ���
				DataInfo[SysData.FDataValiveNum].StartBlock = i;
				
				DataInfo[SysData.FDataValiveNum].CellActNum = 0;	//�����
				DataInfo[SysData.FDataValiveNum].CellStart = 0;	//��ʼ����
				
				for(j = 0; j < DevSubMax; j++)
				{
					DataInfo[SysData.FDataValiveNum].DataCellStepNum[j] = 0;//��ؽ׶�����
					DataInfo[SysData.FDataValiveNum].DataCellFlag[j] = 0;//��ʼ������־
					DataInfo[SysData.FDataValiveNum].DataCelBlock[j][0] = 0;//�������λ��
					DataInfo[SysData.FDataValiveNum].DataCelBlock[j][1] = 0;
					DataInfo[SysData.FDataValiveNum].DataCelBlock[j][2] = 0;
					
					DataInfo[SysData.FDataValiveNum].DataCellNum[j][0] = 0;//�����������
					DataInfo[SysData.FDataValiveNum].DataCellNum[j][1] = 0;
					DataInfo[SysData.FDataValiveNum].DataCellNum[j][2] = 0;
				}
			}
			else	//��Ч�������п�ʼ
			{
				continue;	//�˳�����ѭ��
			}
		}
		else	//��ͬ�ı��
		{
			if(i > DataInfo[SysData.FDataValiveNum].StopBlock)
			{
				DataInfo[SysData.FDataValiveNum].StopBlock = i;
			}
			if(DataReadBuf[0].TypeCell == 0)	//������
			{
				if(DataReadBuf[0].DateSerial == FlagDataStop)	//��ʾ���λ����
				{
					DataInfo[SysData.FDataValiveNum].Flag |= DataFlagStop;	//��ʼ���
					memcpy(&DataInfo[SysData.FDataValiveNum].StopTime, &DataReadBuf[1].Time, sizeof(DateTimeStruct));
					DataInfo[SysData.FDataValiveNum].StopBlock = i;
				}
			}
			else	//�׶�����
			{
				for(j = 0; j < PageInBlockrNum; j++)	
				{
					funSPIF_ReadData((BlockSize * i) + (PageSize * j) , (uint8_t *)DataReadBuf, PageSize);	//һ�ζ�һ����������
					for(k = 0; k < 16; k++)
					{
						Cell = DataReadBuf[0].TypeCell & 0x3F;
						Type = DataReadBuf[0].TypeCell & 0xC0;
						Type >>= 6;
						if((Type != 0) && (Cell != 0)  && (Cell <= 40) )	//��Ч����
						{
							if((DataReadBuf[0].DateSerial == 0x00) && (j == 0) && (k == 0)	)//�׶ο�ʼ
							{
								
								switch(Type)
								{
									case 1:
										DataInfo[SysData.FDataValiveNum].DataCellFlag[Cell - 1] |= DataFlagStart;
										DataInfo[SysData.FDataValiveNum].DataCelBlock[Cell - 1][0] = i;
									
										if(DataInfo[SysData.FDataValiveNum].CellStart == 0)
										{
											DataInfo[SysData.FDataValiveNum].CellStart = Cell;	//��ʼ����
										}
										DataInfo[SysData.FDataValiveNum].CellActNum ++;	//�����
										
										DataInfo[SysData.FDataValiveNum].DataCellStepNum[Cell - 1]++; //��ؽ׶�����
										break;
									case 2:
										DataInfo[SysData.FDataValiveNum].DataCellFlag[Cell - 1] |= DataFlagStart << 2;
										DataInfo[SysData.FDataValiveNum].DataCelBlock[Cell - 1][1] = i;
										DataInfo[SysData.FDataValiveNum].DataCellStepNum[Cell - 1]++; //��ؽ׶�����
										break;
									case 3:
										DataInfo[SysData.FDataValiveNum].DataCellFlag[Cell - 1] |= DataFlagStart << 4;
										DataInfo[SysData.FDataValiveNum].DataCelBlock[Cell - 1][2] = i;
										DataInfo[SysData.FDataValiveNum].DataCellStepNum[Cell - 1]++; //��ؽ׶�����
										break;
								}
								DataInfo[SysData.FDataValiveNum].DataCellNum[Cell - 1][Type - 1] = 0;
							}
							else if(DataReadBuf[k].DateSerial == 0x55)	//����
							{
								DataInfo[SysData.FDataValiveNum].DataCellNum[Cell - 1][Type - 1] ++;
							}
							else if(DataReadBuf[k].DateSerial == FlagDataStop)	//����
							{
								switch(Type)
								{
									case 1:
										DataInfo[SysData.FDataValiveNum].DataCellFlag[Cell - 1] |= DataFlagStop;
										//DataInfo[SysData.FDataValiveNum].DataCellNum[Cell - 1][0] = temp;
										break;
									case 2:
										DataInfo[SysData.FDataValiveNum].DataCellFlag[Cell - 1] |= DataFlagStop << 2;
										//DataInfo[SysData.FDataValiveNum].DataCellNum[Cell - 1][1] = temp;
										break;
									case 3:
										DataInfo[SysData.FDataValiveNum].DataCellFlag[Cell - 1] |= DataFlagStop << 4;
										//DataInfo[SysData.FDataValiveNum].DataCellNum[Cell - 1][2] = temp;
										break;
								}
								Block_End = 1;//�����
								break;	//ҳ����
							}
							else	//�쳣����
							{
								switch(Type)
								{
									case 1:
										//DataInfo[SysData.FDataValiveNum].DataCellNum[Cell - 1][0] = temp;
										break;
									case 2:
										//DataInfo[SysData.FDataValiveNum].DataCellNum[Cell - 1][1] = temp;
										break;
									case 3:
										//DataInfo[SysData.FDataValiveNum].DataCellNum[Cell - 1][2] = temp;
										break;
								}
								Block_End = 1;//�����
								break;	//ҳ����
							}
						}	
						else
						{
						}
					}						
					if(Block_End != 0)
					{
						Block_End = 0;//
						break;	//�����
					}
				}	//end for (j < PageInBlockrNum)
			}
		}
	}//end for (i < BlockNum)
	
	if(SysData.FDataValiveNum >= 1)
	{
		if(DataInfo[0].SerialNum == DataInfo[SysData.FDataValiveNum].SerialNum)	//�ϲ�
		{
			DataInfo[SysData.FDataValiveNum].Flag |= DataInfo[0].Flag & DataFlagStop;
			DataInfo[SysData.FDataValiveNum].StopBlock = DataInfo[0].StopBlock;
			memcpy(&DataInfo[SysData.FDataValiveNum].StopTime, &DataInfo[0].StopTime, sizeof(DateTimeStruct));
			
			for(i = 0; i < 40; i++)
			{
				if(DataInfo[SysData.FDataValiveNum].Flag == 0) //�޿�ʼ
				{
					DataInfo[SysData.FDataValiveNum].Flag = DataInfo[0].Flag;
					DataInfo[SysData.FDataValiveNum].CellStart = DataInfo[0].CellStart;
					DataInfo[SysData.FDataValiveNum].DataCellStepNum[i] += DataInfo[0].DataCellStepNum[i];
					
					DataInfo[SysData.FDataValiveNum].DataCelBlock[i][0] = DataInfo[SysData.FDataValiveNum].DataCelBlock[i][0];
					DataInfo[SysData.FDataValiveNum].DataCelBlock[i][1] = DataInfo[SysData.FDataValiveNum].DataCelBlock[i][1];
					DataInfo[SysData.FDataValiveNum].DataCelBlock[i][2] = DataInfo[SysData.FDataValiveNum].DataCelBlock[i][2];
					
					DataInfo[SysData.FDataValiveNum].DataCellNum[i][0] = DataInfo[SysData.FDataValiveNum].DataCellNum[i][0];
					DataInfo[SysData.FDataValiveNum].DataCellNum[i][1] = DataInfo[SysData.FDataValiveNum].DataCellNum[i][1];
					DataInfo[SysData.FDataValiveNum].DataCellNum[i][2] = DataInfo[SysData.FDataValiveNum].DataCellNum[i][2];
				}
			}
		}
	}
	memset(&DataInfo, 0, sizeof(DataInfoStruct));	//
	//����--��������
	for(i = 1; i < SysData.FDataValiveNum; i++)
	{
		for(j = i + 1; j <= SysData.FDataValiveNum; j++)
		{
			if(DataInfo[i].SerialNum < DataInfo[j].SerialNum)
			{
				memcpy(&DataInfo[0], &DataInfo[j], sizeof(DataInfoStruct));	
				memcpy(&DataInfo[j], &DataInfo[i], sizeof(DataInfoStruct));	
				memcpy(&DataInfo[i], &DataInfo[0], sizeof(DataInfoStruct));	
			}
		}
	}
	memset(&DataInfo, 0, sizeof(DataInfoStruct));	//
}



void funFdataRead(uint8_t src, int16_t Block, DataHeadStruct *head)
{
	int16_t num, i, k;
	int16_t flag = 0;
	if((Block < 0) || (Block >= BlockNum))
	{
		return ;
	}
	if(src > 2)
	{
		return;
	}
	memset(DataFramDat[src], 0, sizeof(DataStruct) * DataFramLen);

	for(i = 0; i < PageInBlockrNum; i++)
	{
		funSPIF_ReadData((BlockSize * Block) + (PageSize * i) , (uint8_t *)DataReadBuf, PageSize);	//һ�ζ�һ����������
		for(k = 0; k < 16; k++)
		{
			if((DataReadBuf[k].DateSerial == 0x00)	//��ʼ 
				&& (i == 0) && (k == 0) )
			{
				memcpy(&head->StartTime, &DataReadBuf[k].Time, sizeof(DateTimeStruct) );
				head->SerialNumber = DataReadBuf[k].Start.SerialNum;
				head->Type = (DataReadBuf[k].TypeCell >> 6) & 0x03;
				head->Cell = DataReadBuf[k].TypeCell & 0x03F;

				num = 0;
				flag = 1;
			}
			else if((DataReadBuf[k].DateSerial == 0x55)	&& (flag != 0))//����
			{
				memcpy(&DataFramDat[src][num], &DataReadBuf[k], sizeof(DataStruct));
				num++;
				head->AH = DataReadBuf[k].Data.AH;
				head->DataNum = num;
			}
			else if((DataReadBuf[k].DateSerial == FlagDataStop)	&& (flag != 0))	//����
			{
				memcpy(&head->StopTime, &DataReadBuf[k].Time, sizeof(DateTimeStruct) );
				head->DataNum = DataReadBuf[k].Stop.DataNum;
				head->StopType = DataReadBuf[k].Stop.StopCode;
				break;
			} 
			else	//�쳣����
			{
				break;
			}
		}
	}
	
					
	
//	Serial--;
//	//Serial += BlockNum
//	temp = BlockNum + FDataLast - Serial;
//	temp %= BlockNum;
//	
//	funSPIF_ReadData(BlockSize * temp, (uint8_t *)&FDataReadHead.Start, sizeof(FDataStart_STRUCT));
//	funSPIF_ReadData(BlockSize * temp + PageSize, (uint8_t *)&FDataReadHead.Stop, sizeof(FDataStop_STRUCT));
//	
//	memset(&FDataRead, 0 , sizeof(FDataRead));
//	num = FDataReadHead.Stop.Num < FDataNumMax ? FDataReadHead.Stop.Num : FDataNumMax;	
//	
//	
//	PageDatNum = PageSize / sizeof(FData_STRUCT);	//ȷ�����ݶ��룬������  256/16 = 16
//	//Page = num / PageDatNum;
//	for(i = 0; i < num; )
//	{
//		funSPIF_ReadData((BlockSize * temp) + SectorSize + ((i / PageDatNum) * PageSize), (uint8_t *)&FDataRead[i], PageSize);
//		i += PageDatNum;
//	}
	//
}


void funSPIF_Reset(void);
uint16_t funSPIF_ReadID(void);

uint16_t SPIF_ID;
void funSPIF_Init(void)
{
	funSPIF_Reset();
	vTaskDelay(50/portTICK_RATE_MS);
	SPIF_ID = funSPIF_ReadID();
}

void funSPIF_Reset(void)
{
	FlashSPI_WR_DIS;
	FlashSPI_CS1_EN;
	
	SPIF_TxBuf[0] = SPIF_CMD_ResetEn;
	drvFlashSPI_SendRecData(SPIF_TxBuf, SPIF_RxBuf, 1);
	vTaskDelay(5/portTICK_RATE_MS);
	
	FlashSPI_CS1_DIS;
	vTaskDelay(2/portTICK_RATE_MS);

	FlashSPI_CS1_EN;
	
	SPIF_TxBuf[0] = SPIF_CMD_ResetDEV;
	drvFlashSPI_SendRecData(SPIF_TxBuf, SPIF_RxBuf, 1);
	vTaskDelay(5/portTICK_RATE_MS);
	
	FlashSPI_CS1_DIS;
}

uint16_t funSPIF_ReadID(void)
{
	uint16_t id;
	FlashSPI_WR_DIS;
	FlashSPI_CS1_EN;
	
	SPIF_TxBuf[0] = SPIF_CMD_DEVID;
	SPIF_TxBuf[1] = 0;
	SPIF_TxBuf[2] = 0;
	SPIF_TxBuf[3] = 0;
	SPIF_TxBuf[4] = 0;
	SPIF_TxBuf[5] = 0;
	
	drvFlashSPI_SendRecData(SPIF_TxBuf, SPIF_RxBuf, 6);
	vTaskDelay(5/portTICK_RATE_MS);
	
	FlashSPI_CS1_DIS;

	id = (SPIF_RxBuf[4] << 8) | SPIF_RxBuf[5];
	return id;
}

uint8_t funSPIF_ReadSts(void)
{
	FlashSPI_WR_DIS;
	FlashSPI_CS1_EN;
	
	SPIF_TxBuf[0] = SPIF_CMD_ReadSts1;
	SPIF_TxBuf[1] = 0;
	
	drvFlashSPI_SendRecData(SPIF_TxBuf, SPIF_RxBuf, 2);
	vTaskDelay(2/portTICK_RATE_MS);
	FlashSPI_CS1_DIS;

	return SPIF_RxBuf[1];
}

uint8_t funSPIF_WriteEn(uint8_t enable)
{
	FlashSPI_WR_DIS;
	FlashSPI_CS1_EN;
	if(enable != 0)
	{
		SPIF_TxBuf[0] = SPIF_CMD_WriteEN;
	}
	else
	{
		SPIF_TxBuf[0] = SPIF_CMD_WriteDIS;
	}
	drvFlashSPI_SendRecData(SPIF_TxBuf, SPIF_RxBuf, 1);
	vTaskDelay(2/portTICK_RATE_MS);
	FlashSPI_CS1_DIS;

	return SPIF_RxBuf[1];
}

uint16_t funSPIF_EraseBlock(uint32_t addr)
{
	uint16_t id;
	uint8_t sts;
	
	sts = funSPIF_ReadSts();
	while((sts & 0x02) == 0)
	{
		funSPIF_WriteEn(1);
		sts = funSPIF_ReadSts();
	}
	
	FlashSPI_WR_DIS;
	FlashSPI_CS1_EN;
	
	SPIF_TxBuf[0] = SPIF_CMD_BloackErase1;
	SPIF_TxBuf[1] = (addr >> 16) & 0xFF;
	SPIF_TxBuf[2] = (addr >> 8) & 0xFF;
	SPIF_TxBuf[3] = addr & 0xFF;
	
	drvFlashSPI_SendRecData(SPIF_TxBuf, SPIF_RxBuf, 4);
	vTaskDelay(5/portTICK_RATE_MS);
	FlashSPI_CS1_DIS;
	
	sts = funSPIF_ReadSts();
	while(sts & 0x01)
	{
		sts = funSPIF_ReadSts();
	}
	
	id = (SPIF_RxBuf[4] << 8) | SPIF_RxBuf[5];
	return id;
}

uint16_t funSPIF_EraseChip(void)
{
	uint16_t id;
	uint8_t sts;
	FlashSPI_WR_DIS;
	FlashSPI_CS1_EN;
	
	SPIF_TxBuf[0] = SPIF_CMD_ChipErase1;
	
	drvFlashSPI_SendRecData(SPIF_TxBuf, SPIF_RxBuf, 1);
	vTaskDelay(2/portTICK_RATE_MS);
	FlashSPI_CS1_DIS;
	
	sts = funSPIF_ReadSts();
	while(sts & 0x01)
	{
		sts = funSPIF_ReadSts();
	}
	
	id = (SPIF_RxBuf[4] << 8) | SPIF_RxBuf[5];
	return id;
}


uint16_t funSPIF_ReadData(uint32_t addr, uint8_t *buf, int32_t len)
{
	uint16_t rdlen;	
	FlashSPI_WR_DIS;
	FlashSPI_CS1_EN;
	
	memset(SPIF_TxBuf, 0, sizeof(SPIF_TxBuf));
	SPIF_TxBuf[0] = SPIF_CMD_FastRead;
	SPIF_TxBuf[1] = (addr >> 16) & 0xFF;
	SPIF_TxBuf[2] = (addr >> 8) & 0xFF;
	SPIF_TxBuf[3] = addr & 0xFF;
	drvFlashSPI_SendRecData(SPIF_TxBuf, SPIF_RxBuf, 5 + len);
	vTaskDelay(5/portTICK_RATE_MS);
	FlashSPI_CS1_DIS;

	for(rdlen = 0; rdlen < len; rdlen++)
	{
		*buf++ = SPIF_RxBuf[5 + rdlen];
	}
	rdlen = len;
	return rdlen;
}



uint16_t funSPIF_WriteData(uint32_t addr, uint8_t *buf, int32_t len)
{
	uint16_t wrlen;
	uint8_t sts;
	
	sts = funSPIF_ReadSts();
	while((sts & 0x02) == 0)
	{
		funSPIF_WriteEn(1);
		sts = funSPIF_ReadSts();
	}
	
	FlashSPI_WR_EN;
	FlashSPI_CS1_EN;
	
	SPIF_TxBuf[0] = SPIF_CMD_PageProg;
	SPIF_TxBuf[1] = (addr >> 16) & 0xFF;
	SPIF_TxBuf[2] = (addr >> 8) & 0xFF;
	SPIF_TxBuf[3] = addr & 0xFF;
	for(wrlen = 0; wrlen < len; wrlen++)
	{
		 SPIF_TxBuf[4 + wrlen] = *buf++;
	}
	drvFlashSPI_SendRecData(SPIF_TxBuf, SPIF_RxBuf, 4 + len);
	vTaskDelay(5/portTICK_RATE_MS);
	FlashSPI_WR_DIS;
	FlashSPI_CS1_DIS;
		
	sts = funSPIF_ReadSts();
	while(sts & 0x01)
	{
		sts = funSPIF_ReadSts();
	}
	
	return wrlen;
}





















